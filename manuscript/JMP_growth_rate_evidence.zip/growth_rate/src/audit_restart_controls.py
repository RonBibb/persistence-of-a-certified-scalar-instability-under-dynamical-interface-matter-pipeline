"""Post-run adverse identity controls and fresh checked Dirichlet replay."""
import copy,json,platform,sys
from pathlib import Path
assert platform.system()=='Linux'
from flow import ROOT,sha,atomic,run,verify_freeze
import flint

def check_files(expected):
 for name,digest in expected.items():
  if sha(ROOT/name)!=digest: raise RuntimeError('Frozen file mismatch: '+name)
def check_runtime(expected):
 if sha(Path(sys.executable).resolve())!=expected['executable_sha256']: raise RuntimeError('Executable mismatch')
 if flint.__version__!=expected['flint_version']: raise RuntimeError('FLINT version mismatch')
 if str(Path(flint.__file__).resolve().parent)!=expected['flint_path']: raise RuntimeError('FLINT location mismatch')
 if flint.ctx.prec!=expected['precision_bits'] or flint.ctx.threads!=expected['threads']: raise RuntimeError('Arithmetic context mismatch')
 for p,digest in expected['libraries'].items():
  if sha(p)!=digest: raise RuntimeError('Native library mismatch')
def rejects(fun,value):
 try: fun(value)
 except RuntimeError: return True
 return False

guard=verify_freeze(); freeze=json.loads((ROOT/'FREEZE.json').read_text())
runtime=json.loads((ROOT/'RUNTIME.json').read_text())
check_files(freeze['files']); check_runtime(runtime)
checks={}
for path,label in [('src/primary_interval.py','source'),('inputs/central_bindings.json','inputs'),('CONTRACT.md','protocol')]:
 bad=copy.deepcopy(freeze['files']);bad[path]='0'*64
 checks[label+'_mismatch_rejected']=rejects(check_files,bad)
for field,value in [('executable_sha256','0'*64),('precision_bits',767),('threads',2),('flint_version','wrong')]:
 bad=copy.deepcopy(runtime);bad[field]=value
 checks[field+'_mismatch_rejected']=rejects(check_runtime,bad)
assert all(checks.values())
bracket=json.loads((ROOT/'results/BRACKET_dirichlet.json').read_text())
mu=bracket['mu_bracket'][1]
old=json.loads((ROOT/bracket['endpoint_records'][1]['file']).read_text())
new=run('primary','dirichlet',mu)
assert new==old,'Fresh checked replay did not exactly reproduce terminal unit'
out=ROOT/'results/DIRICHLET_CHECKED_REPLAY.json'
assert not out.exists();atomic(out,new)
atomic(ROOT/'RESTART_AUDIT.json',{'pass':True,'guard':guard,'source_sha256':sha(__file__),'checks':checks,'actual_runtime_matches_freeze':True,'fresh_process_dirichlet_unit_exact_repeat':True,'replay_record':str(out.relative_to(ROOT)),'scope':'Terminal-unit replay and mismatch rejection; no mid-flow checkpoint recovery is claimed'})
atomic(ROOT/'progress/flow.json',{'state':'COMPLETE','guard':guard,'last_unit':'Dirichlet checked replay','all_scientific_units_complete':True})
print(json.dumps({'pass':True,'mismatch_controls':len(checks),'dirichlet_fresh_replay_exact':True}))
