"""Read-only exact-rational audit and growth conversion after producer closeout."""
import hashlib,json,math,os,platform,sys
from pathlib import Path
from fractions import Fraction as Q
from datetime import datetime,timezone
assert platform.system()=='Linux'
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,obj):(ROOT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
freeze=json.loads((ROOT/'FREEZE.json').read_text()); guard=sha(ROOT/'FREEZE.json')
for name,digest in freeze['files'].items(): assert sha(ROOT/name)==digest,name
runtime=json.loads((ROOT/'RUNTIME.json').read_text())
assert sha(Path(sys.executable).resolve())==runtime['executable_sha256']
import flint
assert flint.__version__==runtime['flint_version']
assert str(Path(flint.__file__).resolve().parent)==runtime['flint_path']
for path,digest in runtime['libraries'].items(): assert sha(path)==digest,path
write('RUNTIME_RECHECK.json',{'pass':True,'utc':datetime.now(timezone.utc).isoformat(),'executable_matches':True,'library_files_verified':len(runtime['libraries']),'freeze_file_count':len(freeze['files']),'scope':'Post-run observed runtime and source identities match the pre-run freeze; no assertion of independent arithmetic-library correctness'})
allb=json.loads((ROOT/'results/BRACKETS.json').read_text()); assert allb['status']=='COMPLETE' and allb['guard']==guard
bindings=json.loads((ROOT/'inputs/central_bindings.json').read_text())
dlo,dhi=map(Q,bindings['config']['D'])
def strict_sign(record):
 lo,hi=Q(record['determinant']['lo']),Q(record['determinant']['hi'])
 assert lo<=hi
 return 1 if lo>0 else -1 if hi<0 else 0
def sqrt_floor(q,n=1000000):
 z=math.isqrt((q.numerator*n*n)//q.denominator)
 assert Q(z,n)**2<=q<Q(z+1,n)**2
 return Q(z,n)
def lower_rate(x):return sqrt_floor(Q(9,4)-x)-Q(3,2)
def upper_rate(x):return sqrt_floor(Q(9,4)-x)+Q(1,1000000)-Q(3,2)
def format6(q):
 assert q*1000000==int(q*1000000)
 return f'{float(q):.6f}'
summary={}; all_k=[]; verified=0
for wall,b in allb['results'].items():
 lo,hi=map(Q,b['mu_bracket']); assert lo<hi
 records=[]
 for ref in b['endpoint_records']:
  path=ROOT/ref['file']; assert sha(path)==ref['sha256']
  r=json.loads(path.read_text()); assert r['status']=='COMPLETE' and r['guard']==guard
  assert r['wall']==wall and r['all_cell_gates_pass']
  assert strict_sign(r)==r['sign']!=0
  assert Q(r['curvature']['lo'])>0 and Q(r['shifted_mass']['hi'])<0
  assert Q(r['minimum_warp_squared_lower'])>0
  assert r['cells']==(8183 if r['engine']=='primary' else 16365)
  assert r['trajectory_checkpoints'][-1]['cell']==r['cells']
  last=dlo
  for piece in r['full_event_cover']:
   assert Q(piece['lo'])==last and Q(piece['hi'])>=last
   last=Q(piece['hi'])
   assert Q(r['determinant']['lo'])<=Q(piece['determinant']['lo'])<=Q(piece['determinant']['hi'])<=Q(r['determinant']['hi'])
  assert last==dhi
  records.append(r); all_k.append((Q(r['curvature']['lo']),Q(r['curvature']['hi']))); verified+=1
 for engine in ['primary','independent']:
  pair=[r for r in records if r['engine']==engine]
  assert len(pair)==2
  assert [Q(r['mu']) for r in pair]==[lo,hi]
  assert pair[0]['sign']*pair[1]['sign']==-1
 kl=min(Q(r['curvature']['lo']) for r in records); kh=max(Q(r['curvature']['hi']) for r in records)
 xlo,xhi=lo/kl,hi/kh
 rl,rh=lower_rate(xhi),upper_rate(xlo)
 assert rl>1 and (rl+Q(3,2))**2 <= Q(9,4)-xhi
 assert (rh+Q(3,2))**2 > Q(9,4)-xlo
 summary[wall]={'mu_bracket_exact':[str(lo),str(hi)],'mu_bracket_approx':[float(lo),float(hi)],
  'mu_over_k_outer_exact':[str(xlo),str(xhi)],'mu_over_k_approx':[float(xlo),float(xhi)],
  'growth_over_expansion_outer_exact':[str(rl),str(rh)],'growth_over_expansion_outer_decimal':[format6(rl),format6(rh)],
  'root_exists_and_unique':'Opposite interval signs plus inherited one-turn theorem','endpoints_verified_in_both_engines':True}
kl=min(k[0] for k in all_k); kh=max(k[1] for k in all_k)
softlo=Q(summary['soft']['mu_bracket_exact'][0]); ddhi=Q(summary['dirichlet']['mu_bracket_exact'][1])
uniformlo=lower_rate(ddhi/kh); uniformhi=upper_rate(softlo/kl)
assert uniformlo>1
assert Q(summary['soft']['mu_bracket_exact'][1]) < Q(summary['physical']['mu_bracket_exact'][0])
assert Q(summary['physical']['mu_bracket_exact'][1]) < Q(summary['dirichlet']['mu_bracket_exact'][0])
result={'status':'PASS','guard':guard,'analyzer_sha256':sha(__file__),'endpoint_records_verified':verified,
 'curvature_hull_exact':[str(kl),str(kh)],'curvature_hull_approx':[float(kl),float(kh)],'cases':summary,
 'uniform_counted_mode_rate':{'lower_exact':str(uniformlo),'upper_exact':str(uniformhi),'lower_decimal':format6(uniformlo),'upper_decimal':format6(uniformhi),'strict_bounds':True,'excess_percent_approx':[float(100*(uniformlo-1)),float(100*(uniformhi-1))],
 'scope':'Fixed exact Appendix A background; all counted modes in Theorems 1–2, including nonnegative pure-potential walls and the admitted finite dynamical wall fields. No family-uniform numerical margin is claimed.',
 'proof':'Static and finite-wall brackets give mu_soft <= mu <= mu_DD. All endpoint mass bounds are strict. Curvature and square-root conversion use conservative exact rational bounds.'},
 'inherited_premises':['Original exact background certificate','Original-action physical domain and weak correspondence','Theorems 1–2 and the one-turn count'],
 'not_established':['Nonlinear fate or inflationary lifetime','Full Cauchy instability theorem','Independent arithmetic library validation','External human peer review']}
write('GROWTH_BOUNDS.json',result)
print(json.dumps({'status':result['status'],'endpoint_records_verified':verified,'curvature':result['curvature_hull_approx'],'cases':{w:{'mu':v['mu_bracket_approx'],'mu_over_k':v['mu_over_k_approx'],'rate':v['growth_over_expansion_outer_decimal']} for w,v in summary.items()},'uniform':result['uniform_counted_mode_rate']},indent=2))
