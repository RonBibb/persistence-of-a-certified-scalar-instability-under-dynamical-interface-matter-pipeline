"""Verify final research artifacts, observe process closure, and seal hashes."""
import hashlib,json,os,platform,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as Q
assert platform.system()=='Linux'
ROOT=Path(__file__).resolve().parents[1]; P=ROOT.parents[1]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(name,obj): (ROOT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
now=datetime.now(timezone.utc)
start=datetime(2026,11,14,19,0,56,tzinfo=timezone.utc)
assert now<datetime(2026,11,14,21,0,56,tzinfo=timezone.utc)
growth=json.loads((ROOT/'GROWTH_BOUNDS.json').read_text()); assert growth['status']=='PASS'
assert json.loads((ROOT/'PREFLIGHT.json').read_text())['pass']
assert json.loads((ROOT/'BOUNDARY_CONTROLS.json').read_text())['pass']
assert json.loads((ROOT/'RESTART_AUDIT.json').read_text())['pass']
assert json.loads((ROOT/'RUNTIME_RECHECK.json').read_text())['pass']
freeze=json.loads((ROOT/'FREEZE.json').read_text())
for name,digest in freeze['files'].items(): assert sha(ROOT/name)==digest,name
for src,dest in freeze['copies'].items(): assert sha(P/src)==sha(ROOT/dest),src
display={'physical':['-4.014904','-4.014865'],'dirichlet':['-4.013410','-4.013371'],'soft':['-4.019143','-4.019104']}
for wall,outer in display.items():
 exact=growth['cases'][wall]['mu_over_k_outer_exact']
 assert Q(outer[0])<Q(exact[0]) and Q(outer[1])>Q(exact[1])
 for value in outer+growth['cases'][wall]['growth_over_expansion_outer_decimal']:
  assert value in (ROOT/'REPORT.md').read_text(),value
for value in ['1.002672','1.003826','1.002971','1.002979']:
 assert value in (ROOT/'PROPOSED_INSERTION.md').read_text()
names=['ActiveState','SubState','MainPID','Result','ExecMainStatus','ControlGroup']
command=['systemctl','--user','show','paper-a-growth-20261114.service']
for name in names: command+=['-p',name]
raw=subprocess.check_output(command,text=True)
unit=dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
assert unit['ActiveState']=='inactive' and unit['MainPID']=='0' and unit['Result']=='success'
live=[]
targets={str(ROOT/'src/investigate.py'),str(ROOT/'src/flow.py'),str(ROOT/'src/audit_restart_controls.py')}
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit(): continue
 try: args=(proc/'cmdline').read_bytes().decode(errors='replace').split('\0')
 except (FileNotFoundError,PermissionError,ProcessLookupError): continue
 if any(arg in targets for arg in args): live.append({'pid':int(proc.name),'args':args})
assert not live
put('RESOURCE_CLOSEOUT.json',{'observed_utc':now.isoformat(),'unit':unit,'live_scientific_workers':live,'aggregate_cpu_quota_cores':1,'native_threads_per_worker':1,'fixed_affinity_pinning':False,'address_space_limit_bytes':3*1024**3,'systemd_memory_limit_bytes':3*1024**3,'hard_science_cutoff_utc':'2026-11-14T21:00:56Z','leases_acquired':0,'other_jobs_or_holds_changed':False,'systemd_run_completion_observed':{'source':'Captured systemd-run completion output','result':'success','service_runtime':'4min 52.865s','cpu_time':'4min 2.300s','memory_peak_display':'41.9M (swap: 0B)'},'production_runtime_is_not_total_investigation_time':True})
flows=[]
for path in sorted((ROOT/'results/flows').glob('*.json')):
 r=json.loads(path.read_text()); assert r['status']=='COMPLETE'
 flows.append((path,r))
indeterminate=[{'file':str(path.relative_to(ROOT)),'engine':r['engine'],'wall':r['wall'],'mu':r['mu'],'determinant':r['determinant']} for path,r in flows if r['sign']==0]
failures=[str(p.relative_to(ROOT)) for p in ROOT.rglob('*.failure.json')]
assert not failures
put('ADVERSE_RECORDS.json',{'indeterminate_sign_units':indeterminate,'handling':'Preserved without assigning a sign; predeclared quarter probes supplied the final strict bracket','failed_scientific_units':failures,'environment_discovery':['Default and old nominal Python environment did not import scipy. No scientific computation ran in those probes. The validated Arb engines were available and no package was installed.'],'intentionally_incomplete_control_file':'results/flows/'+hashlib.sha256(json.dumps([sha(ROOT/'FREEZE.json'),'primary','physical','-33/25000']).encode()).hexdigest()+'.json.uncommitted-control'})
put('CLOSEOUT.json',{'completed_utc':now.isoformat(),'authorized_start_utc':start.isoformat(),'authorized_maximum_seconds':7200,'elapsed_investigation_seconds':(now-start).total_seconds(),'status':'COMPLETE_QUANTITATIVE_FIXED_BACKGROUND_GROWTH_CERTIFICATION','scope_completed':['Physical-wall mass and growth bracket','Dirichlet and soft-corner mass and growth brackets','Wall-uniform rate transfer under inherited theorems','Exact arithmetic and preserved evidence audit','Report and proposed insertion without manuscript edits'],'short_complete_flow_units':len(flows),'additional_checked_dirichlet_replay':1,'decisive_endpoints':12,'scientific_workers_remaining':0,'leases_held':0,'article_changed':False,'supplement_changed':False,'public_pipeline_changed':False,'external_review_performed':False,'release_or_submission_performed':False,'no_successor_authorized':True,'early_completion_reason':'Existing validated engines reached both the physical and wall-uniform targets; evidence and controls are complete, not merely staged.','claim_ceiling':growth['uniform_counted_mode_rate']['scope']})
files=[p for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts]
put('MANIFEST.json',{'sealed_utc':now.isoformat(),'status':'COMPLETE_RESEARCH_PACKET_UNSUBMITTED','files':{str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(files)}})
for name,v in json.loads((ROOT/'MANIFEST.json').read_text())['files'].items(): assert sha(ROOT/name)==v['sha256']
print(json.dumps({'status':'COMPLETE','elapsed_minutes':round((now-start).total_seconds()/60,2),'complete_flow_units':len(flows),'indeterminate_units':len(indeterminate),'manifest_files':len(files),'total_bytes':sum(p.stat().st_size for p in files),'live_workers':0},indent=2))
