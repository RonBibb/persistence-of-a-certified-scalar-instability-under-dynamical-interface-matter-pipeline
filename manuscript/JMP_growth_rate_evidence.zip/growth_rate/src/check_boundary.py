"""Exact symbolic checks of the three boundary launches and rate ordering."""
import json, platform
from pathlib import Path
assert platform.system()=='Linux'
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
T,Tp,lam,kap=s.symbols('T Tp lam kap',nonzero=True)
f=3*lam/(kap*T/2-Tp); g=kap*f/2-2*T
checks={
 'finite_launch_wall':s.cancel(g+2*T-kap*f/2)==0,
 'finite_launch_constraint':s.cancel(T*g-Tp*f+2*T*T-3*lam)==0,
 'soft_launch':s.cancel(f.subs(kap,0)+3*lam/Tp)==0,
 'dirichlet_f_limit':s.limit(f,kap,s.oo)==0,
 'dirichlet_g_limit':s.simplify(s.limit(g,kap,s.oo)-(3*lam/T-2*T))==0,
 'dirichlet_launch_constraint':s.simplify(T*(3*lam/T-2*T)+2*T*T-3*lam)==0
}
x=s.symbols('x',negative=True); rho=s.sqrt(s.Rational(9,4)-x)-s.Rational(3,2)
checks['rate_threshold']=rho.subs(x,-4)==1
checks['rate_derivative']=s.simplify(s.diff(rho,x)+1/(2*s.sqrt(s.Rational(9,4)-x)))==0
assert all(checks.values())
(ROOT/'BOUNDARY_CONTROLS.json').write_text(json.dumps({'pass':True,'checks':{k:bool(v) for k,v in checks.items()},'scope':'Launch, Dirichlet limit and analytic conversion identities; inherited full correspondence theorem is not re-proved'},indent=2)+'\n')
print(json.dumps({'pass':True,'checks':len(checks)}))
