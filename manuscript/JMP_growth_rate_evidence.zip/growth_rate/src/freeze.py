"""Linux-only provenance and immutable source/input freeze."""
import hashlib,json,os,platform,shutil,sys
from pathlib import Path
from datetime import datetime,timezone
assert platform.system()=='Linux'
ROOT=Path(__file__).resolve().parents[1]; P=ROOT.parents[1]
assert P.name=='persistence-of-a-certified-scalar-instability-under-dynamical-interface-matter'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
copies={
 'pipeline/src/historical/mass/primary_interval.py':'src/primary_interval.py',
 'pipeline/src/historical/mass/independent_interval.py':'src/independent_interval.py',
 'pipeline/data/processed/neutral-certificates/phase/phase_regeneration/source/inputs/central_bindings.json':'inputs/central_bindings.json',
 'pipeline/data/processed/neutral-certificates/mass/output/primary_low.json':'inputs/old_primary_low.json',
 'pipeline/data/raw/neutral-certificates/mass/RESULT_REPORT.md':'inputs/old_mass_report.md',
 'publication_updates/20261114_JMP_final_editorial_corrections/manuscript/MAIN_ARTICLE.md':'inputs/MAIN_ARTICLE.md',
 'publication_updates/20261114_JMP_final_editorial_corrections/manuscript/SUPPLEMENT.md':'inputs/SUPPLEMENT.md'
}
assert not (ROOT/'FREEZE.json').exists()
for src,dst in copies.items():
 assert (P/src).is_file(),src
 shutil.copyfile(P/src,ROOT/dst); assert sha(P/src)==sha(ROOT/dst)
import flint
library=Path(flint.__file__).resolve().parent
runtime={'python':sys.version,'executable':str(Path(sys.executable).resolve()),'executable_sha256':sha(Path(sys.executable).resolve()),'platform':platform.platform(),'flint_version':flint.__version__,'flint_path':str(library),'libraries':{str(p):sha(p) for p in list(library.rglob('*.so'))+list(library.parent.glob('python_flint.libs/*')) if p.is_file()},'threads':1,'precision_bits':768,'affinity':list(os.sched_getaffinity(0)),'fixed_pinning':False,'env':{k:os.environ.get(k) for k in ['PYTHONPATH','PYTHONDONTWRITEBYTECODE','PYTHONHASHSEED','PYTHONNOUSERSITE','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS']}}
(ROOT/'RUNTIME.json').write_text(json.dumps(runtime,indent=2)+'\n')
files=[p for sub in ['src','inputs'] for p in (ROOT/sub).glob('*') if p.is_file()]+[ROOT/'CONTRACT.md',ROOT/'METHOD.md',ROOT/'RUNTIME.json']
freeze={'created_utc':datetime.now(timezone.utc).isoformat(),'cutoff_utc':'2026-11-14T21:00:56Z','files':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)},'copies':copies,'source_engines_unmodified':True,'script_version':'v1','work_order':['physical','dirichlet','soft'],'initial_bracket':['-33/25000','-2615/2000000'],'target_width':'1/50000000','max_rounds':18}
(ROOT/'FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps({'freeze_sha256':sha(ROOT/'FREEZE.json'),'files':len(files),'source_root':str(P),'python':sys.version.split()[0],'flint':flint.__version__}))
