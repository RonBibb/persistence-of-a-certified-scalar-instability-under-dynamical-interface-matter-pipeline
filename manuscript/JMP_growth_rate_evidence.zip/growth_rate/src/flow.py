"""One short, complete Linux interval-flow unit. No old source is modified."""
import argparse, hashlib, importlib.util, json, math, os, platform, resource
import sys, tempfile, time, traceback
from pathlib import Path
from fractions import Fraction
from datetime import datetime, timezone
assert platform.system() == 'Linux'
resource.setrlimit(resource.RLIMIT_AS, (3*1024**3, 3*1024**3))
from flint import arb, fmpq, ctx
ctx.prec = 768
ctx.threads = 1
ROOT = Path(__file__).resolve().parents[1]
CUTOFF = datetime(2026, 11, 14, 21, 0, 56, tzinfo=timezone.utc).timestamp()

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def atomic(p, x):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=p.name+'.uncommitted-', dir=p.parent)
    with os.fdopen(fd, 'w') as f:
        json.dump(x, f, sort_keys=True, indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(name, p)
def pack(x):
    return {'lo': str(x.lower().fmpq()), 'hi': str(x.upper().fmpq()),
            'approx': [float(x.lower()), float(x.upper())]}
def sign(x): return 1 if x.lower() > 0 else -1 if x.upper() < 0 else 0
def load_engine(role):
    path = ROOT/'src'/(role+'_interval.py')
    spec = importlib.util.spec_from_file_location('growth_'+role, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod
def verify_freeze():
    freeze = json.loads((ROOT/'FREEZE.json').read_text())
    for name, digest in freeze['files'].items():
        if sha(ROOT/name) != digest: raise RuntimeError('Frozen input changed: '+name)
    return sha(ROOT/'FREEZE.json')

def run(role, wall, mu_text):
    guard = verify_freeze(); m = load_engine(role)
    assert m.algebra_controls()['pass']
    b = json.loads((ROOT/'inputs/central_bindings.json').read_text())
    cfg = b['config']; mu = m.interval(fmpq(mu_text), fmpq(mu_text))
    A = m.interval(*map(fmpq, cfg['A'])); y, p = m.initial(A, mu, b['model_exact'])
    psi_index = 5 if role == 'primary' else 4
    f_index, g_index = psi_index+1, psi_index+2
    T, Tprime = y[3], p['m2']*y[2]-4*y[1]*y[3]
    lower_den = p['B0']
    if wall == 'soft':
        lower_den = -Tprime
        assert sign(lower_den) != 0
        y[f_index] = 3*(mu+4*p['k'])/lower_den
        y[g_index] = -2*T
    elif wall == 'dirichlet':
        lower_den = T
        assert sign(T) < 0
        y[f_index] = arb(0)
        y[g_index] = 3*(mu+4*p['k'])/T-2*T
    elif wall != 'physical':
        raise ValueError('Unknown wall')
    assert m.constraint(y, p).contains(0)
    if wall == 'dirichlet': assert y[f_index].is_zero()
    else:
        kap = 20 if wall == 'physical' else 0
        assert (y[g_index]+2*T-y[f_index]*kap/2).contains(0)
    assert p['k'].lower()>0 and (mu+4*p['k']).upper()<0
    Dlo, Dhi = map(fmpq, cfg['D'])
    h = fmpq(2, cfg[role+'_steps']); n = math.ceil(Fraction(str(Dhi))/Fraction(str(h)))
    event=None; cover=[]; max_picard=0; psi_hull=None; min_warp=None; trace=[]
    start=time.monotonic()
    for j in range(n):
        if time.time() >= CUTOFF: raise TimeoutError('Authorized cutoff reached')
        if time.monotonic()-start > 175: raise TimeoutError('Flow unit deadline reached')
        y, cell = m.step(y, h, p)
        geom=m.geometry(cell,p)
        assert all(v.is_finite() for v in y+list(geom.values()))
        assert geom['constraint'].contains(0) and geom['first_integral'].contains(0)
        assert geom['warp_squared'].lower()>0
        max_picard=max(max_picard,cell['picard_iterations'])
        psi_hull=geom['psi'] if psi_hull is None else m.hull(psi_hull,geom['psi'])
        min_warp=geom['warp_squared'].lower().fmpq() if min_warp is None else min(min_warp,geom['warp_squared'].lower().fmpq())
        s=j*h
        if s+h>=Dlo and s<=Dhi:
            lo=max(fmpq(0),Dlo-s); hi=min(h,Dhi-s)
            yy=m.range_on_cell(cell,lo,hi)
            if wall=='physical': det=m.determinant(yy,p)
            elif wall=='soft': det=yy[g_index]+2*yy[3]*yy[psi_index]
            else: det=yy[f_index]
            event=det if event is None else m.hull(event,det)
            cover.append({'lo':str(s+lo),'hi':str(s+hi),'determinant':pack(det)})
        if (j+1)%512==0 or j+1==n:
            trace.append({'cell':j+1,'s':str((j+1)*h),'state':[pack(v) for v in y]})
            atomic(ROOT/'progress/flow.json', {'state':'RUNNING','engine':role,'wall':wall,'mu':mu_text,'completed_cells':j+1,'total_cells':n,'elapsed_seconds':time.monotonic()-start,'guard':guard})
    last=Dlo
    for piece in cover:
        assert fmpq(piece['lo'])==last; last=fmpq(piece['hi'])
    assert last==Dhi and event is not None
    return {'status':'COMPLETE','guard':guard,'engine':role,'wall':wall,'mu':mu_text,
            'determinant':pack(event),'sign':sign(event),'curvature':pack(p['k']),
            'shifted_mass':pack(mu+4*p['k']),'lower_denominator':pack(lower_den),
            'cells':n,'picard_max_iterations':max_picard,'all_cell_gates_pass':True,
            'whole_psi':pack(psi_hull),'minimum_warp_squared_lower':str(min_warp),
            'full_event_cover':cover,'trajectory_checkpoints':trace}

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--engine',choices=['primary','independent'],required=True)
    parser.add_argument('--wall',choices=['physical','soft','dirichlet'],required=True)
    parser.add_argument('--mu',required=True); parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists(): raise RuntimeError('Refuse to overwrite completed unit')
    try:
        result=run(args.engine,args.wall,args.mu); atomic(args.output,result)
        print(json.dumps({k:result[k] for k in ['engine','wall','mu','sign','determinant','cells']}),flush=True)
    except Exception as error:
        atomic(args.output.with_suffix('.failure.json'),{'status':'INCOMPLETE','error':repr(error),'traceback':traceback.format_exc()})
        raise
