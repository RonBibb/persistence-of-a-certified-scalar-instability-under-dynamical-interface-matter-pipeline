"""Bounded adaptive mass bracketing with complete-flow restart boundaries."""
import hashlib, json, os, platform, subprocess, sys, time
from pathlib import Path
from fractions import Fraction as Q
from datetime import datetime, timezone
assert platform.system()=='Linux'
from flow import ROOT, CUTOFF, atomic, verify_freeze, sha

GUARD=verify_freeze()
RUN_LOG=[]
def key(role,wall,mu):
    return hashlib.sha256(json.dumps([GUARD,role,wall,str(Q(mu))]).encode()).hexdigest()
def validate_record(record,role,wall,mu):
    if record['guard']!=GUARD or record['status']!='COMPLETE': raise RuntimeError('Incompatible terminal unit')
    if [record['engine'],record['wall'],record['mu']] != [role,wall,str(Q(mu))]: raise RuntimeError('Wrong unit parameters')
    assert record['all_cell_gates_pass']
    return record
def unit(role,wall,mu,suffix=''):
    mu=str(Q(mu)); path=ROOT/'results/flows'/(key(role,wall,mu)+suffix+'.json')
    if path.exists(): return validate_record(json.loads(path.read_text()),role,wall,mu)
    if time.time()+190>CUTOFF: raise TimeoutError('Insufficient authorized time for another flow')
    command=[sys.executable,'-B',str(ROOT/'src/flow.py'),'--engine',role,'--wall',wall,'--mu='+mu,'--output',str(path)]
    log=ROOT/'logs'/(path.stem+'.log'); log.parent.mkdir(parents=True,exist_ok=True)
    begun=time.time()
    with log.open('x') as f:
        completed=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    RUN_LOG.append({'command':command,'returncode':completed.returncode,'seconds':time.time()-begun,'log':str(log.relative_to(ROOT))})
    atomic(ROOT/'progress/invocations.json',RUN_LOG)
    if completed.returncode: raise RuntimeError('Flow failed: '+str(log))
    result=validate_record(json.loads(path.read_text()),role,wall,mu)
    print(json.dumps({'engine':role,'wall':wall,'mu':mu,'sign':result['sign'],'det_approx':result['determinant']['approx'],'seconds':time.time()-begun}),flush=True)
    return result
def cache_reference(record):
    return {'file':'results/flows/'+key(record['engine'],record['wall'],record['mu'])+'.json',
            'sha256':sha(ROOT/'results/flows'/(key(record['engine'],record['wall'],record['mu'])+'.json'))}
def checkpoint(wall,lo,hi,round_number,completed):
    atomic(ROOT/'progress/controller.json',{'state':'RUNNING','guard':GUARD,'wall':wall,'bracket':[str(lo),str(hi)],'round':round_number,'completed_walls':completed,'resume_rule':'Reload verified complete unit files and repeat deterministic decisions; completed flows are never recomputed.'})

def preflight():
    low=Q(-33,25000)
    a=unit('primary','physical',low)
    b=unit('primary','physical',low,'-restart-control')
    assert a==b, 'Fresh-process deterministic replay differs'
    corrupted=dict(a); corrupted['guard']='altered'
    rejected=False
    try: validate_record(corrupted,'primary','physical',low)
    except RuntimeError: rejected=True
    assert rejected
    bad_parameters=False
    try: validate_record(a,'primary','physical',Q(-131,100000))
    except RuntimeError: bad_parameters=True
    assert bad_parameters
    partial=ROOT/'results/flows'/(key('primary','physical',low)+'.json.uncommitted-control')
    partial.write_text('{"unfinished":')
    assert unit('primary','physical',low)==a
    old=json.loads((ROOT/'inputs/old_primary_low.json').read_text())['determinant']
    new=a['determinant']
    assert Q(new['lo'])<=Q(old['hi_exact']) and Q(old['lo_exact'])<=Q(new['hi'])
    atomic(ROOT/'PREFLIGHT.json',{'pass':True,'guard':GUARD,'fresh_process_exact_flow_repeat':True,'changed_guard_rejected':rejected,'changed_unit_parameters_rejected':bad_parameters,'uncommitted_file_ignored':True,'physical_low_overlaps_archived':True,'duplicate_control_file':str((ROOT/'results/flows'/(key('primary','physical',low)+'-restart-control.json')).relative_to(ROOT))})

def main():
    preflight(); results={}
    for wall in ['physical','dirichlet','soft']:
        lo=Q(-33,25000); hi=Q(-2615,2000000)
        left=unit('primary',wall,lo); right=unit('primary',wall,hi)
        if not left['sign']*right['sign']==-1: raise RuntimeError('Initial bracket not strict for '+wall)
        orientation=left['sign']; stalled=0
        for round_number in range(18):
            checkpoint(wall,lo,hi,round_number,list(results))
            if hi-lo<=Q(1,50000000): break
            before=(lo,hi); mid=(lo+hi)/2
            test=unit('primary',wall,mid)
            if test['sign']==orientation: lo=mid; left=test
            elif test['sign']==-orientation: hi=mid; right=test
            else:
                for point in [(3*before[0]+before[1])/4,(before[0]+3*before[1])/4]:
                    test=unit('primary',wall,point)
                    if test['sign']==orientation and point>lo: lo=point; left=test
                    elif test['sign']==-orientation and point<hi: hi=point; right=test
            stalled=stalled+1 if (lo,hi)==before else 0
            if stalled>=2: break
        il=unit('independent',wall,lo); ih=unit('independent',wall,hi)
        assert il['sign']==orientation and ih['sign']==-orientation
        for p,i in [(left,il),(right,ih)]:
            assert Q(p['determinant']['lo'])<=Q(i['determinant']['hi']) and Q(i['determinant']['lo'])<=Q(p['determinant']['hi']), 'Engine enclosures do not overlap'
        result={'wall':wall,'mu_bracket':[str(lo),str(hi)],'mu_bracket_approx':[float(lo),float(hi)],'width':str(hi-lo),'target_width_reached':hi-lo<=Q(1,50000000),'primary_signs':[left['sign'],right['sign']],'independent_signs':[il['sign'],ih['sign']],'endpoint_records':[cache_reference(r) for r in [left,right,il,ih]],'curvature':left['curvature'],'inherited_premises':['Exact central background existence and its full A,D enclosures','One-turn restricted count and physical correspondence in current Paper A','Static and finite-wall bracketing for uniform transfer']}
        atomic(ROOT/'results'/('BRACKET_'+wall+'.json'),result); results[wall]=result
    atomic(ROOT/'results/BRACKETS.json',{'status':'COMPLETE','guard':GUARD,'results':results,'runtime_seconds':sum(x['seconds'] for x in RUN_LOG),'wall_clock_completed_utc':datetime.now(timezone.utc).isoformat(),'claim_ceiling':'Computer-assisted endpoint sign brackets conditional on inherited analytic and background premises; not a new independent analytic review'})
    atomic(ROOT/'progress/controller.json',{'state':'COMPLETE','guard':GUARD,'completed_walls':list(results)})

if __name__=='__main__':
    try: main()
    except Exception as e:
        import traceback
        atomic(ROOT/'results/INVESTIGATION_FAILURE.json',{'state':'INCOMPLETE','error':repr(e),'traceback':traceback.format_exc(),'guard':GUARD})
        raise
