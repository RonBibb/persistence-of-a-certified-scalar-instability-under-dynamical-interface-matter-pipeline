# Boundary adaptation and certification argument

The two copied interval engines are unchanged. They propagate the original
regular physical equations in (W,H,Phi,T,psi,f,g), with E=exp(-W) added in the
polynomial implementation. The background launch and curvature are unchanged.
Let lambda=mu+4k, Tprime=m2*Phi-4*H*T and psi_a=1 (a_a=1).

For a finite lower Hessian kappa_a, the lower wall is
g_a+2*T_a*psi_a=kappa_a*f_a/2 and the constraint gives

    (kappa_a*T_a/2-Tprime_a)*f_a = 3*lambda,
    g_a = kappa_a*f_a/2-2*T_a.

For lower Dirichlet conditions f_a=0, the same constraint gives

    g_a=3*lambda/T_a-2*T_a.

The admitted background has T_a<0, so that denominator is safe. At the upper
finite wall the residual is g_b+2*T_b*psi_b+kappa_b*f_b/2. At the Dirichlet
wall the residual is f_b. No division by the interior turning scalar derivative
is introduced. The physical (20,20) arm uses the original initial and determinant
functions without adaptation, permitting direct comparison with old records.

Opposite strict residual signs give a root for the fixed exact background by
continuity. Full A and D intervals contain that background; no midpoint
substitution is used. The inherited one-turn theorem gives uniqueness below
-4k at every admitted wall corner. The inherited static and finite-wall brackets
then transfer the Dirichlet upper mass bound and soft-corner lower mass bound
to all counted modes of the declared wall class on this fixed background.

For k>0 and mu<0, set rho(mu/k)=sqrt(9/4-mu/k)-3/2. It decreases with mu/k.
Interval arithmetic includes curvature uncertainty when enclosing the ratio
and square root. For mu<=mu_DD<=mu_DD_upper<0, the conservative lower rate uses
mu_DD_upper/k_upper. For mu>=mu_soft_lower, the upper rate uses
mu_soft_lower/k_lower. All statements refer to separated linear growing modes;
they do not establish nonlinear fate or a full Cauchy instability theorem.
