# Proposed insertion for author review — not applied to the manuscript

## Main text, following the certified-background application

**Quantitative growth bound.** On the exact background of Appendix A, the counted
mode satisfies
\[
1.002672<r_i/h_i<1.003826
\]
for every wall system admitted by Theorems 1–2. At the physical wall Hessians
\((20,20)\), the sharper enclosure is
\(1.002971<r_i/h_i<1.002979\). These bounds follow from certified soft-corner,
physical-wall and Dirichlet mass enclosures and the decreasing rate map in
Section 3.1. Supplementary Section S10 supplies the exact endpoints and numerical
predicates. The bounds concern this fixed background and its linear separated
growing branch.

## Supplement, following S10.2

Insert the three-case table and boundary launch from this packet's REPORT.md and
METHOD.md. Preserve the exact original background uncertainty, distinguish the
two equation implementations from independent arithmetic backends, and link
the future public evidence package after pipeline integration. The new numerical
margin is not transferred to the parameter families without further mass bounds.

## Figure 1(c)

Place the physical-pair point near
\((\mu/k,r_i/h_i)=(-4.01488,1.002975)\), using the certified interval rectangle
from GROWTH_BOUNDS.json. Any center is only a plotting choice, not a claimed
best-fit eigenvalue. On the existing large axis range the rectangle will be
visually tiny; give its enclosure in the caption or supplement. Retain the
distinction between the analytic curve and the newly certified example.
