# Certified quantitative growth bounds for Paper A

The investigation establishes a quantitative strengthening on the exact
Appendix A background. Under the paper's inherited background, physical-domain
and counting theorems, the unique counted growing mode satisfies

\[
\boxed{1.002672 < r_i/h_i < 1.003826}
\]

for every nonnegative pure-potential wall pair, including the Dirichlet faces,
and every finite dynamical wall system admitted by Theorem 2. The statement is
uniform in those wall choices on this fixed background. It is not a numerical
uniform bound over the parameter families or over other backgrounds.

At the physical wall pair `(20,20)`, the sharper bound is

\[
1.002971 < r_i/h_i < 1.002979.
\]

Thus the physical growing branch exceeds the expansion rate by 0.2971–0.2979%.
Across the entire admitted wall class, the certified excess is bounded between
0.2672% and 0.3826%. These are relative rates, not a claim that the disturbance
itself grows by only that percentage per expansion time.

## Numerical results

The table's mass-ratio and rate bounds are rounded outward. The exact rational
mass endpoints and curvature enclosures are retained in `GROWTH_BOUNDS.json`
and the linked producer records.

| Wall conditions | Enclosure for mu/k | Enclosure for r_i/h_i |
|---|---|---|
| Physical, `(20,20)` | `(-4.014904, -4.014865)` | `(1.002971, 1.002979)` |
| Dirichlet, `(infinity,infinity)` | `(-4.013410, -4.013371)` | `(1.002672, 1.002681)` |
| Soft corner, `(0,0)` | `(-4.019143, -4.019104)` | `(1.003818, 1.003826)` |

The strict mass brackets are:

- Physical: `-134373/102400000 < mu < -537487/409600000`.
- Dirichlet: `-134323/102400000 < mu < -537287/409600000`.
- Soft corner: `-1076119/819200000 < mu < -1076109/819200000`.

Each interval has width `1/81920000`. Two independently written interval engines
confirm strict positive and negative endpoint residuals in all three cases.
The engines share Arb arithmetic. The numerical engine checks are not an
independent human review of the analytic correspondence theorem.

## Why the wall-uniform conclusion follows

1. The exact original model, launch-root interval and upper-wall interval are
   copied from the existing certificate. The background coefficient remains
   gamma=20 in every arm. Only perturbative wall conditions change.
2. The unchanged polynomial and exponential engines propagate the full launch
   uncertainty. All Picard inclusions are strict. Each flow checks finite state,
   positive warp, the constraint and first integral, and the complete uncertain
   upper-wall event interval. No midpoint background is substituted.
3. Strict opposite endpoint residual signs give a root for the fixed exact
   background. The inherited one-turn theorem identifies it as the unique root
   below `-4k` for that wall pair.
4. Theorems 1–2 give `mu_soft <= mu <= mu_DD` for the counted root throughout
   the admitted pure and dynamical wall classes. The new corner brackets thus
   enclose every such root.
5. The rate map `rho(x)=sqrt(9/4-x)-3/2` decreases with x. The curvature interval
   is retained when taking the ratio. Exact integer/Fraction square tests verify
   the outward rate endpoints, independently of floating square-root rounding.

The lower bound is exactly `62667/62500`; the upper bound is exactly
`501913/500000`. The strict sign brackets make both displayed uniform
inequalities strict. The ratio is the same for either wall's proper clock.

`METHOD.md` records the boundary adaptation explicitly. In particular, the
Dirichlet launch has `f_a=0`, `psi_a=1` and
`g_a=3*(mu+4*k)/T_a-2*T_a`. Eight exact symbolic identities check the finite-wall
launch, constraint, Dirichlet limit and growth conversion. There is no division
by the scalar derivative at an interior turn.

## Relation to the reviewer estimate and existing evidence

The reviewer's original scratch script, exact six wall choices and outputs were
not recovered. This is a new, preserved reconstruction from the certified model,
not a claim to have replayed that missing scratch calculation. The results agree
with the approximate reported `mu/k` range near `-4.013` to `-4.019` and replace
that unsupported illustration with exact interval statements for the physical
pair and the two corners controlling all admitted walls.

The original mass packet already certified `-0.00132 < mu < -0.00131` for the
physical walls. A fresh replay at its lower endpoint reproduces its determinant
enclosure. The present work narrows the physical bracket and adds the soft and
Dirichlet brackets. It does not rerun the original shooting-root existence proof;
its full certified uncertainty is an inherited input.

## Value and recommended incorporation

The growth law is established prior work, already credited in the manuscript
to Frolov–Kofman. A numerical value for one wall pair would have been a useful
illustration. The wall-uniform numerical margin is the stronger outcome:
it makes the existing qualitative persistence result quantitatively explicit.
It does not establish a new universal growth law or a new nonlinear mechanism.

Recommended manuscript addition after author review:

- Add one short quantitative corollary or paragraph following the certified
  background application, with the physical-pair interval and the uniform
  rate bound. Keep the theorem assumptions explicit.
- Add the physical-pair marker to Figure 1(c); the uncertainty is much narrower
  than the panel's overall scale. A short inset or supplementary rate plot can
  distinguish physical, soft and Dirichlet values if that comparison is useful.
- Put the three-case table, boundary launch, exact mass endpoints, interval
  workflow and claim-to-evidence map in S10. A proposed concise insertion is
  supplied separately in `PROPOSED_INSERTION.md`.
- Add these sources and records to the future public pipeline release during
  the deferred pipeline cleanup. They presently belong to the private Paper A
  research packet; the public pipeline was not modified.

No extra digits are needed to support that addition. A parameter-family-uniform
margin or an explanation of threshold proximity would be a separate research
question, not an automatically launched successor.

## Validation and limits

- Twelve decisive endpoint records pass the exact post-run audit.
- Three brackets reach the declared target width; both engines agree on signs
  and their same-endpoint enclosures overlap.
- Fresh-process physical and Dirichlet replay controls reproduce terminal
  records exactly. Changed fingerprints, parameters, source/input/protocol
  identities, executable identity, precision, thread count and library version
  are rejected by the recorded controls. An incomplete temporary file is ignored.
- The observed interpreter and all 42 native-library identities are checked
  against the pre-run freeze after production.
- One soft-corner midpoint returned an indeterminate interval sign. That record
  is preserved; predeclared quarter-point probes supplied strict signs. It is
  not a physical failure or an obstruction.
- The original analytic mode domain, exact background certificate and counting
  theorems remain explicit premises. No unrestricted Cauchy instability,
  nonlinear endpoint, inflationary lifetime, event horizon or external human
  validation is asserted.

The numerical production finished successfully. Resource observations, final
process closure and the elapsed investigation time are in `CLOSEOUT.json` and
`RESOURCE_CLOSEOUT.json`. The two-hour allowance was a ceiling. The requested
physical and wall-uniform bounds were reached; the run did not stop at a
preparation checkpoint. The article, supplement and public pipeline are unchanged.
