# Scalar instability counts for de Sitter two-brane backgrounds with dynamical wall fields

## Abstract

We establish a scalar instability count for smooth five-dimensional Einstein--scalar two-brane backgrounds with de Sitter slices. Under explicit endpoint signs and the declared original-action mode domain, exactly \(n\) simple radial eigenvalues lie below \(\mu=-4k\), where \(n\) counts interior zeros of the background scalar derivative. Consequently the background has at least \(n\) tachyonic modes in the declared sector, each admitting a homogeneous growing branch faster than de Sitter expansion. The count persists under finitely many local wall fields with nonnegative total potential and kinetic forms, a positive independent-field kinetic block and tangential mixing with the bulk trace. The proof combines regular physical reconstruction, removal of an artificial negative-signature zero, closed-form theory and a monotone Schur response. A positive background coefficient gives a one-turn criterion; in particular, a non-monotone profile in a convex bulk potential has exactly one eigenvalue below the shifted threshold. For a certified quadratic background and two continuous upper-wall parameter families, linked background and zero-mass phase enclosures exclude the remaining negative band, giving exactly one negative eigenvalue throughout the wall class. At flat slicing the threshold is zero and the analytic negative count is complete; excluding massless added wall fields additionally requires a positive independent-field potential block.

**Keywords:** mathematical relativity; Einstein-scalar systems; de Sitter branes; spectral index; dynamical boundary conditions; computer-assisted bounds.

## 1. Introduction {#sec-1}

Boundary matter changes both the spectrum and the physical mode domain of a warped extra dimension. In Einstein--scalar two-brane models, a useful question is therefore not only whether a growing mode exists, but how many negative radial eigenvalues survive after dynamical wall fields are included. The Randall--Sundrum geometry [1] and bulk-scalar stabilization mechanism [2, 3] provide the setting.

We establish a restricted count for a class of smooth de Sitter two-brane backgrounds: under explicit endpoint signs, the number of eigenvalues below the curvature-shifted threshold \(\mu=-4k\) equals the number of interior zeros of the background scalar derivative. This count persists under finite local wall fields with nonnegative total potential and kinetic forms and a positive independent-field kinetic block. Neither assertion requires a numerical phase calculation. A certified background (the anchor) and two continuous upper-wall parameter families supply the stronger application: exactly one negative eigenvalue on the entire negative axis, throughout the stated wall class. That complete count requires a remaining-band phase enclosure as well as the background certificate.

Curved-wall instability, regular scalar-turn variables and wall-stiffness dependence have substantial precedents. Gen and Sasaki [43] and Chacko and Fox [44] obtain the de Sitter radion at \(\mu=-4k\) without a stabilizing field. Contaldi, Kofman and Peloso [45] identify a negative curvature contribution in their warped de Sitter compactification class, equal to \(-4k\) for one extra dimension. Tanaka and Montes [46] conjecture tachyonic modes for non-monotonic stabilizing scalar profiles in their two-brane setting. Frolov and Kofman [4] derive the curved scalar equation and find typically negative radion mass squared for de Sitter branes stabilized by brane potentials. Lesgourgues and Sorbo [5] and Konikowska, Olechowski and Schmidt [6] supply regular-turn variables and stability arguments. Olechowski [7] gives necessary-and-sufficient scalar stability conditions for multibrane Minkowski backgrounds. Girmohanta et al. [8] analyze finite brane potentials and the endpoint terms in a generalized scalar product.

Our contribution is the physical reconstruction and exact restricted count under the hypotheses below, its persistence under the declared frequency-dependent wall response, certified complete counts on an exact background and two upper-wall families, and an exact flat-slice count refining the qualitative results of [5, 6, 7]. The proof uses established Sturm oscillation and closed-form methods [23, 24]. It distinguishes the original-action kinetic norm from an auxiliary indefinite endpoint product and removes the latter's artificial zero before counting physical modes. The count is not a claim that individual eigenvalue branches can be causally identified with particular scalar turns. Detailed equation-level comparisons are in Appendix I. BraneCode evolutions also exhibit departure from unstable stabilized de Sitter configurations [17; Section 5.1 and Figure 5], while Binétruy, Deffayet and Langlois identify the linear radion instability of two de Sitter branes [18; Section 6].

Coupled bulk/brane test scalars [35, 36], Robin boundary oscillators [37], trace kinetic actions [38] and rational eigenparameter-dependent boundary conditions [32, 33, 34] are also established. The present problem includes the coupled gravitational constraints and both physical wall equations. Matter-supported stabilization and matter-induced tachyonicity in other models [9, 10, 11] prevent extrapolating the obstruction beyond our background and wall hypotheses.

Figure 1 separates the restricted count from the remaining-band exclusion and translates the counted masses into growth rates; Figure 2 shows their analytic and numerical dependencies.

Sections 2-4 state the physical domain, restricted theorem, convex-potential consequence, wall-field extension and flat-slice corollary; Section 5 gives the certified background and parameter-family applications. Appendices A-G make the model, counting proof, phase exclusion, numerical predicates and wall variation part of the article; Appendix P gives the flat-slice proof modifications. The supplement provides the full bulk variation, extended comparisons, implementation records, static relaxation and further examples.



![Spectral count schematics and analytic de Sitter growth rate versus dimensionless radial mass squared.](figures/spectral_map.png){#fig:spectral_map}

**Figure 1.** Spectral scope and growth-rate interpretation. Panels (a)--(b) are schematic: ticks and the ellipsis count roots without specifying their masses; Theorems 1--2 place each counted root in its static bracket. For the certified one-turn example, Proposition 1 also excludes \((-4k,0)\) and pure-potential zero modes; massless wall spectators are not excluded. Panel (c) plots the exact growing-branch relation \(r_i/h_i=\rho(\mu/k)\), not measured eigenvalues. The counted region has \(\rho>1\); the remaining negative band has \(0<\rho<1\). The point \((-4,1)\) gives the unstabilized radion rate [43, 44, 4], while our admitted backgrounds exclude a root at that threshold. A decaying solution branch also exists. Section S10 derives the conversion and its scope.



![Dependency graph separates analytic results, anchor certificates and parameter-uniform family predicates.](figures/proof_dependencies.png){#fig:proof_dependencies}

**Figure 2.** Logical dependencies. Solid-outline boxes denote analytic statements; hatched boxes denote numerical premises. The general endpoint hypotheses lead to Theorem 1 and then Theorem 2. For the selected quadratic model, the background certificate and Lemma 1 give the one-turn hypotheses, and the phase certificate completes Proposition 1. The family corollary additionally requires parameter-uniform background and phase predicates, root identification and seam checks in Appendix O.6. The action variation and physical-domain correspondence are proved in Appendix G, Appendix J and Appendices K-L.

## 2. Action, background and physical mode domain {#sec-2}

### 2.1. Action and backgrounds {#sec-2.1}

Use signature \((-++++)\), units \(\ell=\kappa_5=1\), a reflected doubled bulk cover and walls at the ends of a compact proper-distance interval \([0,D]\). The background contains a real bulk scalar and pure wall potentials, with no charged matter or wall-field excitation; we call this a neutral background. Its action is

\[
S=\int_{\widetilde{\mathcal M}}\sqrt{-g}
\left[\frac{R+12}{2}-\frac12(\nabla\Phi)^2-V(\Phi)\right]d^5x
-\sum_{i=a,b}\int_{\Sigma_i}\sqrt{-h_i}\,\tau_i(\Phi)\,d^4x.
\tag{1}
\]

The interval formulation includes the Gibbons--Hawking terms [25] with the doubled bulk normalization and the signed joint terms where needed [26]. Wall embeddings are varied before gauge fixing. The finite wall-field action in Section 4 replaces the potential-only wall terms while matching their background values and slopes.

\[
ds_5^2=a(s)^2\gamma_{k,\alpha\beta}dx^\alpha dx^\beta+ds^2,
\quad \operatorname{Ric}(\gamma_k)=3k\gamma_k,\quad h=\sqrt{k}>0.
\tag{8}
\]

Assume a smooth potential and a smooth solution with \(a>0\), \(k>0\), \(H=a'/a\) and \(T=\Phi_0'\), satisfying the background equations, including the Hamiltonian constraint:

\[
\begin{gathered}
a'=Ha,\qquad \Phi_0'=T,\qquad
H'=-T^2/3-k/a^2,\qquad T'=V_{,\Phi}-4HT,\\
H^2-1-T^2/12+V/6-k/a^2=0.
\end{gathered}
\tag{9}
\]

The warp normalization \(a(0)=1\) may be chosen. The slice expansion rate \(h=\sqrt{k}\), radial gradient \(H\), and positive auxiliary \(\mathfrak h\) used in Appendix K are distinct.

### 2.2. Junctions, sector and admissibility {#sec-2.2}

With inward orientations \(\sigma_a=+1\), \(\sigma_b=-1\), the reflected Darmois--Israel and scalar laws [13, 14, 15] are

\[
K_{ab}=-\frac12\left(S_{ab}-\frac{S}{3}h_{ab}\right),\qquad
S_{ab}=-\tau h_{ab},\qquad 2n\cdot\partial\Phi=\tau_{,\Phi}.
\tag{4}
\]

Each wall occurs once against two bulk copies. The reflection condition makes the averaged normal-evolution equation redundant; it does not remove either local junction row [16; Sections II--III]. The background wall values and slopes are matched, and their perturbative Hessians \(\kappa_i\) may vary without changing the background.

Let \(\Box_{\gamma_k}Q=\mu Q\) with nonzero traceless Hessian. Work in this generic, reflection-preserving scalar sector, retaining the wall graphs until the varied Israel equations are imposed. In the regular longitudinal representative, \(\lambda=\mu+4k\) and the profiles obey

\[
\begin{aligned}
\psi'&=-2H\psi-Tf/3,\qquad f'=g,\\
g'&=-4Hg+(V_{,\Phi\Phi}-\mu/a^2+2T^2)f
+(12HT-4V_{,\Phi})\psi,\\
0&=Tg-T'f+(2T^2-3\lambda/a^2)\psi.
\end{aligned}
\tag{10}
\]

Set \(L=g+2T\psi\). Pure-potential walls impose \(L_a=\kappa_af_a/2\), \(L_b=-\kappa_bf_b/2\), with \(\kappa_i\in[0,\infty]\); infinity means \(f_i=0\). The physical domain consists of global distributional solutions with these traces and finite kinetic norm

\[
Z_A=2\int_0^D a^2\left(|f|^2+6|\psi|^2\right)ds>0.
\tag{11}
\]

The kinetic pullback assumes vanishing four-dimensional surface flux. The equations remain regular at a scalar turn and force the classical regularity needed for endpoint traces; finite norm alone would not exclude a glued derivative jump. Appendix J supplies the full bulk and pure-wall action derivation; Appendix G derives the added wall-field rows. Appendices K-L establish the regular transformation and weak-domain/classical-mode correspondence, including the exclusion of derivative jumps at scalar turns. These physical-domain hypotheses are retained in every theorem below. No unrestricted Cauchy-data space is identified with the auxiliary spectral space.

## 3. Restricted instability count {#sec-3}

### 3.1. Endpoint hypotheses and theorem {#sec-3.1}

In addition to Section 2, assume

\[
T_a<0<T_b,\qquad T'_a>0,\quad T'_b>0.
\tag{RT1}
\]

Let \(n\) be the number of interior zeros of \(T\). The background identity \((a^4T')'=a^4\mathcal QT\), with \(\mathcal Q=V''+4k/a^2+4T^2/3\), makes every zero simple unless \(T\) vanishes identically. The nonzero endpoints and uniqueness for this regular linear equation imply finitely many zeros. Under (RT1), \(n\) is positive and odd.

**Theorem 1 — restricted radial index.** Under Section 2 and (RT1), the pure-potential separated spectrum is real, discrete, bounded below and simple for every \((\kappa_a,\kappa_b)\in[0,\infty]^2\). There is no eigenvalue at \(\mu=-4k\), and exactly \(n\) eigenvalues lie below it. The ordered eigenvalues \(\alpha_0<\alpha_1<\cdots\) are continuous on the compactified wall square, nondecreasing in each stiffness and strictly increasing at finite stiffness. For \(0\le j<n\),

\[
\alpha_j(0,0)\le\alpha_j(\kappa_a,\kappa_b)
\le\alpha_{j,DD}<-4k,\qquad
\alpha_{j,DD}:=\alpha_j(\infty,\infty).
\tag{RT2}
\]

**Proof.** Appendix K constructs \(F=f+(T/\mathfrak h)\psi\), where \(\mathfrak h=v'/(2v)>0\), without dividing by \(T\) or \(H\). For \(\lambda\ne0\) its undivided scalar pencil is equivalent to the physical problem, including all finite endpoint poles. The auxiliary product has one negative direction. Its simple zero mode \(F_0=T/(a^2v')\) has negative signature and no physical inverse at \(\lambda=0\); a separate physical wall/energy argument excludes that threshold. Appendix L supplies the exhaustive entire characteristic and simplicity.

The fixed Robin comparison problem in Appendix M has \(F_0\) as a zero eigenfunction with \(n\) nodes. Sturm oscillation [23] gives negative index \(n\). Adding positive endpoint squares preserves that index. Removing the artificial negative-signature kernel leaves a uniformly positive complement, on which the closed form has compact resolvent [24]. Its nonzero spectrum, including multiplicities, is the physical spectrum shifted by \(4k\). The constrained Dirichlet form domains give the same index on both wall faces. Variational comparison gives the ceilings, and the norm response
\(\partial_{\kappa_i}\alpha_j=a_i^4|f_i|^2/Z_A>0\)
gives strict finite-stiffness monotonicity. At a finite endpoint \(f_i=0\), the wall row and constraint would force the entire nonthreshold mode to vanish. Compactified characteristic continuity completes the assertion. \(\square\)

This theorem counts only \(\mu<-4k\). It neither excludes additional eigenvalues in \((-4k,0)\) nor assumes the phase enclosure used later. No sign condition on \(H\) or convexity condition on \(V\) is added to its hypotheses. The endpoint assumptions (RT1) are not relaxed to same-sign endpoints here.

**Growth-rate interpretation.** On wall \(i\), the physical mass squared is \(m_i^2=\mu/a_i^2\) and the de Sitter expansion rate is \(h_i=\sqrt{k}/a_i\). The homogeneous growing branch has
\[
\frac{r_i}{h_i}=\rho(\mu/k),\qquad
\rho(x)=-\frac32+\sqrt{\frac94-x}>1\quad(x<-4).
\]
Thus every counted radial mode admits growth faster than expansion, for all wall pairs in Theorem 1 and all finite wall systems in Theorem 2. The growth formula is standard [4; Eq. (21)]; the exact count and uniform strict bound are the consequences here. Figure 1(c) shows this conversion. Section S10 gives the proper-time derivation, rate brackets and distinction from an unrestricted initial-value instability theorem.

### 3.2. An analytic sufficient condition for one turn {#sec-3.2}

**Lemma 1 — one turn and positive derivative.** If \(\mathcal Q>0\) throughout the interval and \(T_a<0<T_b\), then \(T\) has exactly one simple interior zero and \(T'>0\) everywhere. Thus (RT1) and \(n=1\) follow.

**Proof.** Between two zeros, multiplication of \((a^4T')'=a^4\mathcal QT\) by \(T\) and integration gives
\(-\int a^4(T')^2=\int a^4\mathcal QT^2\), a contradiction. A double zero would force \(T\equiv0\). At the unique crossing \(s_0\), \(T'(s_0)>0\). The function \(a^4T'\) decreases to that positive value on the left, where \(T<0\), and increases from it on the right, where \(T>0\). Hence \(T'>0\) on the closed interval. \(\square\)

For \(V''\ge0\), positivity of \(k\) ensures \(\mathcal Q>0\). The condition also permits some concave potentials; the supplement gives a separate example. On the certified quadratic background below, the endpoint signs of \(T\) remain numerical inputs, but the positive derivative signs follow analytically from this lemma.

**Corollary (convex non-monotone backgrounds).** Let a background in Section 2 have \(V''\ge0\) along its scalar range and a non-monotone scalar profile. After reversing the scalar orientation if necessary, (RT1) holds with \(n=1\). Consequently there is exactly one radial eigenvalue below \(-4k\) for every wall pair of Theorem 1 and every finite wall system of Theorem 2. Additional eigenvalues in \((-4k,0)\) are not excluded.

**Proof.** Positivity of \(\mathcal Q\) and the between-zeros argument in Lemma 1 allow at most one zero of \(T\), including endpoints. Non-monotonicity supplies an interior zero; uniqueness makes it simple. Choose scalar orientation so that it crosses from negative to positive; the relabeling preserves the hypotheses and spectrum (Section S10.3). Both endpoints are then nonzero with opposite signs, and Lemma 1 gives \(T'>0\) throughout. Theorems 1--2 apply. \(\square\)

## 4. Persistence under finite local wall fields {#sec-4}

### 4.1. Action class and restricted count {#sec-4.1}

Use a background satisfying Theorem 1. At each wall let \(z_i=(\Phi|_{\Sigma_i}-\Phi_i^*,\chi_i)\), with finitely many independent real scalars \(\chi_i\in\mathbb R^{n_i}\). The first component is the bulk scalar trace, not a new independent boundary variable. Replace the wall scalar potential and kinetic terms by

\[
\begin{gathered}
\mathcal L_i=-U_i(z_i)-\tfrac12 h_i^{ab}(D_a z_i)^T\mathsf K_i(z_i)D_bz_i,\\
\mathsf H_i=D^2U_i(0)\ge0,\qquad \mathsf K_i=\mathsf K_i(0)\ge0,
\qquad M_i=(\mathsf K_i)_{\chi\chi}>0.
\end{gathered}
\tag{FW1}
\]

The matrices are real symmetric; the last condition is empty when \(n_i=0\). Match \(U_i(0)\) and \(U_{i,0}(0)\) to the original wall value and scalar slope, and set \(U_{i,\chi}(0)=0\). Thus the exact background is unchanged. The Hessian \(\mathsf H_i\) is the total potential Hessian, including the original tension. Only tangential first derivatives occur: normal-derivative terms, induced curvature, cross-wall interactions and nonzero tangential background gradients are excluded.

Varying the embeddings before imposing longitudinal gauge leaves the inherited generic tracefree Israel consequence unchanged: the added centered terms have no first-order stress. In that representative \(z_i=(f_i,u_i)\). With \(x_i=-\mu/a_i^2\) and \(\mathsf Q_i=\mathsf H_i+x_i\mathsf K_i\), the undivided scalar rows and physical norm are

\[
\begin{gathered}
2\sigma_iL_i=(\mathsf Q_i z_i)_0,\qquad
(\mathsf Q_i z_i)_\chi=0,\\
Z_{\mathrm{new}}=Z_A+\sum_i a_i^2z_i^\dagger\mathsf K_i z_i>0.
\end{gathered}
\tag{FW2}
\]

The wall sees the physical mass squared \(\mu/a_i^2\), not the shifted gravitational parameter. The undivided Green identity, paired with the complex conjugate, gives \((\mu-\bar\mu)Z_{\mathrm{new}}=0\); positivity also holds for a nonzero pure-wall profile by \(M_i>0\). Appendix G gives the variation and identity in detail.

**Theorem 2 — finite local wall-field persistence.** Under Theorem 1's hypotheses, every finite wall system (FW1) has exactly \(n\) eigenvalues below \(-4k\), each real and simple, and none at \(-4k\). For \(j=0,\ldots,n-1\), the corresponding root satisfies

\[
\alpha_j(0,0)\le\mu_j\le\alpha_{j,DD}<-4k.
\tag{FW3}
\]

Thus these wall fields cannot remove all negative radial eigenvalues in the declared sector. The statement requires no phase enclosure and makes no count assertion in \((-4k,0)\).

**Proof.** For \(\mu<0\), put \(B_i=(\mathsf H_i)_{\chi\chi}+x_iM_i>0\), \(c_i=(\mathsf Q_i)_{\chi0}\) and \(v_i=(1,-B_i^{-1}c_i)^T\). The independent rows give \(z_i=f_iv_i\), so the bulk problem has effective Hessians

\[
\begin{gathered}
\Gamma_i(\mu)=(\mathsf Q_i)_{00}-c_i^TB_i^{-1}c_i\ge0,\\
\Gamma_i'(\mu)=-a_i^{-2}v_i^T\mathsf K_i v_i\le0.
\end{gathered}
\tag{FW4}
\]

The first inequality is Schur positivity; differentiation of the minimized quadratic form gives the second. Empty blocks have their natural meaning. For each \(j<n\), the function \(F_j(\mu)=\alpha_j(\Gamma_a(\mu),\Gamma_b(\mu))\) is continuous and nonincreasing. On the interval \(I_j=[\alpha_j(0,0),\alpha_{j,DD}]\), it takes values in \(I_j\), so \(F_j-\mu\) changes weak sign between the endpoints and is strictly decreasing. It has exactly one root. Outside \(I_j\), the same bounds exclude another root on that branch. For \(j\ge n\), the static eigenvalue is above \(-4k\), so no such branch contributes a root below the threshold. Distinct branches cannot share a root, since the static spectrum at the same effective wall pair is simple.

Every negative full mode reduces to a static fixed point. No negative pole or pure-wall negative mode is lost because \(B_i>0\), including at \(\mu=-4k\). Theorem 1 therefore also excludes a full threshold mode. At each restricted root the physical Hessian response yields

\[
1-F_j'(\mu_j)=Z_{\mathrm{new}}/Z_A>0.
\tag{FW5}
\]

The simple static characteristic and the nonvanishing factor \(\det B_a\det B_b\) give algebraic as well as geometric simplicity. Reality follows from the undivided Green identity. This proves the restricted count and (FW3). \(\square\)

The result includes coupled wall scalars, kinetic mixing with the bulk trace, a localized trace kinetic term and semidefinite restoring Hessians. It counts negative radial eigenvalues; massless wall fields and nonnegative wall poles must still be retained in the undivided theory. It supplies no general mode-basis or Cauchy-instability theorem. The canonical oscillator specialization is proved in supplementary Section S5.3. Sections S4-S7 give the normal form, static-count reduction, its rank-loss qualification, and detailed examples and asymptotics. Rational eigenparameter-dependent boundary conditions and localized brane kinetic terms have established precedents [32, 33, 34]; the contribution here is the action-derived realization and restricted count under the stated background hypotheses.




Figure 3 illustrates the wall response and the rank-loss qualification using exact finite-dimensional formulas.

![Exact response formulas for a mixed wall system, a semidefinite system and a rank-loss family on logarithmic x axes.](figures/wall_response.png){#fig:wall_response}

**Figure 3.** Plots of the exact finite-dimensional response formulas, with \(x=-\mu/a_i^2>0\); these are not numerically solved eigenvalue branches. Left: the mixed-matrix response (EX2), with relaxed value \(7/3\) and large-\(x\) slope \(8/5\). Middle: \(\Gamma=x/(1+x)\). Right: \(\Gamma=x/(\varepsilon^2+x)\) approaches the rank-loss response \(\Gamma\equiv1\) at positive \(x\), while its relaxed value is zero for every \(\varepsilon>0\). The noncommuting limits explain the continuity qualification in supplementary Section S4.3.

### 4.2. Flat-slice corollary {#sec-4.2}

**Corollary (flat slices).** Replace the de Sitter slices by Minkowski slices, set \(k=0\), and retain the generic-harmonic, vanishing four-dimensional surface-flux and physical-domain assumptions of Section 2 together with (RT1). For every nonnegative pure-potential wall pair, including Dirichlet faces, there are exactly \(n\) simple negative radial eigenvalues and no massless radial mode. The stiffness monotonicity and static brackets of Theorem 1 hold with ceiling \(\alpha_{j,DD}<0\). Every finite wall system (FW1) also has exactly \(n\) simple negative eigenvalues, with the brackets of Theorem 2. For the enlarged wall system, exclusion of massless modes additionally follows if each independent-field potential block \((\mathsf H_i)_{\chi\chi}\) is positive definite; each vector in the kernel of such a block instead gives a massless wall spectator.

**Proof.** The reduction and index proof use \(\lambda=\mu+4k\), not positivity of \(k\). At \(k=0\), \(\lambda=\mu\), so the restricted count covers the entire negative axis and the separate threshold argument excludes pure-potential zero modes. The negative-axis Schur argument still applies; its zero-mass extension needs the additional potential-block condition just stated. Appendix P supplies the proof and sector qualifications. No remaining-band phase certificate is required. \(\square\)

The qualitative instability of turning flat backgrounds and the zero-mode criteria have established precedents [5, 6, 7]. The refinement here is the exact count, its stiffness bounds and persistence within the declared finite-wall class; the regular reconstruction also requires no nonvanishing warp-gradient assumption at scalar turns (Section S2). We do not claim the first flat-background instability criterion. Supplementary Section S9 gives exploratory one-turn and three-turn illustrations, separately from an interval-enclosed flat background.

## 5. Certified complete-count application {#sec-5}

The restricted theorem does not settle the remaining negative band. For the anchor background, take the quadratic bulk and wall potentials with the six exact rational parameters and launch and wall-distance enclosures in Appendix A. The linked background certificate establishes a smooth positive warp, \(k>0\), and \(T_a<0<T_b\), with the full launch and endpoint uncertainty retained. Lemma 1 gives \(n=1\) and \(T'>0\) analytically. The physical quadratic-wall model has perturbative Hessians \((\kappa_a,\kappa_b)=(20,20)\). The phase certificate is evaluated at the soft corner \(\kappa_a=\kappa_b=0\); Appendix N.2 transfers its exclusion to the physical pair and the full nonnegative wall square while preserving the background values and slopes.



Figure 4 illustrates the scalar turn of the certified background.

![Archived scalar profile and derivative between the walls; one scalar minimum and a derivative zero are marked.](figures/background_turn.png){#fig:background_turn}

**Figure 4.** Archived numerical profile of the certified model, plotted from stored multiprecision samples. Curves are not interval enclosures, and the marked minimum is a sampled location. The one-turn conclusion and \(T'>0\) follow from Lemma 1 and the certified endpoint signs, not from the plotted samples. The scalar turn is not a geometric throat.

**Proposition 1 — certified complete count.** Conditional on the linked background and outward-arithmetic phase predicates in Appendix O.1-O.5, every nonnegative pure-potential Hessian pair, including its Dirichlet faces, has exactly one simple negative radial eigenvalue and no massless radial mode in the declared generic coupled sector. Every finite wall system (FW1) on that background also has exactly one simple negative eigenvalue. Its mass obeys

\[
\alpha(0,0)\le\mu_*\le\alpha_{DD}<-4k.
\tag{12}
\]

The enlarged wall theory may retain massless wall fields; the no-massless assertion is for the pure-potential problem.

**Proof.** Theorem 1 and Lemma 1 give one root below \(-4k\). At physical zero mass and zero perturbative Hessians, the regular launch is

\[
(\psi_a,f_a,g_a)=(1,-12k/T'_a,-2T_a),\qquad \theta_a=3\pi/2.
\tag{13}
\]

The phase \(\theta\) is the continuously lifted physical phase of Appendix N. The identified whole-cell interval flow and full uncertain-wall enclosure give

\[
\frac{\theta_b(0)}{\pi}\in
\left[\frac{577838035}{536870912},\frac{577858823}{536870912}\right]
\subset(1,3/2).
\tag{14}
\]

Appendix N shows that this excludes the first additional negative-band crossing and a massless root at the soft corner. Any extra negative root at another nonnegative wall pair would continue toward that corner with decreasing mass; simplicity, compact wall continuation and the uniform spectral barriers prevent escape or merger. A massless root away from the corner enters the same negative band along that path. Both contradict (14). This completes the pure-potential count. Negative-axis Schur reduction then identifies every full-wall negative mode with a pure-potential root at its own effective nonnegative Hessians. There is only the one branch, and Theorem 2 supplies its unique root and bracket. \(\square\)



Figure 5 displays the whole-cell phase enclosures and the clipped wall-event pieces.

![Whole-cell lifted-phase enclosures from two implementations, with a magnified comparison of clipped uncertain-wall event pieces and the published phase hull.](figures/certified_phase.png){#fig:certified_phase}

**Figure 5.** Archived certified phase enclosures at physical \(\mu=0\) and zero perturbative wall Hessians. Left: each horizontal interval band is a whole-cell angle enclosure; both implementations are drawn through \(D_+\), with the last cell clipped horizontally. The \(L<0\) chart applies after the first cell; the launch is \(3/2\). Right: the two clipped event pieces from each implementation and the published uncertain-wall hull (14), rather than the grid endpoint beyond the wall. Its upper bound leaves a margin exceeding \(0.42365\) to \(3/2\). The two implementations give identical event enclosures piece for piece; corresponding rows in panel (b) therefore have identical extents. Implementations A and B share Arb arithmetic; their agreement is not arithmetic independence.

The numerical chain has two distinct tasks: establish the exact background and its input linkage, then exclude the remaining band on that background. Appendix O gives the interval-Newton, whole-cell flow, phase-lift and uncertain-endpoint predicates. Agreement between two recurrence implementations shares Arb arithmetic [31] and the same mathematical formulation; arithmetic independence is not claimed. Saved-record consistency or a terminal determinant sign alone does not establish these predicates.

**Table 6. Numerical dependencies of the complete-count application.**

| Input | Required output | Consequence |
|---|---|---|
| Six exact rational action parameters and frozen shooting box | Existence and uniqueness of the linked local root; positive warp and curvature; opposite endpoint signs of \(T\); full launch and wall-distance enclosures | An exact background to which Lemma 1 and Theorem 1 apply |
| That same background enclosure and physical zero-mass, zero-Hessian launch | Whole-cell inclusions, continuously lifted phase and complete uncertain-endpoint coverage giving (14) | Exclusion of the remaining negative band and pure-potential massless roots |
| Interval-valued upper-wall parameter and each frozen launch box | Parameter-uniform background and phase predicates; containment of the archived root at the anchor; monotonicity and overlapping launch boxes at each seam (Appendix O.6) | The same complete count on each stated continuous family branch |

### 5.1. Certified parameter families {#sec-5.1}

**Corollary (certified families).** Fix \(m^2,\gamma,v_0,\lambda_a\) at their exact values in Appendix A. Conditional on the parameter-uniform predicates and seam checks in Appendix O.6, the conclusions of Proposition 1 hold on each of the following continuous branches through that background: \(\lambda_b\in[-60529/10000,-60229/10000]\) with \(v_1\) fixed, and \(v_1\in[43/500,99/1000]\) with \(\lambda_b\) fixed. The fixed upper-wall parameter always takes its Appendix A value. Each member has its own background, curvature \(k>0\), wall position and static eigenvalue brackets.

**Proof.** Uniform root and geometry enclosures give \(T_a<0<T_b\), positive warp and \(k>0\); the quadratic bulk potential gives Lemma 1. Both phase implementations enclose the terminal phase strictly between \(\pi\) and \(3\pi/2\) on every accepted parameter subinterval. The proof of Proposition 1 therefore applies pointwise. Local uniqueness and the seam argument in Appendix O.6 join the roots into the asserted continuous branches. \(\square\)

Figure 8 displays both certified families and the uncertified gaps.

![Parameter-uniform terminal phase enclosures for two upper-wall families, distinguishing the anchor-connected branches, other certified pieces and gaps.](figures/certified_families.png){#fig:certified_families}

**Figure 8.** Saved parameter-uniform enclosures of \(\theta_b(0)/\pi\). Top panels show the full distance to the exclusion threshold \(3/2\); lower panels magnify the enclosures. Each rectangle covers a full parameter subinterval and the hull of both phase engines. Blue pieces connect to the original background (vertical dotted line); orange pieces are certified but not joined to that branch across the two hatched gaps. The corollary uses the full blue tension segment and only the blue centre segment. No interpolation crosses a failed cell. The engines share Arb arithmetic. These are enclosures, not a plot of measured eigenvalues.

The tension run certified 30 of 30 subintervals; the centre run certified 62 of 64, of which the first 13 form the anchor-connected segment. The remaining certified centre segments are \([0.100,0.147]\) and \([0.148,0.150]\), without a proved connection to the anchor. These are separate one-parameter families, not a certified two-dimensional neighbourhood. Supplementary Section S8 retains the controls, gaps and failed anchor-row cells of the separate two-parameter attempt.

## 6. Scope and conclusion {#sec-6}

Under the endpoint signs (RT1), the restricted radial count equals the number of scalar-derivative zeros and persists under the declared finite wall fields. This analytic obstruction is independent of the remaining-band computation. The certified quadratic background and two continuous upper-wall parameter families give the stronger complete negative count, conditional on their background and phase premises. The flat-slice corollary gives a complete analytic count under its own domain and endpoint assumptions, with no remaining negative band to certify.

For a convex bulk potential, a non-monotone scalar profile therefore cannot be stabilized by the admitted wall modifications. Monotonicity is necessary for scalar radial stability within this class, but sufficiency is not established here; neither a nonlinear lifetime nor an identification with the unstabilized radion follows from the count.

The supplement also proves a static-relaxation identity: under its explicit separated-spectrum hypotheses, the full negative count equals the static count at the wall potentials minimized over independent fields. Kinetic changes at fixed potential therefore preserve the count, although masses and growth rates change. Potential paths require continuity of those relaxed Hessians; a rank-loss counterexample shows why that qualification matters.

The results concern radial eigenvalues in the generic scalar sector. They do not count exceptional harmonics, vector or tensor sectors, harmonic multiplicities or a full Cauchy unstable manifold. A positive physical kinetic coefficient does not imply positive restoring energy. The flat extension retains the generic-sector and surface-flux restrictions and its additional zero-mode qualification. Anti-de Sitter slices, same-sign endpoint extensions, other wall actions and nonlinear evolution require separate arguments.

## Supplementary Material

The supplement contains the full bulk action and gauge reconstruction, detailed literature comparisons, implementation and saved-record guidance, static relaxation with its rank-loss qualification, oscillator and matrix examples, inertia asymptotics, a separate concave-background example, parameter-family records, flat-slice illustrations and the growth-rate derivation. The restricted-index proof, complete-count phase argument, numerical predicates and finite-wall variation are in the article appendices. The article and supplement have distinct equation and reference numbering with linked locators.

## Acknowledgements

The author acknowledges Chunshan Lin’s work [47] as an inspiration for the broader research program from which this study developed. The present investigation addresses a distinct mathematical problem. The author is also grateful to Hazel for her steadfast support, patience and encouragement throughout the research process.

No funding was received for this work.

**AI disclosure.** OpenAI Codex and Anthropic Claude were used to develop and check mathematical derivations, generate and execute computational code, compare sources, and draft and revise text and figures. AI agents carried out the parameter-family computations and flat-slice extension and contributed to the growth-rate and convexity derivations. The author retains responsibility for the claims, source verification and final text. The action-to-mode derivation received a separate blind agent re-derivation; the family computations and flat extension were research contributions, not independent reviews. Agent scrutiny is not external human peer review. The supplement distinguishes recorded numerical premises from the checks performed on their saved records.

## Author declarations

**Conflict of interest.** The author has no conflicts of interest to disclose.

## Data availability

Exact model inputs and the numerical predicates are stated in the article appendices; implementation records are described in the supplement. Supporting source and frozen numerical records are versioned in the [public research pipeline](https://github.com/RonBibb/persistence-of-a-certified-scalar-instability-under-dynamical-interface-matter-pipeline/tree/2e3cf97652cfac80dd89010b7368aa9015331c28). The records distinguish interval-producer executions from saved-record verification. The latter checks do not by themselves regenerate the interval trajectories or establish all the predicates of Appendix O.

## Appendix A. Exact anchor background {#app-A}

The central bulk and wall potentials are \(V=m^2\Phi^2/2\), \(\tau_a=\lambda_a+\gamma(\Phi-v_0)^2/2\), \(\tau_b=\lambda_b+\gamma(\Phi-v_1)^2/2\), with the six exact rational inputs in Table 4.

**Table 4. Exact action parameters; all values are dimensionless in the stated units.**

| Parameter | Exact value |
|---|---|
| \(m^2\) | \(7385903388887613/18014398509481984\) |
| \(\gamma\) | \(20\) |
| \(v_0\) | \(3602879701896397/36028797018963968\) |
| \(v_1\) | \(6520040733916207/72057594037927936\) |
| \(\lambda_a\) | \(6755388606266369/1125899906842624\) |
| \(\lambda_b\) | \(-851862101055633/140737488355328\) |

The linked exact root satisfies

\[
\begin{gathered}
\Phi_0(0)\in
\left[\frac{456607025194779413}{4611686018427387904},
\frac{114151756532473697}{1152921504606846976}\right],\\
D\in[32727/16384,32729/16384].
\end{gathered}
\tag{31}
\]

The centered traces \(\Phi_i^*\) used in the finite wall action belong to this exact solution. The phase calculation propagates the full launch and endpoint uncertainty. Zero perturbative Hessians (13) preserve the background values and slopes, with \(\gamma=20\) unchanged in the shooting map.

## Appendix B. Regular scalar reduction and its physical domain {#app-K}

This section derives the regular transformation used in Theorem 1 and Proposition 1. All derivatives are in proper distance. The auxiliary \(v\) used here is strictly positive at both walls; the lower-vanishing phase-anchor solution in Appendix N is a different function. We prove equivalence of classical solutions and traces, not equivalence of full closed Hilbert-space domains.

### B.1. Starting identities {#app-K.1}

Use proper distance \(s\), \(a>0\), \(H=a'/a\), \(T=\Phi'\), and \(\lambda=\mu+4k\). Define \(L=g+2T\psi\) and

\[
\mathcal Q=V''+4k/a^2+4T^2/3.
\]

The original constrained system is equivalently

\[
\psi'=-2H\psi-Tf/3,\quad
f'=L-2T\psi,\quad
L'=-4HL+(\mathcal Q-\lambda/a^2)f-2T'\psi,
\tag{J1}
\]
\[
TL-T'f=3\lambda\psi/a^2.
\tag{J2}
\]

The background implies
\[
T''+4HT'=\mathcal QT.
\tag{J3}
\]
For example, differentiating \(L=g+2T\psi\) and using \(T'=V'-4HT\) gives the last equation of (J1) with no division. These identities hold at scalar turns.

### B.2. Positive auxiliary function {#app-K.2}

Choose any solution v of
\[
v''+2Hv'-2T^2v/3=0,
\qquad v(0)>0,\quad v'(0)>0.
\tag{J4}
\]
It is globally finite on the compact interval because this is a regular linear equation. While v>0,
\[
(a^2v')'=2a^2T^2v/3\ge0.
\]
Thus \(v'\) stays positive, so \(v\) cannot have a first loss of positivity. In particular
\[
\mathfrak h=\frac{v'}{2v}>0,\quad
\mathfrak h'=-2H\mathfrak h-2\mathfrak h^2+T^2/3
\tag{J5}
\]
is regular and bounded away from zero on this fixed compact interval. No sign of \(H\) is required.

Set
\[
C=\frac{T^2}{3\mathfrak h},\qquad
B=T'-\frac{T^3}{3\mathfrak h}=T'-CT,
\qquad R=2H-C,
\tag{J6}
\]
\[
U=\mathcal Q-\frac{4TT'}{3\mathfrak h}-\frac{2HT^2}{\mathfrak h}
-\frac{2T^2}{3}+\frac{2T^4}{9\mathfrak h^2}.
\tag{J7}
\]
Direct use of (J3),(J5) gives the division-free identity
\[
B'+(2H+R)B=TU.
\tag{J8}
\]
The displayed smooth formula (J7), rather than the formal quotient of (J8) by \(T\), defines \(U\) at turns.

### B.3. Transformation and inverse {#app-K.3}

Define
\[
F=f+\frac{T}{\mathfrak h}\psi.
\tag{J9}
\]
Equations (J1),(J5) imply
\[
F'=L-Cf+\frac{B}{\mathfrak h}\psi,
\quad TF'-BF=3\lambda\psi/a^2,
\quad \psi'=-R\psi-TF/3.
\tag{J10}
\]
Differentiate the middle equality, substitute the last equality and (J8), and simplify. The result is
\[
F''+4HF'+(\lambda/a^2-U)F=0,
\quad\text{or}\quad
-(a^4F')'+a^4UF=\lambda a^2F.
\tag{J11}
\]
No curvature approximation or substitution into a flat factorization has been made. The coefficients p=a^4 and w=a^2 are strictly positive; the potential a^4U is regular.

For \(\lambda\ne0\) the inverse is
\[
\psi=\frac{a^2}{3\lambda}(TF'-BF),\quad
f=F-\frac{T}{\mathfrak h}\psi,\quad g=f'.
\tag{J12}
\]
For completeness, differentiating the first expression and using (J8),(J11) gives exactly \(\psi'=-R\psi-TF/3\), without dividing by \(T\). The definition of f then gives (J10) and (J2), with \(L=f'+2T\psi\). Differentiation of (J2) supplies the remaining equation (J1) away from zeros of \(T\); continuity supplies it at those zeros. The nonzero endpoints exclude \(T\equiv0\). Uniqueness for the regular linear background equation (J3) makes every zero of \(T\) simple; compactness and nonzero endpoint values then make their number finite. Thus this extension has no exceptional interval. Consequently (J9),(J12) give a linear bijection between the two-dimensional classical constrained solution space and the two-dimensional classical solution space of (J11), for each \(\lambda\ne0\), including negative \(\lambda\) and any nonzero wall pole below.

A pointwise determinant check makes the absence of lost local data explicit. For \(\lambda\ne0\), put \(\alpha=a^2/(3\lambda \mathfrak h)\). Using the constraint to eliminate \(\psi\), the map between constrained initial-data pairs factors as
\[
\begin{pmatrix}F\\F'\end{pmatrix}
=
\begin{pmatrix}1&0\\-C&1\end{pmatrix}
\begin{pmatrix}
1-\alpha TT'&\alpha T^2\\
-\alpha(T')^2&1+\alpha TT'
\end{pmatrix}
\begin{pmatrix}f\\L\end{pmatrix}.
\tag{J13}
\]
The first matrix has determinant one, and the second has determinant
\[
(1-\alpha TT')(1+\alpha TT')+\alpha^2T^2(T')^2=1.
\]
Thus the full pointwise map is invertible, including at \(T=0\) or \(H=0\). Its coefficients still depend singularly on \(\lambda\) at zero; this check neither extends the inverse to that parameter nor identifies unrestricted function-space norms.

This is a solution-domain equivalence. It does not assert a uniform bounded invertible transformation on the entire unconstrained \(H^1\) space; the inverse contains F' and \(1/\lambda\). On compact spectral sets away from zero, it is an ordinary regular differential map on the displayed classical solution spaces. Its dependence on \(\lambda\) is analytic there.

### B.4. Exact transformed walls and their poles {#app-K.4}

At a finite wall write \(L_i=r_if_i\), with
\[
r_a=\kappa_a/2,\quad r_b=-\kappa_b/2,\quad
E_i=T'_i-r_iT_i.
\tag{J14}
\]
The stated endpoint hypotheses give \(E_a,E_b>0\), including zero Hessians. All quantities in the following wall formulas are evaluated at that wall. Substitution in (J10) yields the **undivided** condition
\[
(3\mathfrak h\lambda-a^2ET)F'
=\{3\mathfrak h(r-C)\lambda-a^2EB\}F.
\tag{J15}
\]
For \(\lambda\ne0\) this is equivalent to the original wall condition. One can see the equivalence directly: its left side minus its right side equals \(3\mathfrak h\lambda\) times \((L-rf)\) after (J12) is used. Thus no quotient is needed at a pole.

Away from the pole, (J15) has logarithmic derivative
\[
F'/F=\mathscr R_i(\lambda)
=r-C-\frac{a^2E^2}{3\mathfrak h(\lambda-\lambda_{p,i})},
\quad \lambda_{p,i}=\frac{a^2ET}{3\mathfrak h}.
\tag{J16}
\]
Both residues are negative and both derivatives are positive:
\[
\mathscr R_i'(\lambda)=\frac{a^2E^2}{3\mathfrak h(\lambda-\lambda_{p,i})^2}>0.
\tag{J17}
\]
The lower pole is negative because \(T_a<0\); the upper pole is positive because \(T_b>0\). At either pole \(\lambda_p\ne0\) the coefficient of \(F\) in (J15) is \(-a^2E^2\ne0\), so the correct wall condition is \(F_i=0\), with \(F'_i\) free. It is a regular boundary chart change, not a deleted eigenvalue.

To translate to boundary conditions \((A\lambda+B_0)F=(C_0\lambda+D)pF'\), \(p=a^4\), choose
\[
A=3\mathfrak h(r-C),\quad B_0=-a^2EB,\quad
C_0=3\mathfrak h/a^4,\quad D=-a^2ET/a^4.
\]
Then
\[
AD-B_0C_0=\frac{3\mathfrak h E^2}{a^2}>0.
\tag{J18}
\]
The raw determinants have the same positive sign at both endpoints. A cited theorem that inserts an outward-normal sign into its determinant must be translated accordingly; this calculation must not be read as automatic satisfaction of its hypotheses.

At a Dirichlet scalar wall \(f=0\), the transformed undivided condition is
\[
a^2T^2F'=(a^2TB+3\mathfrak h\lambda)F,
\tag{J19}
\]
or \(F'/F=B/T+3\mathfrak h\lambda/(a^2T^2)\). Endpoints have \(T\ne0\). Thus transformed Dirichlet walls remain spectral Robin walls, with positive slope. This formula is obtained directly and includes \(\lambda=0\) as a transformed condition; \(\lambda=0\) still requires the separate analysis below. It is also the limit of (J15) as the corresponding nonnegative Hessian tends to infinity.

### B.5. Exact norm identity; why the endpoint space is indefinite {#app-K.5}

For real solutions, direct differentiation using (J5) and \(\psi'\) gives
\[
a^2F^2=a^2(f^2+6\psi^2)-3\left(\frac{a^2\psi^2}{\mathfrak h}\right)'.
\tag{J20}
\]
Therefore the original regular norm obeys
\[
\frac Z2=\int_0^D a^2F^2ds+
3\left[\frac{a^2\psi^2}{\mathfrak h}\right]_a^b.
\tag{J21}
\]
At a finite wall away from its pole,
\[
\psi_i=-\frac{a_i^2 E_i F_i}{3(\lambda-\lambda_{p,i})},\quad
\frac{3a_i^2\psi_i^2}{\mathfrak h_i}=a_i^4\mathscr R_i'(\lambda)F_i^2.
\tag{J22}
\]
The same last equality holds at a Dirichlet wall with the affine derivative from (J19). At finite poles one must use (J21) with the regular inverse (J12), not the undefined quotient (J22).

Hence the transformed endpoint norm on eigenfunctions has a positive upper-wall term and a negative lower-wall term:
\[
N[F]=\int_0^D a^2F^2ds+
a_b^4\mathscr R_b'F_b^2-a_a^4\mathscr R_a'F_a^2=Z/2>0
\tag{J23}
\]
for a nonzero physical eigenprofile with \(\lambda\ne0\). Polarization of (J20) gives the corresponding mixed-product identity. At distinct spectral parameters the boundary rational functions give divided differences rather than the equal-parameter derivatives in (J23).

The signs matter: the natural endpoint linearization has one negative boundary direction. Positivity on the actual nonzero physical eigenfunctions is not positivity of that entire enlarged space. A standard positive-measure Sturm–Liouville theorem cannot be imported by suppressing this negative endpoint contribution.

One can display regular endpoint coordinates even at the finite poles. Set \(\vartheta_i=\sqrt{3}\,a_i\psi_i/\sqrt{\mathfrak h_i}\) and \(d_i=a_i^3E_i/\sqrt{3\mathfrak h_i}>0\). Then the finite-wall trace relations are
\[
p_iF'_i=p_i(r_i-C_i)F_i+d_i\vartheta_i,
\quad \lambda\vartheta_i=\lambda_{p,i}\vartheta_i-d_iF_i,
\tag{J24}
\]
and the product is \(\int a^2F^2\,ds+\vartheta_b^2-\vartheta_a^2\). At \(\lambda=\lambda_p\) these equations impose \(F_i=0\) and retain \(\vartheta_i\) and the derivative, so no physical wall pole is discarded. At a Dirichlet scalar wall set \(e_i=\sqrt{3\mathfrak h_i}\,a_i/T_i\); then \(\vartheta_i=e_iF_i\) and \(p_iF'_i=p_i(B_i/T_i)F_i+e_i\lambda\vartheta_i\). These trace-coordinate relations alone do not prove an operator-domain theorem. Appendix M supplies an auxiliary form-domain realization; a basis theorem for arbitrary original Einstein–scalar Cauchy data is not inferred.

### B.6. The exceptional zero is artificial and has negative norm {#app-K.6}

At \(\lambda=0\), the original constrained solutions have
\[
f=-uT,\quad L=-uT',\quad \psi=u'/2,
\quad u''+2Hu'-2T^2u/3=0.
\tag{J25}
\]
To justify coverage, on intervals where \(T\ne0\) the constraint gives this expression; the regular system continues it through every simple turn. These solutions form the full two-dimensional constrained space. At either finite wall, \(L-rf=-Eu\), so \(E>0\) forces \(u_i=0\). A Dirichlet wall likewise forces \(u_i=0\) since \(T_i\ne0\). Multiplying the equation for \(u\) by \(a^2u\) and integrating under \(u(0)=u(D)=0\) yields
\[
\int_0^D a^2\{(u')^2+2T^2u^2/3\}\,ds=0.
\]
Thus there is no nonzero physical \(\lambda=0\) eigenfunction for any of these wall pairs.

The transformation (J9) at \(\lambda=0\) has kernel \(u\) proportional to the chosen positive auxiliary \(v\). Its image is spanned by
\[
F_0=\frac{T}{a^2v'}.
\tag{J26}
\]
Indeed, the Wronskian \(vu'-v'u\) is a constant times \(a^{-2}\), and \(F=T(u'/(2\mathfrak h)-u)\). Equation (J11) holds for this image; equivalently it follows directly by substitution. At either endpoint
\[
F_0'/F_0=T'/T-T^2/(3\mathfrak h)=B/T.
\]
This is exactly (J15) at zero, regardless of finite stiffness, and also (J19) at zero. The transformed separated problem therefore always has this spurious zero eigenfunction. Since its separated left condition is nontrivial, its eigenspace has dimension one. It has exactly the same interior zeros as \(T\).

At zero the finite-wall norm coefficients reduce to the Dirichlet values, independent of stiffness:
\[
a_i^4\mathscr R_i'(0)=3a_i^2\mathfrak h_i/T_i^2.
\]
Define \(\mathfrak d=3/(2a^2vv')=3\mathfrak h/(a^2v'^2)\). Equation (J4) gives
\[
\mathfrak d'=-a^2F_0^2-\frac{3}{2a^2v^2}.
\]
Consequently its transformed norm is strictly negative:
\[
N[F_0]=\int_0^D a^2F_0^2ds+[\mathfrak d]_a^b
=-\frac32\int_0^D\frac{ds}{a^2v^2}<0.
\tag{J27}
\]
This does not contradict (J21): no original profile satisfies both physical walls at \(\lambda=0\), and the inverse (J12) is unavailable there. Applying the equal-parameter transformed boundary formula to the artificial zero does not manufacture a physical inverse.


### B.7. Compact wall faces and the count offset {#app-K.7}

For a single formula on the nonnegative wall square, set \(t_i=1/(1+\kappa_i)\), \(j_a=-(1-t_a)/2\), \(j_b=(1-t_b)/2\), and \(\widetilde E_i=t_iT'_i+j_iT_i\). The physical wall is \(t_iL_i+j_if_i=0\). In the endpoint-only theorem \(\widetilde E_i>0\) uniformly, including both faces. Substitution of (J12) gives
\[
(3\mathfrak h_i\lambda t_i-a_i^2\widetilde E_iT_i)F_i'
+\{3\mathfrak h_i\lambda(t_i C_i+j_i)+a_i^2\widetilde E_iB_i\}F_i=0.
\tag{J28}
\]
At \(t_i=1\) this is zero Hessian; at \(t_i=0\) it is (J19). For every \(\lambda\ne0\), its residual is exactly \(3\mathfrak h_i\lambda(t_iL_i+j_if_i)\). Thus even simultaneous Dirichlet limits retain the classical trace correspondence, and no division by a wall parameter is required. Appendices L/N treat simple-root continuation and the uniform root-free strip in the physical variables, without a pointwise limit of rational slopes.

The same-sign determinants belong to established eigenparameter-dependent boundary theory [28, 29]; a positive-measure boundary theorem cannot be applied by dropping the negative endpoint direction. Appendix M constructs the required positive complement explicitly and proves the restricted count. Appendix N supplies the separate remaining-band exclusion. The exact characteristic factor in Appendix L preserves every nonzero physical multiplicity and identifies only one simple artificial zero. No original Cauchy-data spectral expansion follows from this solution-space transformation.


## Appendix C. Weak mode domain and the physical characteristic determinant {#app-L}

This section proves the exhaustive neutral mode-domain statement used in Theorem 1 and Proposition 1. It concerns the separated generic longitudinal scalar sector, with the action-derived equations and traces of Appendix J. A finite kinetic norm is a radial condition on \(f,\psi\); it is not a claim that an arbitrary finite signed-action metric perturbation admits this gauge or belongs to this sector. The endpoint hypotheses \(T_a<0<T_b\), \(T'_a,T'_b>0\) are assumed for the full compact wall square below.

### C.1. Global weak equations force classical regularity {#app-L.1}

Let \(I=(0,D)\). Require
\[
\int_I a^2(|f|^2+6|\psi|^2)\,ds<\infty
\]
and impose, as distributions on all of \(I\),
\[
\psi'=-2H\psi-Tf/3,\quad
f''+4Hf'=A_\mu f+E\psi,\quad
Tf'-T'f+(2T^2-3\lambda/a^2)\psi=0,
\tag{K1}
\]
where \(A_\mu=V_{,\Phi\Phi}-\mu/a^2+2T^2\), \(E=12HT-4V_{,\Phi}\), and \(\lambda=\mu+4k\). These coefficients are regular and bounded. The scalar equation must hold through every scalar turn, not merely on the complementary subintervals.

Positive warp on the compact interval makes the norm condition equivalent to \(f,\psi\in L^2(I)\). Momentum then gives \(\psi\in H^1(I)\). Put \(p=a^4\) and \(R=p(A_\mu f+E\psi)\in L^2\). The scalar equation states \((pf')'=R\). Its primitive \(G(s)=\int_0^sR(r)dr\) belongs to \(H^1\), and the distribution \(pf'-G\) has zero derivative, so it is a constant on the connected interval. Consequently \(pf'\in H^1\); multiplication by \(1/p\) gives \(f'\in H^1\), hence \(f\in H^2\). No assumption \(f'\in L^2\) was needed in advance.

In one dimension \(H^1\) functions have continuous representatives. Thus \(\psi,f,g=f'\) are continuous. The right-hand sides of manuscript (10) are now continuous, giving \(\psi,g\in C^1\) and \(f\in C^2\), with one-sided derivatives at both walls. The constraint is continuous and zero as a distribution, hence pointwise zero. Conversely every classical retained solution has finite norm and satisfies (K1). The wall traces are therefore ordinary classical traces.

This proves that no additional finite-norm weak mode or interface datum occurs at \(T=0\), without dividing by \(T\) or \(H\). To see why the global scalar equation is necessary, join two constrained classical solutions at a simple turn with the same \(f_*,\psi_*\) but different \(g_*\). The constraint there fixes \(f_*=-3\lambda\psi_*/(a_*^2T'_*)\) and does not fix \(g_*\). The glued pair has finite norm and satisfies the other equations and the scalar equation off the turn, but \(f''\) has a nonzero delta term equal to the jump in \(g\). It is not a solution of (K1). The retained scalar equation excludes this gluing; finite norm alone would not.

For \(\lambda\ne0\), the scalar-pencil weak solutions are classical by the same primitive argument applied to \(-(a^4F')'+a^4UF=\lambda a^2F\). Thus Appendix K also gives a bijection of the physical and scalar-pencil weak eigensolution spaces with their undivided wall traces. This remains a solution-space statement, not a bounded equivalence on unrestricted Sobolev spaces.

### C.2. Uniform boundary rank and the normalized physical launch {#app-L.2}

Set
\[
t_i=(1+\kappa_i)^{-1},\quad
j_a=-(1-t_a)/2,\quad j_b=(1-t_b)/2,\quad
\widetilde E_i=t_iT'_i+j_iT_i.
\tag{K2}
\]
Zero Hessian means \(t_i=1\), and physical Dirichlet means \(t_i=0\). The endpoint hypotheses give
\[
\widetilde E_a\ge\min(T'_a,-T_a/2)>0,\qquad
\widetilde E_b\ge\min(T'_b,T_b/2)>0.
\tag{K3}
\]
The wall row is \(t_iL_i+j_if_i=0\). Its norm is at least \(1/\sqrt5\), since
\(t^2+(1-t)^2/4=(5t-1)^2/20+1/5\).
The constraint and wall rows on \((f,L)\) are \((-T',T)\) and \((j,t)\); their determinant is \(-\widetilde E\). Thus no boundary rank is lost, even at a compactified face.

Every nonzero lower-admissible solution has \(\psi_a\ne0\): if it vanished, those two independent equations would force \(f_a=L_a=0\), and IVP uniqueness would force the full profile to vanish. Normalize the whole lower-admissible line by
\[
\psi_a=1,\quad f_a=-3\lambda t_a/(a_a^2\widetilde E_a),\quad
L_a=3\lambda j_a/(a_a^2\widetilde E_a),\quad g_a=L_a-2T_a.
\tag{K4}
\]
It satisfies the constraint and lower wall for every complex \(\lambda\), including zero. It is affine in \(\lambda\) and uniformly regular on the whole wall square. Every admissible eigenfunction is a scalar multiple of this launch. In particular the radial eigenspace is one-dimensional; this does not count the multiplicity of four-dimensional harmonics.

### C.3. Entire characteristic determinant, reality and simplicity {#app-L.3}

Propagate (K4) with manuscript (10) and define
\[
\mathscr D(\lambda,t_a,t_b)=t_bL_b+j_bf_b.
\tag{K5}
\]
For a compact complex spectral disk, the IVP matrix is uniformly bounded on the finite interval. Its iterated-integral series has the factorial bound \((MD)^r/r!\); uniform convergence makes the solution entire in \(\lambda\). The normalized launch has the same property. Thus \(\mathscr D\) is entire in \(\lambda\), and real analytic in the wall coordinates in a neighborhood of each compactified face. This does not assert analytic dependence on an arbitrary smooth background parameter.

By Appendix L.1–L.2, \(\mathscr D=0\) is equivalent to an admissible finite-norm weak/classical radial mode. Pairing a complex root with its conjugate in the regular Green identity gives
\[
(\mu-\overline\mu)\int_0^D a^2(|f|^2+6|\psi|^2)\,ds=0.
\]
The wall fluxes vanish at finite, zero-Hessian and Dirichlet walls. The integral is positive, so every root is real. In particular \(\mathscr D(i)\ne0\), showing it is not identically zero. Its roots are discrete and finite in every bounded spectral interval.

At a real root with \(\lambda\ne0\), the upper wall line has the form
\[
(f_b,L_b)=\zeta(t_b,-j_b),\qquad \zeta\ne0.
\]
If \(\zeta=0\), the constraint gives \(\psi_b=0\), contradicting the normalized nonzero launch by IVP uniqueness. Differentiating the Green identity in the second mass, with the fixed lower wall, gives
\[
a_b^4(f_bL_{\lambda,b}-L_bf_{\lambda,b})=-Z/2,
\qquad
\mathscr D_\lambda=-\frac{Z}{2a_b^4\zeta}\ne0.
\tag{K6}
\]
Thus each root is a simple characteristic zero as well as having a one-dimensional radial eigenspace, including on all compactified faces. On a compact root set separated from shifted zero, continuity also bounds this derivative away from zero. This directly identifies characteristic multiplicity of the analytic boundary-value problem. Appendix M constructs an auxiliary operator with matching nonzero eigenspaces; no original physical Cauchy-data completion is assumed here.

### C.4. Shifted zero and the exact transformed determinant factor {#app-L.4}

At \(\lambda=0\) the regular solutions have \(f=-Tu\), \(L=-T'u\), \(\psi=u'/2\), with
\[
(a^2u')'=\tfrac23a^2T^2u.
\]
Each physical wall is \(-\widetilde E_i u_i=0\). Therefore both endpoint values vanish, and integration against \(\overline u\) gives
\[
\int_0^D a^2(|u'|^2+\tfrac23T^2|u|^2)\,ds=0.
\]
There is no nonzero physical root. For the normalized launch (K4), \(u_a=0,u'_a=2\), independently of the wall coordinates. Positivity of the flux makes \(u_b>0\), and
\[
\mathscr D(0,t_a,t_b)=-\widetilde E_bu_b<0
\tag{K7}
\]
uniformly on the square. The physical determinant is entire and nonzero at shifted zero; its exceptional-root issue is confined to the scalar transformation.

Let \(C=T^2/(3\mathfrak h)\), \(B=T'-CT\) as in Appendix K. The compact scalar boundary row (J28) is
\[
W_i[F]=\alpha_iF_i'+\beta_iF_i,
\quad \alpha_i=3\mathfrak h_i\lambda t_i-a_i^2\widetilde E_iT_i,
\quad \beta_i=3\mathfrak h_i\lambda(t_iC_i+j_i)+a_i^2\widetilde E_iB_i.
\tag{K8}
\]
The determinant of its \(\lambda\)-coefficient vector and constant vector, in the order \((\alpha,\beta)\), is
\(3\mathfrak h_i a_i^2\widetilde E_i^2>0\).
Thus its two coefficients never vanish simultaneously at any complex \(\lambda\), and it always specifies one scalar initial-data line.

The forward identities yield the exact off-constraint relation
\[
W_i[F]-3\mathfrak h_i\lambda(t_iL_i+j_if_i)
=-a_i^2\widetilde E_i
\{T_iL_i-T'_if_i-3\lambda\psi_i/a_i^2\}.
\tag{K9}
\]
This identity does not divide by \(\lambda\). Use the forward image of (K4) to normalize the scalar lower launch. It is entire and never zero: for \(\lambda\ne0\) use (J13), and at zero use \(F_a=T_a/\mathfrak h_a\ne0\). It spans the entire lower scalar boundary line for every parameter. Its upper characteristic residual therefore satisfies
\[
\widetilde{\mathscr D}(\lambda,t_a,t_b)
=3\mathfrak h_b\lambda\,\mathscr D(\lambda,t_a,t_b).
\tag{K10}
\]
All nonzero physical and transformed characteristic multiplicities agree. By (K7), the transformed zero is artificial and simple. The negative-signature calculation in K.6 is consistent with, and independent of, this characteristic proof of its simplicity. Neither proof extends the physical inverse through zero.

## Appendix D. The restricted index as a standard form-theory consequence {#app-M}

This section proves the count below \(\lambda=0\) after the regular physical reconstruction and exceptional-root calculation. Ordinary Sturm oscillation [23] and standard closed-form representation, compactness and variational results [24] supply the general spectral facts. The required application hypotheses, endpoint signs, kernel and physical spectrum are established explicitly below. The separate remaining-band phase argument is in Appendix N.

### D.1. Fixed Robin comparison and its negative index {#app-M.1}

Write \(p=a^4\), \(w=a^2\), \(q=pU\). At each finite wall use the notation
\[
A_i=r_i-C_i,\quad z_i=\frac{a_i^2E_iT_i}{3\mathfrak h_i},\quad
c_i=\frac{a_i^2E_i^2}{3\mathfrak h_i}>0,\quad
d_i=\sqrt{p_ic_i},\quad e_i=\frac{d_i}{z_i}=\frac{\sqrt{3\mathfrak h_i}a_i}{T_i}.
\tag{L1}
\]
Here \(C_i=T_i^2/(3\mathfrak h_i)\), \(E_i=T'_i-r_iT_i>0\), and \(p_i=a_i^4\); the pole \(z_i\) is distinct from the bulk coefficient \(p\). Endpoint signs imply \(z_a<0<z_b\). The exact transformed boundary equations are
\[
p_iF'_i=p_iA_iF_i+d_i\vartheta_i,\qquad
\lambda\vartheta_i=z_i\vartheta_i-d_iF_i.
\tag{L2}
\]
They retain the spectral poles without a quotient. At zero,
\[
R_i^0:=A_i+c_i/z_i=B_i/T_i,\qquad e_i=d_i/z_i,
\tag{L3}
\]
both independent of wall stiffness.

Consider the ordinary, fixed separated Robin problem with the same bulk expression and \(F'_i=R_i^0F_i\). Its form on \(H^1(0,D)\) is
\[
s_R[F]=\int_0^D(p|F'|^2+q|F|^2)ds
+p_aR_a^0|F_a|^2-p_bR_b^0|F_b|^2.
\tag{L4}
\]
The smooth function \(F_0=T/(a^2v')\) is its zero eigenfunction and has exactly the \(n\) simple interior zeros of \(T\). The regular separated Sturm theorem therefore places zero at ordered index \(n\), starting at index zero [23; Section 5.5]. This ordinary Robin problem has exactly \(n\) negative eigenvalues and a one-dimensional kernel. Its form consequently has negative index \(n\). These Robin eigenvalues are comparison data, not asserted to be the physical eigenvalues.

### D.2. Closed augmented form and exact index preservation {#app-M.2}

Let
\[
\mathcal H=L^2((0,D),w\,ds)\oplus\mathbb C^2,\quad
Y=(F,\vartheta_a,\vartheta_b),\qquad
[Y,Y]=\|F\|_w^2-|\vartheta_a|^2+|\vartheta_b|^2.
\tag{L5}
\]
Thus \([Y,Z]=\langle JY,Z\rangle_{\mathcal H}\), with \(J\) negative on the lower endpoint coordinate only. For finite walls take \(\mathcal V=H^1(0,D)\oplus\mathbb C^2\) and define the Hermitian form
\[
s[Y]=s_R[F]+(-z_a)|\vartheta_a-e_aF_a|^2
+z_b|\vartheta_b-e_bF_b|^2.
\tag{L6}
\]
The two added coefficients are positive. Expanding them gives the boundary part
\[
p_aA_a|F_a|^2-p_bA_b|F_b|^2
-z_a|\vartheta_a|^2+2d_a\operatorname{Re}(F_a\overline{\vartheta_a})
+z_b|\vartheta_b|^2-2d_b\operatorname{Re}(F_b\overline{\vartheta_b}),
\]
which verifies the endpoint orientation directly.

The form is densely defined and lower bounded. The one-dimensional trace estimate
\[
|F_a|^2+|F_b|^2\le\epsilon\|F'\|_2^2+C_\epsilon\|F\|_2^2
\]
absorbs the possibly negative Robin terms into the uniformly positive principal term. For sufficiently large \(c\), the squared form norm \(s[Y]+c\|Y\|_{\mathcal H}^2\) is equivalent to the squared complete \(H^1\oplus\mathbb C^2\) norm. The upper estimate uses bounded traces; the lower estimate uses the trace bound and the nonnegative squares. Hence \(s\) is closed. The representation theorem gives its self-adjoint lower-bounded operator \(S\) [24; Theorem 10.7]. The form-domain embedding into \(\mathcal H\) is compact, by one-dimensional compactness and the finite endpoint coordinates; equivalently the resolvent is compact [24; Proposition 10.6]. Explicitly, the coercive estimate bounds \((S+c)^{-1}\) into \(\mathcal V\), whose embedding into \(\mathcal H\) is compact.

The negative index is unchanged. Any negative subspace of \(s\) projects injectively to a negative subspace of \(s_R\), because the squares are nonnegative. Conversely, lift every negative Robin subspace by \(\vartheta_i=e_iF_i\), making both squares zero. Thus
\[
\operatorname{ind}_{-}s=\operatorname{ind}_{-}s_R=n.
\tag{L7}
\]
In the polarized kernel equation \(s(Y,Z)=0\) for every \(Z\in\mathcal V\), the independent endpoint variations force \(\vartheta_i=e_iF_i\), and the remaining equation is the ordinary Robin zero equation. Therefore
\[
\ker S=\operatorname{span}\{Y_0\},\qquad
Y_0=(F_0,e_aF_{0,a},e_bF_{0,b}),\qquad
[Y_0,Y_0]=-\frac{3}{2}\int_0^D\frac{ds}{a^2v^2}<0.
\tag{L8}
\]
The last equality is the independent K.6 signature calculation. The vector \(Y_0\) and the metric \(J\) do not change with stiffness. This is the artificial scalar root, not a physical zero mode.

### D.3. Removing the negative kernel and recovering the physical spectrum {#app-M.3}

Set \(\mathcal M=\{Y:[Y,Y_0]=0\}\). This is uniformly positive in the metric (L5), not merely nonnegative. To see this explicitly, write the ambient Hilbert space as its positive coordinates plus the one negative coordinate, and let \(Y_0=(u_0,\alpha)\), with \(r=\|u_0\|/|\alpha|<1\). Orthogonality gives \(|\vartheta_a|\le r\|u\|\), so
\[
[Y,Y]\ge\frac{1-r^2}{1+r^2}\|Y\|_{\mathcal H}^2,
\qquad Y\in\mathcal M.
\tag{L9}
\]
Projection along \(Y_0\) is bounded and preserves the form domain, since \(Y_0\) belongs to it. Its range on \(\mathcal V\) is dense in \(\mathcal M\), and
\(\mathcal V=\operatorname{span}\{Y_0\}\oplus(\mathcal V\cap\mathcal M)\).
Because \(s(Y_0,Z)=0\), removing this kernel leaves the negative index unchanged. On the positive Hilbert space \((\mathcal M,[\cdot,\cdot])\), the restricted form is closed, lower bounded and compactly embedded, by (L9) and the preceding coercive estimate. Its self-adjoint form representative \(T_{\mathcal M}\) has compact resolvent and exactly \(n\) negative eigenvalues by the variational principle [24; Theorem 12.1]. It has no zero eigenvalue: a restricted zero solution extends to the full kernel, whose intersection with \(\mathcal M\) is zero.

For finite walls the full weak equation
\[
s(Y,Z)=\lambda[Y,Z]\quad\hbox{for all }Z\in\mathcal V
\tag{L10}
\]
gives the bulk scalar equation and exactly (L2), by interior, endpoint-coordinate and endpoint-trace variations. Interior regularity makes the solutions classical. For \(\lambda\ne0\), testing against \(Y_0\) forces \(Y\in\mathcal M\). Conversely a restricted eigenfunction satisfies (L10) against all \(\mathcal V\), since both sides vanish against \(Y_0\). Consequently the nonzero scalar-pencil eigenvalues are exactly those of \(T_{\mathcal M}\). Appendix K and (K10) identify them, including characteristic multiplicity, with the physical nonzero roots. Thus exactly \(n\) physical eigenvalues have \(\lambda<0\), independently of the physical-phase proof.

This construction is an auxiliary operator realization of the separated transformed pencil. Its spectral theorem is not an expansion theorem for arbitrary original Einstein–scalar initial perturbations: the inverse map contains the spectral parameter, and no unrestricted physical Cauchy-data space has been identified with \(\mathcal M\).

### D.4. Dirichlet faces and stiffness comparison {#app-M.4}

At a physical Dirichlet endpoint use the exact trace condition
\[
\vartheta_i=e_iF_i,\qquad p_iF'_i=p_iR_i^0F_i+\lambda e_i^2F_i.
\tag{L11}
\]
Keep the same \(\mathcal H,J,Y_0,\mathcal M\). Impose \(\vartheta_i=e_iF_i\) in the form domain at each Dirichlet wall and omit its square in (L6); finite endpoints retain their free coordinate and square. The resulting domain is closed in the \(H^1\oplus\mathbb C^2\) topology and dense in \(\mathcal H\). For density, approximate an arbitrary bulk \(L^2\) function by smooth interior functions, then add arbitrarily narrow \(H^1\) boundary layers realizing any prescribed endpoint \(\vartheta_i/e_i\) with arbitrarily small bulk \(L^2\) norm. No bounded derivative norm is required for that density approximation.

The coercive estimate and compact embedding still hold. Projection along \(Y_0\) preserves these constrained domains. The negative-index comparison is unchanged: every negative Robin subspace can still be lifted by \(\vartheta_i=e_iF_i\) at all endpoints. The kernel remains (L8). In (L10), a constrained endpoint variation has \(\zeta_i=e_iG_i\); the boundary term gives exactly (L11), with the same oriented signs at either wall. Hence the proof covers either or both affine transformed Dirichlet faces directly. It does not send a finite pole to infinity inside a quotient chart.

The same comparison also explains the standard stiffness behavior. At finite walls \(\rho_a=-z_a\), \(\rho_b=z_b\) increase with the respective nonnegative Hessians, while \(e_i,Y_0,\mathcal M\) remain fixed. The variational principle gives nondecreasing ordered eigenvalues, with Dirichlet ceilings. For a physical eigenmode, \(\vartheta_i-e_iF_i=-e_if_i\) and \(\partial_{\kappa_i}\rho_i\,e_i^2=a_i^4/2\); its norm is \([Y,Y]=Z/2\). The simple-root derivative is therefore exactly \(a_i^4f_i^2/Z\), as used in Appendix N. These are standard variational consequences after the reconstruction, not separate novelty claims.

## Appendix E. Phase monotonicity and the complete neutral count {#app-N}

### E.1. Green identity and nonvanishing {#app-N.1}

Let \((\psi_i,f_i,g_i)\) satisfy the regular constrained system at mass \(\mu_i\), and set \(L_i=g_i+2T\psi_i\). Direct substitution gives

\[
\bigl[a^4(f_iL_j-L_if_j)\bigr]'
=(\mu_i-\mu_j)a^2(f_if_j+6\psi_i\psi_j).
\tag{M1}
\]

For verification put \(U=\psi_if_j-f_i\psi_j\), \(W=f_ig_j-g_if_j\), \(\Delta\mu=\mu_i-\mu_j\). Then \(W'=-4HW+\Delta\mu f_if_j/a^2+4(T'+HT)U\) and \(TU'=(T'-2HT)U-3\Delta\mu\psi_i\psi_j/a^2\). These identities give (M1) without dividing by \(T\). The lower flux vanishes for a fixed lower physical wall. Differentiating in the second mass and setting the masses equal yields

\[
\partial_\mu\theta(s,\mu)=
\frac{Z_s}{2a(s)^4(f^2+L^2)}>0,\quad
\theta=\arg(L+if),\quad
Z_s=2\int_0^s a^2(f^2+6\psi^2)\,dr.
\tag{M2}
\]

For \(\lambda\ne0\), \((f,L)\) cannot vanish anywhere: the constraint gives \(\psi=0\), then IVP uniqueness makes the entire profile zero. Thus (M2) defines a continuous spectral phase lift, not only a derivative evaluated at an eigenvalue. Complex conjugate pairing in (M1) gives reality. Appendix L supplies the exhaustive characteristic and its simple roots on the full compact wall square.

### E.2. Wall response and compact continuation {#app-N.2}

For finite Hessians the same Green identity with one wall varied gives

\[
\mu_{\kappa_i}=\frac{a_i^4 f_i^2}{Z}>0.
\tag{M3}
\]

Its sign is the same at both ends because the two physical wall orientations are opposite. A finite-wall \(f_i\) at a nonzero shifted root cannot vanish without making all profiles zero. Use \(t_i=(1+\kappa_i)^{-1}\in[0,1]\), \(j_a=-(1-t_a)/2\), \(j_b=(1-t_b)/2\), \(\widetilde E_i=t_iT'_i+j_iT_i>0\). The entire lower launch in (K4) has \(f_a=-3\lambda t_a/(a_a^2\widetilde E_a)\). At an upper root write \((f_b,L_b)=\zeta_b(t_b,-j_b)\), \(\zeta_b\ne0\). The response extends to all faces as

\[
\mu_{t_a}=-\frac{9\lambda^2}{Z\widetilde E_a^2}<0,
\qquad\mu_{t_b}=-\frac{a_b^4\zeta_b^2}{Z}<0.
\tag{M4}
\]

This follows from (M3) in the interior and analyticity of the simple normalized root at a face. Appendix L proves the physical determinant is strictly negative at \(\lambda=0\), uniformly on the compact square. Its continuity on a compact spectral neighborhood gives a common two-sided root-free strip around that point. No numerical value of that strip is required.

Given a remaining-band tachyon \(-4k<\mu<0\) at any target wall, increase both \(t_i\) toward the soft corner \((1,1)\). Its mass decreases by (M4). It cannot escape through zero mass, or through the uniform strip at \(-4k\). At a putative finite continuation endpoint, compactness of the mass interval and IVP continuity give a limiting root; simplicity extends it by the implicit-function theorem. Distinct roots cannot merge because the limiting characteristic derivative is nonzero. Therefore

\[
N_{(-4k,0)}(t_a,t_b)\le N_{(-4k,0)}(1,1).
\tag{M5}
\]

This is an injection, not a general equality. If a non-soft target had a massless root, the same path has negative initial mass derivative (at least one coordinate increases). It immediately becomes a remaining-band tachyon and would also reach the soft corner. Thus an empty soft-corner band and absence of a soft-corner zero exclude every extra tachyon and every massless mode throughout the square. The restricted count of Appendix M is one, including Dirichlet faces, so these exclusions complete the count.



Figure 6 illustrates continuation to the soft corner and the two-sided threshold exclusion.

![Compactified wall square with arrows toward the soft corner and a schematic root-free strip on both sides of the shifted threshold.](figures/soft_corner.png){#fig:soft_corner}

**Figure 6.** Schematic of the soft-corner injection in Appendix N.2. In \(t_i=(1+\kappa_i)^{-1}\), the soft corner is \((1,1)\) and the Dirichlet faces have \(t_i=0\). A hypothetical additional negative root moves with decreasing mass toward the soft corner. The proof supplies a uniform root-free strip on both sides of \(-4k\), together with simplicity and compact continuation, preventing loss of a branch before the contradiction at that corner. No numerical width is assigned to the strip.

### E.3. Physical zero mass and its anchored phase {#app-N.3}

At zero Hessians the normalized launch is

\[
\psi_a=1,\quad f_a=-3\lambda/T'_a,\quad
g_a=-2T_a,\quad L_a=0,\qquad a_a=1.
\tag{M6}
\]

At \(\lambda=0\), put \(f=-T u_0\), \(L=-T'u_0\), \(\psi=u'_0/2\). The auxiliary equation is \((a^2u'_0)'=2a^2T^2u_0/3\), \(u_0(a)=0\), \(u'_0(a)=2\). Hence \(u_0,u'_0>0\) inside the collar. This is not the everywhere-positive auxiliary \(v\) used in Appendix K's transformation. With exactly one simple zero of \(T\), \(f\) is first positive and then negative; at that zero \(L=-T'u_0<0\). Its continuous spatial lift passes through \(\pi\), and the upper signs \(T_b,T'_b>0\) place its endpoint strictly in \((\pi,3\pi/2)\). There is no hidden extra winding, since \(f\) has only that one interior zero.

For positive \(\lambda\), (M6) has lower phase \(3\pi/2\). This choice is tied to the preceding auxiliary lift. Indeed the regular equations give
\(L'=-4HL+(V''-\mu/a^2+4T^2/3)f-2T'\psi\), so at the lower corner \((s,\lambda)=(0,0)\), \(L'=-2T'_a<0\). It remains negative in a small corner neighborhood. The phase therefore joins through the left half-plane to the positive-\(\lambda\) lower launch; resetting its principal value to \(-\pi/2\) would change the winding by one. Nonvanishing then extends that lift continuously up to physical \(\mu=0\), which means \(\lambda=4k\).

Upper zero-Hessian roots satisfy \(L_b=0\); their angles above the auxiliary endpoint are \(3\pi/2+j\pi\), \(j\ge0\). Strict monotonicity (M2) counts crossings up to physical zero mass. Hence

\[
\theta_b(\mu=0)<3\pi/2
\quad\Longrightarrow\quad
N_{(-4k,0)}(1,1)=0\text{ and no soft-corner massless mode}.
\tag{M7}
\]

An equality would be a physical massless root, not a tachyon. An interval merely touching the threshold is inconclusive. The exact enclosure in manuscript (14), justified as a computer-assisted premise in Appendix O, is strictly below the threshold. Combining (M5)–(M7) with the one-root restricted count proves Proposition 1. It counts radial eigenvalues in the generic coupled sector, not harmonic multiplicities or arbitrary Cauchy-data expansions.

## Appendix F. Mathematical justification of the numerical premises {#app-O}

### F.1. Exact problem and dependency chain {#app-O.1}

For the exact potentials in manuscript Appendix A, define the original upper-wall residuals

\[
F_1(s,A)=H(s,A)-\tau_b(\Phi(s,A))/6,
\qquad F_2(s,A)=T(s,A)+\tau_{b,\Phi}(\Phi(s,A))/2.
\tag{N0}
\]

The local branch is the first transverse zero of \(F_1\), followed by a zero of \(F_2\) there. The background wall coefficient remains 20. Numerical truth of the enclosures is a stated outward-execution premise; the following arguments explain why the required predicates imply the result, without re-running a producer.

manuscript Appendix A fixes all six rational action parameters. The proper-distance lower launch for any scalar value \(A\) is

\[
\begin{gathered}
W_a=0,\quad\Phi_a=A,\quad T_a=\gamma(A-v_0)/2,\\
H_a=-[\lambda_a+\gamma(A-v_0)^2/2]/6,\\
k(A)=H_a^2-1-T_a^2/12+m^2A^2/12.
\end{gathered}
\tag{N1}
\]

where \(W=\log a\). The exact central launch interval is the one in manuscript Appendix A; the endpoint interval is \(I_D=[32727/16384,32729/16384]\). Those rational intervals, rather than a fitted central trajectory, are the spectral inputs. Interval evaluation may lose correlations between \(A\) and \(k(A)\); outward bounds enlarge the enclosed set and still include the required correlated trajectory.

The background wall potentials remain the original potentials when this launch is constructed. Setting the **perturbative** wall Hessians to zero means adding background-preserving quadratic wall terms, not replacing \(\gamma=20\) in (N1). For \(\mu=0\), the phase calculation explicitly replaces the default finite-Hessian perturbative launch by

\[
T'_a=m^2A-4H_aT_a,\qquad
\psi_a=1,\quad f_a=-12k/T'_a,\quad g_a=-2T_a.
\tag{N2}
\]

The certificate checks \(k>0\), \(T'_a>0\), and \(f_a<0\). Equation (N2) satisfies the exact constraint and \(L_a=g_a+2T_a\psi_a=0\). Its lifted phase is \(3\pi/2\), by the positive-shift corner argument in Appendix N.3. Physical zero mass here means \(\lambda=4k\), not the auxiliary endpoint \(\lambda=0\).

### F.2. Why the enclosed background exists {#app-O.2}

Let \(F_1,F_2\) be the residuals (N0). On a regular background trajectory, validated event bounds identify the first zero \(D(A)\) of \(F_1\): all earlier cells are excluded, the residual changes sign across the event bracket, and \(\partial_sF_1<0\) on it. The retained event bracket lies strictly inside the integration interval \((0,2)\), so the preceding positive and following negative sign regions are nonempty. Those sign regions are part of the event proof; a vacuous “all cells” test on an empty region would not establish a crossing. The implicit-function theorem defines a differentiable event map there. Propagating the launch sensitivity \(y_A\) together with the background gives

\[
D'(A)=-\frac{\partial_A F_1}{\partial_sF_1},\qquad
q'(A)=\partial_A F_2+\partial_sF_2 D'(A),\qquad
q(A)=F_2(D(A),A).
\tag{N3}
\]

The derivatives include the dependence of the launch and \(k(A)\). On a frozen launch box \(I\), interval Newton evaluates

\[
N(I)=A_0-\frac{q(A_0)}{q'(I)},\qquad A_0\in I,
\quad 0\notin q'(I),\quad N(I)\subset\operatorname{int}I.
\tag{N4}
\]

These interval-Newton conditions [42] establish existence and uniqueness of the shooting zero in \(I\). The high-resolution producer's exact Newton image is the interval \(I_A\) printed in manuscript Appendix A, equation (31); its event enclosure is \(I_D\). The independent background implementation establishes a root of the same shooting function in the common frozen box. Identification uses that uniqueness result, not overlap of approximate roots. Positive warp, positive curvature, event transversality and the opposite endpoint scalar-derivative signs are the retained geometric predicates. The quadratic potential is convex, so Lemma 1 then supplies the one-turn and \(T'>0\) consequences.

Only the local root and geometry are needed here; the separate larger global covers and fixed-distance exclusions are not premises of Proposition 1.

### F.3. Interval flow enclosure {#app-O.3}

Write the coupled background and scalar equations (9)-(10) as a smooth autonomous system \(Y'=F(Y;p)\), where \(p\) denotes fixed parameters in outward intervals. On each cell of width \(h\), an interval starting state \(Y_j\) is enclosed in a padded whole-cell box \(B_j\). The accepted test is strict componentwise inclusion

\[
\operatorname{hull}\{Y_j,\ Y_j+[0,h]F(B_j;p)\}
\subset\operatorname{int}B_j.
\tag{N5}
\]

Local existence and uniqueness follow from the smooth right-hand side. More explicitly, before a hypothetical first exit the integral equation places every exact trajectory in \(Y_j+[0,h]F(B_j;p)\), strictly inside \(B_j\), contradicting that exit. A solution confined to a compact box in the smooth ODE domain extends to time \(h\). This argument is uniform for all enclosed initial states and fixed enclosed parameters; it does not require a computed contraction constant. No numerical Picard contraction constant is claimed: the implementation tests strict self-containment, not a contraction estimate. Failed inclusions stop the calculation.

Define normalized autonomous Taylor coefficients recursively by
\(c_0(Y;p)=Y\) and \(c_{r+1}=(D_Yc_r)F/(r+1)\). Interval recurrences enclose these coefficients. The propagated endpoint and any clipped subinterval use

\[
Y(s_j+t)\in\sum_{r=0}^{4}c_r(Y_j;p)t^r
+c_5(B_j;p)t^5,\qquad 0\le t\le h.
\tag{N6}
\]

Indeed, for each component \(i\), Taylor's theorem gives a remainder \(c_{5,i}(Y(s_j+\xi_i);p)t^5\), with \(0\le\xi_i\le t\). The components need not share one remainder point: each lies in the same whole-cell box, so outward evaluation of \(c_5(B_j;p)\) encloses all of them. The recurrence computes the normalized jets \(Y^{(r)}/r!\). The fifth coefficient evaluated on \(B_j\) therefore bounds the normalized fifth derivative at every possible remainder point. Thus a degree-four polynomial plus a fifth-order remainder encloses the trajectory, rather than treating a truncated numerical series as exact. Polynomial evaluation is by interval Horner arithmetic. Implementation choices and saved-trace bookkeeping are documented in Appendix H.

Arithmetic operations and elementary functions use outward Arb balls. Inputs are formed from exact rational literals, not rounded decimal parameters. Each cell also checks finite state bounds, positive warp, and zero containment of the first-integral and linear-constraint residuals. The last two are consistency gates; they do not prove exact constraint satisfaction by themselves. Exact launch identities and analytical propagation of the constraints supply that assertion.

### F.4. Whole-cell phase charts and the lift {#app-O.4}

On every whole-cell box compute intervals for \(f\) and \(L=g+2T\psi\). At least one of the following strict half-plane conditions must hold. It supplies the indicated interval angle:

Table 7 lists the admitted local phase charts.

**Table 7. Whole-cell conditions and their corresponding local phase charts.**

| Whole-cell condition | Local angle chart |
|---|---|
| \(L>0\) | \(\arctan(f/L)\) |
| \(f>0\) | \(\pi/2-\arctan(L/f)\) |
| \(L<0\) | \(\pi+\arctan(f/L)\) |
| \(f<0\) | \(3\pi/2-\arctan(L/f)\) |

All inequalities hold for the complete interval, so the selected denominator excludes zero. The entire exact path in that cell lies in one open half-plane: it cannot contain the origin or make an unobserved full winding. If no chart is admitted, the calculation stops rather than choosing a principal angle at the endpoint.

The branch-selection argument can be stated without relying on overlap alone. Let \(P\) be the preceding enclosure of the true lifted shared-endpoint angle, with radius less than \(\pi\), and let \(A\) enclose the next half-plane chart. For a proposed integer \(n\), require the rigorous inclusion
\[
A+2n\pi\subset(\operatorname{mid}P-\pi,\operatorname{mid}P+\pi).
\tag{N7}
\]
The preceding true angle and the shifted chart's representative at that same endpoint are now in one open interval of length \(2\pi\), and differ by an integer multiple of \(2\pi\); they must coincide. The continuous half-plane branch therefore propagates the correct lift throughout the cell. The accepted interval also has radius less than \(\pi\), so the argument iterates. The initial \(3\pi/2\) enclosure satisfies the radius condition. The source's strict distance-from-reference-midpoint bound, verified using an outward angle ball and a lower bound for \(\pi\), implements (N7); a floating proposal for \(n\) cannot replace it. The same reasoning applies to endpoint and clipped-event charts, using the accepted cell chart as reference. This proves the branch choice under the stated outward arithmetic premises; coarse saved-trace overlap alone does not establish it.

### F.5. Uncertain wall location and exact terminal comparison {#app-O.5}

For every grid cell intersecting \(I_D=[D_-,D_+]\), evaluate (N6) on

\[
[\max(0,D_--s_j),\ \min(h,D_+-s_j)].
\tag{N8}
\]

The phase on each such clipped event interval is lifted into its whole-cell chart. The saved global endpoints are checked as exact rationals: the first starts at \(D_-\), every next starts where its predecessor ends, and the last ends at \(D_+\). Each engine has two event pieces. The hull of these lifted phase enclosures covers the true wall at the unknown \(D_*\); this is stronger than evaluating the phase at a numerical estimate of the wall.

The final intervals from both phase implementations for \(\theta_b(\mu=0)/\pi\) equal \([577838035/536870912,577858823/536870912]\). They lie strictly inside \([1076307/10^6,1076346/10^6]\). Their approximate finer endpoints are \(1.076307212933898\) and \(1.0763459336012602\). The coarser rational bound is sufficient: its upper endpoint is less than \(3/2\) by \(423654/10^6>0\). No floating-point threshold decision is needed. The auxiliary phase at \(\mu=-4k\) lies in \((\pi,3\pi/2)\), and its spectral derivative is positive. Therefore the interval from the auxiliary endpoint to physical zero mass crosses no admissible upper-wall angle. Appendix N.2 transfers this empty remaining band from the zero-Hessian corner to the full nonnegative family.

### F.6. Parameter-uniform roots and branch seams {#app-O.6}

For the families in Section 5.1, the shooting problem (N1) retains \(m^2,\gamma,v_0,\lambda_a\), and one upper-wall parameter varies as an outward interval of width \(1/1000\). Each subinterval has a frozen launch box. The parameter-uniform interval-Newton inclusion is strict, the wall event is the first transverse crossing, the enclosed warp remains positive, and both background implementations establish the endpoint signs and positive curvature. The primary producer uses 32768 cells and 768-bit arithmetic; the separate background implementation uses 8192 cells. Each phase engine consumes the complete linked launch and wall-event enclosure, including the parameter uncertainty. Its terminal hull lies strictly in \((1,3/2)\) after division by \(\pi\). The arguments of Appendix O.2-O.5 thus apply to every parameter point in the subinterval, not merely its centre.

At a shared parameter endpoint, adjacent launch boxes overlap and the enclosed derivative of the same event-reduced shooting function \(q\) has the same strict sign on both boxes. Their union is an interval on which \(q\) is strictly monotone. The unique root supplied in each box must therefore be the same root at the seam. Within each parameter box, the nonzero shooting derivative and transverse event give continuous root and wall-position dependence by the implicit-function theorem. Repeating the seam argument gives a single continuous branch on each uninterrupted certified run. The archived Newton image (31) lies strictly inside the frozen launch boxes of the subintervals containing the Appendix A parameter values: \(v_1\in[0.090,0.091]\) and \(\lambda_b\in[-6.0529,-6.0519]\), respectively. Uniqueness in each box therefore identifies its family root at that parameter with the archived root. The degenerate parameter control additionally reproduces the archived phase hull. This argument would not follow from overlapping root enclosures alone.

All seams pass along the full tension segment and the centre segment \([0.086,0.099]\). No seam is asserted across a failed subinterval. The complete-count proof is then applied separately at each background and does not identify individual mode eigenfunctions between different backgrounds. The saved parameter boxes, derivative signs, phase hulls and execution bindings are identified in supplementary Section S8. Outward arithmetic and the declared physical spectral correspondence remain premises; a successful execution is not an independent proof of the arithmetic library.

## Appendix G. Wall variation and the physical norm {#app-G}

\hypertarget{fw-action}{}

Use the wall action (FW1), with the bulk scalar trace as component zero. Write \(U_{,C}=\partial U/\partial z^C\) and evaluate the following equations before linearization:

\[
\begin{aligned}
2n\cdot\partial\Phi
&=U_{,0}-D_a(\mathsf K_{0B}D^az^B)
+\tfrac12(\partial_0\mathsf K_{AB})D_az^AD^az^B,\\
0&=U_{,C}-D_a(\mathsf K_{CB}D^az^B)
+\tfrac12(\partial_C\mathsf K_{AB})D_az^AD^az^B,
\quad C>0.
\end{aligned}
\tag{WV1}
\]

The factor two in the normal row follows from the doubled bulk; each wall action occurs once. The bulk trace is varied through the bulk scalar, while the independent rows are obtained by varying the wall fields. Before gauge fixing, the trace perturbation is \(f_i+T_i\xi_i\), where \(\xi_i\) is the wall graph. All background tangential derivatives vanish. Because the added potential has zero value and first derivative relative to the matched original wall, its stress difference starts at quadratic order, as does the added kinetic stress. Thus the original linear Israel equations and their generic tracefree consequence still remove \(\xi_i\) in longitudinal gauge after variation. No embedding was frozen independently. Smooth higher potential jets and derivatives of \(\mathsf K(z)\) do not enter these neutral linear equations.

With \(\Box_{\gamma_k}Q=\mu Q\), the tangential operator is \(\Box_{h_i}=a_i^{-2}\Box_{\gamma_k}\), yielding exactly (FW2). The kinetic pullback adds \(a_i^2z_i^\dagger\mathsf K_i z_i\) at each wall to (11); no second copy of this wall term occurs. The inherited bulk Green identity and the independent wall rows give, for two separated profiles,

\[
\begin{aligned}
\big[a^4(f_1L_2-L_1f_2)\big]'
&=(\mu_1-\mu_2)a^2(f_1f_2+6\psi_1\psi_2),\\
2\sigma_i(f_{1i}L_{2i}-L_{1i}f_{2i})
&=(\mu_1-\mu_2)a_i^{-2}z_{1i}^T\mathsf K_i z_{2i}.
\end{aligned}
\tag{WV2}
\]

Integrating with \(\sigma_a=1\), \(\sigma_b=-1\) therefore gives

\[
(\mu_1-\mu_2)
\left[2\int a^2(f_1f_2+6\psi_1\psi_2)\,ds
+\sum_i a_i^2z_{1i}^T\mathsf K_i z_{2i}\right]=0.
\tag{WV3}
\]

Taking the second mode to be the conjugate of the first proves reality for a nonzero physical separated mode. For a nonzero bulk profile the bulk norm is positive; for a pure-wall profile, \(f=\psi=0\) and \(M_i>0\) supply positivity. This statement concerns the retained original-action domain, including global distributional admissibility and vanishing four-dimensional surface flux. It neither counts exceptional harmonics nor constructs a complete Cauchy mode basis. Decoupled positive-kinetic massless spectators do not affect the negative count.



Figure 7 illustrates the monotone crossing used in this argument.

![Schematic nonincreasing static-branch response crossing the diagonal once inside a negative bracket.](figures/fixed_point.png){#fig:fixed_point}

**Figure 7.** Schematic fixed-point mechanism for Theorem 2. The nonincreasing function \(F_j(\mu)\) maps the negative bracket \(I_j\) into itself, whereas the diagonal is strictly increasing. The endpoint inequalities give a crossing; strict decrease of \(F_j-\mu\) gives uniqueness. The drawn curve is illustrative and is not an eigenvalue calculation.



## Appendix H. Flat slices and the zero-mass qualification {#app-P}

### H.1. Domain and restricted-index transfer {#app-P.1}

Use Minkowski slices in (1), with \(k=0\) in (9)-(11) and \(\lambda=\mu\). Retain reflection-preserving perturbations, the admitted endpoint gauge transformations, the global distributional equations, finite physical norm and vanishing four-dimensional surface flux. On noncompact slices the last condition requires the corresponding fall-off or wave-packet interpretation. The generic scalar harmonics have nonzero traceless Hessian. Within the separated wave-eigenfunction class the excluded zero-Hessian solutions are affine harmonics; nonconstant null plane waves have nonzero traceless Hessian and remain in the generic sector. The displaced-wall equation in (I12) reduces to a zero Hessian for the displacement, and hence removes it for generic harmonics. No action or junction step divides by \(k\).

In Appendix K the auxiliary function satisfies (J4) and is positive with positive derivative independently of \(k\). The regular map and its inverse depend on \(\lambda\); away from zero the same physical/transformed equivalence, finite-pole treatment and norm identity apply. At \(\lambda=0\), the representation (J25), positive endpoint factors and energy identity force the physical mode to vanish. The auxiliary kernel (J27) still has negative signature and has no physical inverse. Thus the physical zero exclusion persists when the shifted zero is the actual massless point.

Appendix L's regularity, compact wall launch and characteristic arguments use the same smooth coefficients and nonzero endpoint factors. Appendix M's comparison function has exactly the \(n\) zeros of \(T\); its augmented form has index \(n\), and removing the negative-signature kernel leaves exactly \(n\) physical negative eigenvalues. None of these steps uses \(k>0\). The spectrum and stiffness conclusions therefore transfer with \(\lambda=\mu\). The interval \((-4k,0)\) is empty, so the de Sitter remaining-band certificate is unnecessary. This specialization follows directly from the form-theoretic proof in Appendices K-M.

### H.2. One turn, finite wall fields and background existence {#app-P.2}

At \(k=0\), \(\mathcal Q=V_{,\Phi\Phi}+4T^2/3\). The proof of Lemma 1 works with \(\mathcal Q\ge0\): integration between two zeros gives a nonpositive derivative integral equal to a nonnegative potential integral, forcing the zero solution and contradicting the endpoint signs. At the unique crossing \(T'>0\). Since \((a^4T')'=a^4\mathcal QT\), its weighted derivative is no smaller on either side than its positive crossing value. Hence \(T'>0\) throughout. A convex bulk potential is sufficient for this criterion; the three-turn illustration does not satisfy that convexity condition.

For \(\mu<0\), \(B_i=(\mathsf H_i)_{\chi\chi}+(-\mu/a_i^2)M_i\) is positive definite exactly as in Theorem 2. The Schur response, monotone fixed-point argument and norm identity give one simple root for each of the \(n\) negative static branches. The higher static branches are positive for every effective nonnegative wall pair, so they cannot supply another negative root. At \(\mu=0\), however, the kinetic contribution vanishes. If \((\mathsf H_i)_{\chi\chi}>0\), its Schur complement is nonnegative and zero-mass elimination reduces to the pure-potential problem, whose zero mode was excluded above. If that block is singular, positivity of the full potential matrix forces its kernel to decouple from the trace; each nonzero kernel vector gives a massless wall spectator with vanishing bulk trace. The negative count remains valid, but an unqualified enlarged-system zero-mode exclusion does not.

Existence of a flat background is a separate requirement. For any regular solution of (9) with \(k=0\) on a chosen compact interval, prescribe the wall values and slopes by \(\tau_a=-6H_a\), \(\tau'_a=2T_a\), \(\tau_b=6H_b\), and \(\tau'_b=-2T_b\). Quadratic walls can realize these values and slopes; nonnegative perturbative Hessians can then be prescribed without changing that background. For fixed wall potentials, the flat junction conditions generically impose one compatibility relation among the wall data (one fine-tuning, as in [7; Section 2.1]). Here the upper-wall values and slopes are instead determined by the integrated solution; they are not prescribed independent rational inputs. This construction therefore does not assert flatness for arbitrary fixed wall data. Supplementary Section S9 distinguishes exploratory spectra from the interval-enclosed example.
