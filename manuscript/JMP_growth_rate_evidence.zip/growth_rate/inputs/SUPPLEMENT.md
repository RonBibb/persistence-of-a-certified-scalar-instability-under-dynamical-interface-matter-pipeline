# Supplementary material: Scalar instability counts for de Sitter two-brane backgrounds with dynamical wall fields

## Reading guide

The article contains the main results, their mathematical proofs and numerical implication arguments in its eight appendices. This supplement gives the full bulk action reconstruction (Section S1), extended literature comparisons (Section S2), implementation and evidence details (Section S3), static relaxation and rank-loss examples (Section S4), canonical oscillator specialization (Section S5), matrix response and inertia limits (Section S6), and a separate concave example (Section S7). Section S8 gives the certified parameter-family records, Section S9 gives flat-slice examples, and Section S10 derives the growth-rate interpretation and brackets. The separate concave example includes its background construction and remaining-band proof.

## S1. Bulk action reconstruction and kinetic norm {#app-J}

This section treats the pure-potential action (1), before applying the finite wall-field extension of Section 4. Here \(\nu_{\rm met}\) is the metric lapse perturbation, not material density; \(\mathcal X\) is a gauge compensator, not a surface oscillator. In this pure-potential calculation, \(Z=Z_A\) is the original-action norm of manuscript (11). The lower/upper signs and background are those of manuscript (4), (8)–(10).

### S1.1. Variation and constraints {#app-J.1}

The matching uses the Darmois–Israel framework [13, 14]; the reflected-wall specialization is described in manuscript Section 2.2. The pure-potential interval action is twice the bulk integral, with twice the usual Einstein Gibbons–Hawking boundary term (coefficient one per copy when the Einstein bulk coefficient is one half), and each wall potential once. The Gibbons–Hawking term uses the outward normal; the junction formulas of manuscript (4) use inward normals. Vary the lapse, scalar shift and tangential metric before fixing longitudinal gauge. Fixing the scalar shift and scalar shear in the action prematurely would lose the momentum and traceless tangential equations; varying the lapse still supplies the Hamiltonian constraint. Varying all components first retains the complete system. The bulk equations are Einstein's equation with cosmological term -6 and the canonical scalar stress, together with \(\nabla^2\Phi-V_{,\Phi}=0\). Their background components give manuscript (9); the boundary variations give manuscript (4) in its pure-potential form.

For a scalar harmonic \(Q\), define

\[
\mathcal H_{\alpha\beta}[Q]
=D_\alpha D_\beta Q-\tfrac14\gamma_{\alpha\beta}\Box_\gamma Q.
\tag{I1}
\]

Before fixing longitudinal gauge, write
\[
\delta g_{ss}=2\nu_{\rm met} Q,\quad \delta g_{s\alpha}=bD_\alpha Q,\quad
\delta g_{\alpha\beta}=2a^2\{\psi\gamma_{\alpha\beta}Q+E D_\alpha D_\beta Q\}.
\]
For \(X^s=\alpha Q\), \(X^\alpha=\beta D^\alpha Q\), with \(\delta g\mapsto\delta g-\mathcal L_Xg\), the transformations are
\[
E\mapsto E-\beta,\quad b\mapsto b-\alpha-a^2\beta',\quad
\psi\mapsto\psi-H\alpha,\quad \nu_{\rm met}\mapsto\nu_{\rm met}-\alpha',\quad
f\mapsto f-T\alpha.
\tag{I2}
\]
Choosing \(\beta=E\), \(\alpha=b-a^2E'\) gives \(E=b=0\) without an inverse warp gradient, scalar gradient or spectral parameter. These are scalar diffeomorphisms of the general perturbation; the lapse, shift and traceless equations have already been varied. Equivalently, \(\mathcal X=b-a^2E'\) transforms as \(\mathcal X\mapsto\mathcal X-\alpha\), so
\[
\widehat\psi=\psi-H\mathcal X,\quad \widehat f=f-T\mathcal X,\quad
\widehat\nu_{\rm met}=\nu_{\rm met}-\mathcal X',\quad \widehat\xi_i=\xi_i+\mathcal X_iQ
\tag{I3}
\]
are gauge invariant within this regular scalar sector. They equal the longitudinal profiles and wall graph after the stated gauge choice. Thus the finite kinetic norm in Appendix L may be specified on \((\widehat\psi,\widehat f)\); no inverse gradient is hidden in that identification. No assertion is made that bare finite signed action alone supplies all required metric/gauge regularity. The generic sector has a nonvanishing traceless Hessian and a nonconstant harmonic. The traceless tangential equation gives \(\nu_{\rm met}=-2\psi\). The mixed equation is

\[
\psi'-H\nu_{\rm met}=-Tf/3.
\tag{I4}
\]

In proper distance the perturbed Hamiltonian equation has

\[
\begin{gathered}
\delta R[h]/Q=-6a^{-2}(\mu+4k)\psi,\\
\delta G_{nn}/Q=3a^{-2}(\mu+4k)\psi+12H(\psi'-H\nu_{\rm met}),\\
\delta T_{nn}/Q=T(g-\nu_{\rm met}T)-V_{,\Phi}f.
\end{gathered}
\tag{I5}
\]

Equating the last two expressions, using (I4), \(T'=V_{,\Phi}-4HT\), and \(\nu_{\rm met}=-2\psi\), yields the constraint in manuscript (10). Direct variation of the scalar equation gives

\[
f''+4Hf'+(\mu/a^2-V_{,\Phi\Phi})f
 +(4\psi'-\nu_{\rm met}')T-2\nu_{\rm met} V_{,\Phi}=0.
\tag{I6}
\]

Substitution of (I4) gives the scalar row of manuscript (10). The background identities and manuscript (10) imply \(C'=-4HC\), so \(a^4C\) is conserved. At a scalar turn \(T=0\), the constraint is the finite relation \(T'f+3(\mu+4k)\psi/a^2=0\); the scalar equation (I6) is still imposed. There is no new interior boundary or freely chosen matching datum.

For explicit sufficiency, put \(q=\psi'-H\nu_{\rm met}\). The unreduced tangential Einstein variation in longitudinal gauge is
\[
\delta G_\alpha{}^\beta
=-\frac{2\psi+\nu_{\rm met}}{a^2}D_\alpha D^\beta Q
+\left[\frac{(2\mu+6k)\psi+\mu\nu_{\rm met}}{a^2}
+3q'-3\nu_{\rm met} H'+12Hq\right]Q\delta_\alpha{}^\beta,
\tag{I7}
\]
while \(\delta T_\alpha{}^\beta=(-Tg+\nu_{\rm met} T^2-V_{,\Phi}f)Q\delta_\alpha{}^\beta\). The cosmological term has zero mixed-index variation. One way to derive (I7) is to use
\[
R_\alpha{}^\beta=R[h]_\alpha{}^\beta-N^{-1}\partial_sK_\alpha{}^\beta
-KK_\alpha{}^\beta-N^{-1}D_\alpha D^\beta N,
\]
\[
R_{nn}=-N^{-1}\partial_sK-K_\alpha{}^\beta K_\beta{}^\alpha-N^{-1}\Box_hN,
\qquad K_\alpha{}^\beta=(H+qQ)\delta_\alpha{}^\beta,
\]
with \(N=1+\nu_{\rm met} Q\) and the intrinsic conformal-curvature variation. These identities fix the signs of both normal and tangential components.

Define the momentum residual \(M=q+Tf/3\). After the generic traceless equation is imposed, the full remaining tangential residual \(\delta(G-6g-T)_\alpha{}^\beta=\mathcal E_{\rm tan}Q\delta_\alpha{}^\beta\) obeys
\[
\mathcal E_{\rm tan}=3q'+12Hq+Tg+V_{,\Phi}f
 +(6k/a^2+6H'+2T^2)\psi
=3M'+12HM.
\tag{I8}
\]
The last bracket vanishes by the background \(H'\) equation; the remaining equality uses \(T'+4HT=V_{,\Phi}\). Thus momentum and traceless equations imply the omitted tangential equation through both \(T=0\) and \(H=0\). The normal residual is \(-C\), and direct differentiation gives
\[
C'=-4H\{Tg-T'f+(2T^2-3\lambda/a^2)\psi\}=-4HC.
\tag{I9}
\]
Necessity of the retained system follows from the varied equations; (I7)–(I9) establish its bulk sufficiency in the classical generic scalar sector. This is a scalar-sector reconstruction, not a classification of vector or tensor perturbations.

### S1.2. Finite walls and bending {#app-J.2}

Before setting the bending to zero, take a wall graph \(s=s_i+\xi_i(x)\). With \(\sigma_a=+1\), \(\sigma_b=-1\), its scalar boundary variation is

\[
\sigma_i[g-\nu_{\rm met} T+T'\xi_i]
=\tfrac12\kappa_i(f+T\xi_i).
\tag{I10}
\]

Harmonic factors are understood for the profile terms. Its mixed extrinsic curvature varies as

\[
\delta K_\alpha{}^\beta
=\sigma_i\{[\psi'-H\nu_{\rm met}+H'\xi_i]\delta_\alpha{}^\beta
-a_i^{-2}D_\alpha D^\beta\xi_i\}.
\tag{I11}
\]

In the full Israel condition the \(f\) terms cancel by (I4). The identity \(H'+T^2/3=-k/a^2\) leaves

\[
D_\alpha D_\beta\xi_i+k\gamma_{\alpha\beta}\xi_i=0.
\tag{I12}
\]

For clarity, before this last reduction the entire Israel condition, after its inward orientation is divided out, is
\[
MQ\delta_\alpha{}^\beta+(H'+T^2/3)\xi_i\delta_\alpha{}^\beta
-a_i^{-2}D_\alpha D^\beta\xi_i=0.
\tag{I13}
\]
Here the background relation \(\tau_{i,\Phi}=2\sigma_iT_i\) cancels the scalar terms. With \(M=0\), it is exactly (I12). Under (I2) the graph changes by \(\xi_i\mapsto\xi_i+\alpha_iQ\). Therefore zero bending in longitudinal gauge is a physical consequence of the generic Israel equation, not a second independent gauge choice imposed at both ends.

For generic harmonics the bending amplitude must vanish. Equation (I10) then gives the neutral wall law \(2\sigma_i L_i=\kappa_i f_i\), including its half-Hessian and opposite endpoint signs. The trace Israel perturbation is already (I4), not a second independent scalar wall condition. Nonconstant embedding harmonics satisfying (I12) obey \(\Box_\gamma\xi_i=-4k\xi_i\), but that necessary scalar equation is weaker than (I12). Consequently this sector distinction does not discard every generic mode with \(\mu=-4k\). Constant harmonics also require separate gauge analysis; none is included by assuming that it represents a generic propagating mode. The distinction at shifted zero is nonvacuous: on a flat-slicing de Sitter patch, \(Q=e^{-4\sqrt{k}\,t}\) has \(\Box_\gamma Q=-4kQ\) but a nonzero traceless Hessian, since its temporal/spatial Hessian difference is proportional to \(20kQ\). It is a local generic example, not a claim of spacetime square integrability. The absence of a physical radial mode at \(\lambda=0\) follows from the wall and energy argument, not from excluding all harmonics at that mass.

The first variation of proper separation is

\[
\delta D(x)=\int_0^D\nu_{\rm met}(s,x)\,ds+\xi_b(x)-\xi_a(x).
\tag{I14}
\]

The lapse and endpoint changes cancel under a transverse coordinate transformation. For the retained generic modes, \(\delta D/Q=-2\int\psi\,ds\). A nonzero overlap establishes a separation component; positive norm alone does not establish this overlap.

### S1.3. Kinetic coefficient and boundary terms {#app-J.3}

The joint terms at intersections with four-dimensional boundaries and the tangential acceleration divergence are four-dimensional surface contributions. They vanish under the stated surface-flux condition; they are not additional radial kinetic weights. After the normal total derivatives have been canceled by the Gibbons–Hawking terms, the four-dimensional derivative terms at quadratic order are

\[
S_{2,\partial x}=2\int ds\,d^4x\sqrt{-\gamma}\,a^2
\left[-\tfrac12(Df)^2+3\{D\nu_{\rm met}\cdot D\psi+(D\psi)^2\}\right].
\tag{I15}
\]

To verify the gravitational coefficient, expand \(N\sqrt{-h}R[h]/2\), with \(N=1+\nu_{\rm met}\), \(h=a^2e^{2\psi}\gamma\), and
\(R[e^{2\psi}\gamma]=e^{-2\psi}[R[\gamma]-6\Box\psi-6(D\psi)^2]\).
The factor multiplying the bracket is \(a^2(1+\nu_{\rm met})e^{2\psi}/2\). Four-dimensional integration by parts gives \(3D\nu_{\rm met}\cdot D\psi+3(D\psi)^2\). This calculation assumes compactly supported variations or vanishing four-dimensional boundary flux. The scalar kinetic term contributes \(-a^2(Df)^2/2\). The extrinsic-curvature terms in this gauge contain normal derivatives; \(R[\gamma]=12k\) changes potential terms. Pure wall potentials have no tangential kinetic terms when \(\xi_i=0\). No wall kinetic term has been dropped from the declared action.

Substitution of \(\nu_{\rm met}=-2\psi\) into (I15) gives the coefficient of \(-\tfrac12\int\sqrt{-\gamma}(DQ)^2\):

\[
Z=2\int_0^D a^2(f^2+6\psi^2)\,ds.
\tag{I16}
\]

The initial factor two is the cover multiplicity. The canonical amplitude is \(Q_c=\sqrt Z Q\). This derivation uses no inverse scalar gradient and remains regular at a turn. Negative \(\mu\) with positive \(Z\) is a tachyonic instability in this sector. It is not a negative-kinetic-energy mode. This is the pullback of the original-action kinetic form to admissible profiles, with vanishing four-dimensional surface flux. It does not identify an unrestricted off-shell master action or a complete operator domain. Appendix L supplies the finite-norm weak/classical mode-domain statement needed for the separated count.

## S2. Closest literature: equations and assumptions {#app-I}

Frolov--Kofman [4] already exhibit the de Sitter shift in their equations 8--9. Their equation 14 gives finite-potential matching and equation 16 its rigid limit; the self-adjoint problem and mass estimate in equations 17--20 use that rigid limit. Their scalar variable and positive weight divide by the background scalar derivative, so those expressions cannot be transferred through a scalar turn without a separate domain argument. Their Section III sets the brane displacement to zero in the absence of brane-matter perturbations, apart from excluded global displacements. Their equation 21 already gives the growing de Sitter exponent used in Section S10. The growth law, curvature shift, radion instability and stiffness dependence are not new here. The unstabilized radion [43, 44, 18], the curvature contribution for the compactification class of [45], equal to \(-4k\) for one extra dimension, and the conjectured link between non-monotonic stabilizing profiles and tachyons [46] are precedents. Our count strengthens that physical interpretation to exactly \(n\) radial modes with growing exponents above the expansion rate, uniformly over the declared wall class; it does not identify those branches with the unstabilized radion.

Lesgourgues--Sorbo [5] do not simply stop at that singular variable. Their equations 12--15 introduce a Mukhanov-type variable regular through a scalar-derivative zero, provided the warp logarithmic derivative is nonzero. Their equations 16--17 include finite wall Hessians. Their setting has flat four-dimensional slices. Thus regular passage through a scalar turn is an explicit precedent. The present retained system (10), its original-action domain, curved-slice characteristic and complete certified count are the more specific objects requiring comparison.

Konikowska--Olechowski--Schmidt [6] include inflating backgrounds: their equation 24 is the shifted Sturm--Liouville problem, equation 29 the variational characterization, and equation 30 a trial-function bound. Their subsequent analytic stability discussion specializes to flat slices (their \(H=0\)). The turning-profile argument uses the Mukhanov-type variable in equations 33--35, which contains inverse warp gradients. The end of their stability section removes the warp-gradient restriction for backgrounds with nonvanishing scalar derivative and Gauss--Bonnet coefficient \(\xi\); that regularity argument does not cover a scalar turn. In contrast, our reconstruction in Appendix K divides by neither \(T\) nor \(H=a'/a\) and retains its stated domain at zeros of either quantity. This distinguishes the scope of the turning-profile count without claiming the first removal of a warp-gradient assumption. The principal additions remain the exact curved-slice count, finite-wall-field persistence and linked certified remaining-band exclusion.

Olechowski [7] studies a canonical five-dimensional Einstein-scalar action with brane potentials on a warped product with four-dimensional Minkowski slices; see his equations 1-2 and Section 4. His necessary-and-sufficient stability conditions include intermediate branes and reduce to earlier two-brane results when these are absent. This is a direct spectral precedent, including the role of a vanishing background scalar derivative. The flat-slice criteria do not transfer unchanged to the shifted mass band of the curved problem. Under (RT1), the endpoint parameters in [5, 6, 7] are positive, so the established flat results already exclude a massless radion and imply at least one tachyon for a turning profile; [5] also fixes the parity. The flat-slice corollary refines these conclusions to an exact count with simplicity, stiffness brackets and persistence under the declared finite wall fields. For de Sitter slices, Proposition 1 and the family corollary instead obtain complete counts using linked background and phase enclosures. No multibrane stability criterion is claimed here.

Girmohanta et al. [8], Section 2.2, derive eigenvalue-dependent finite-potential boundary conditions and a generalized scalar product with endpoint terms; their equations 2.42-2.46 restore mode orthogonality, and their Appendix A connects the product to kinetic mixing. They explicitly note that this product need not be positive in general. Their Minkowski-slice superpotential background and finite-potential mass analysis are therefore close precedents for the present boundary-norm calculation. Here Appendix J obtains the physical kinetic coefficient from the original doubled action. Appendix K then identifies the different, auxiliary indefinite endpoint product introduced by the regular scalar transformation, and Appendix M removes its artificial negative-signature kernel before the physical count. Boundary terms or generalized orthogonality alone do not supply this reconstruction or the complete count. The dynamical oscillator norm in (16) and monotone response in (17)-(20) are additional ingredients of the declared completion.


Karmakar--SenGupta [10; Secs. 4.1 and 4.5] analyze the effective four-dimensional scalar-tensor radion on the branes, including bulk-potential and brane-matter contributions. Their FLRW-brane calculation with the Randall--Sundrum warp ansatz gives a homogeneous radion equation and removes Hubble friction by rescaling its amplitude [10; Eqs. (108)--(110)]. This addresses the effective radion dynamics, not a count of the full coupled five-dimensional radial spectrum through scalar turns. Their de Sitter condition \(\mu_{\rm eff}^2<9H^2/4\) concerns exponential growth of the rescaled variable \(u=a^{3/2}\delta\varphi\). For constant de Sitter coefficients, the physical amplitude \(\delta\varphi\) grows only when \(\mu_{\rm eff}^2<0\), as follows directly from their damped equation. Here the growth criterion is read directly from that physical amplitude, while the radial masses and their count come from Theorems 1--2.

Matter-supported equilibria [9], matter-induced radion tachyonicity in effective theories [10] and effective-potential stabilization criteria [11] concern different backgrounds or matter assumptions. They rule out interpreting the present result as a general statement that brane matter cannot stabilize an extra dimension. Our obstruction uses the stated endpoint signs, generic physical domain and nonnegative finite wall forms.

Martin et al. [17; Section 5.1 and Figure 5] numerically evolve departures from unstable static de Sitter two-brane configurations and examine collisions [17; Section 6]. These locators refer to hep-th/0309001v1. They provide nonlinear context; this paper makes only separated-spectrum claims. The nonlinear radion analyses of Binétruy, Deffayet and Langlois [18] and Langlois and Sorbo [19] likewise address dynamical questions beyond the count.

The contribution to assess is the restricted curved-slice count with its explicit physical-domain reconstruction, the finite wall-field persistence result, the certified remaining-band exclusion on the anchor and its two upper-wall families, and the exact flat-slice refinement. This comparison does not establish historical priority or replace specialist assessment of the result's usefulness.

**Comparison with earlier boundary-field models.** Koyama, Mennim and Wands [35; Eqs. (2.1)-(2.7)] and Cardoso et al. [36; Eq. (9)] couple a bulk test scalar to an independent scalar on a Minkowski or de Sitter brane in AdS. Their local boundary potential has the form \(\beta\phi q+\tfrac12m_b^2q^2\). In our trace/independent-field convention its Hessian has determinant \(-\beta^2\), so nonzero coupling falls outside the nonnegative total wall-Hessian class. Their coupling-induced tachyonic thresholds therefore concern a different action class. Cardoso et al.'s possible two bound states must also be distinguished from two negative mass-squared eigenvalues. Here the compact bulk interval, coupled scalar-gravity equations and scalar-turn reconstruction determine the physical counting problem.

George's Robin-plus-oscillator Hamiltonian [37; Eq. (14)] includes a trace-square term \(\tfrac12\lambda\phi^2\); for \(m_b^2>0\), its boundary Hessian is nonnegative when \(\lambda m_b^2\ge\beta^2\). Thus nonnegative oscillator completions and their rational boundary responses have direct precedents. Dappiaggi, Ferreira and Juárez-Aubry [38; Section III A] derive Wentzell boundary dynamics from a kinetic action on the bulk trace. Their boundary value is constrained to equal that trace, rather than supplying another independent scalar. These fixed-background problems motivate the wall constructions; the original-action gravitational norm and complete negative count require the reconstruction used here.

Koyama, Langlois, Maartens and Wands [41; Sections V–VI] give a complementary physical-domain caution: apparently tachyonic bulk master modes need not yield allowed growing solutions after the coupled brane equations are imposed. Their master mass parameter is not identified with the physical \(\mu\) used here. Our count retains the wall equations, global distributional domain and original-action norm throughout.

## S3. Numerical dependencies and evidence access {#app-H}

The analytic restricted count and wall-field persistence require a background satisfying their explicit hypotheses and the physical spectral correspondence. They use no numerical phase bound. The complete-count application uses two linked numerical premises: the background/root linkage and the zero-mass phase enclosure summarized in Table 6.



Appendix O states the predicates and their mathematical justification. Identified source execution and outward Arb arithmetic remain premises. The two recurrence implementations share arithmetic and chart mathematics; agreement between them is not an independent arithmetic proof. A small residual, a terminal sign or overlapping approximate roots is insufficient. Source hashes establish provenance, not the validity of an interval calculation by themselves.

The background and phase premises are distinct: the phase run consumes the linked background enclosures rather than proving background existence. The background certificate retains the wall parameter 20 in the shooting equations while the phase problem uses zero perturbative Hessians. Root uniqueness links the execution records to the exact action. The positivity of \(T'\) follows from Lemma 1 and is not an additional numerical assumption.

The public pipeline preserves source/result identities, proof ledgers and saved-record verification instructions. Saved-record and exact-arithmetic algebra checks are distinguished from producer execution: the former cannot regenerate an interval trajectory. The Data availability statement identifies the versioned public records.

### S3.1. Implementation and saved-trace details {#implementation-details}

The high-resolution background implementation supplies the exact narrow root image and event interval. A separately written implementation supplies local root and geometry enclosures on the common frozen launch box. The phase computation consumes these enclosures; it does not prove background existence. Larger global covers and simultaneous-wall Jacobians are not premises of the local complete-count application.

The spectral calculation propagates the background and regular scalar equations together. The primary state is
\(Y=(W,H,\Phi,T,\mathcal E,\psi,f,g)\), where \(\mathcal E=e^{-W}\) obeys \(\mathcal E'=-H\mathcal E\), \(\mathcal E_a=1\); occurrences of \(a^{-2}\) become \(\mathcal E^2\). The second implementation propagates \((W,H,\Phi,T,\psi,f,g)\) and evaluates \(e^{-2W}\) directly. Both use equations (9) and (10), fixed \(\mu=0\), and the same exact inputs. They are separately written recurrence implementations, but share the Arb arithmetic library [31] and background/theorem premises.

Starting from \(3\pi/2\), add an integer multiple of \(2\pi\) to the new chart so that it agrees with the previous lifted endpoint. Floating arithmetic proposes this integer, but does not certify it. Acceptance requires outward-ball verification that the shifted chart is at distance strictly less than \(\pi\) from the preceding reference midpoint and overlaps the preceding endpoint interval. The new endpoint is evaluated with (N6), assigned its own half-plane chart and checked for the same unambiguous lift and overlap with the whole-cell chart. These checks, together with whole-cell nonvanishing, propagate the chosen continuous phase, rather than relying on sampled unwrapping.

The saved compact traces export angle bounds divided by \(\pi\) using exact rational floor/ceiling at denominator \(2^{40}\). This outward trace coarsening does not replace the higher-precision producer checks. Rechecking saved trace overlap authenticates a necessary consistency property; the traces alone do not reconstruct (N5), (N6) or the elementary-function bounds.

The primary cell width is \(2/8192\); the second is \(2/16384\). Both use 768-bit ball arithmetic, giving 8,183 and 16,365 cells respectively through the upper end of \(I_D\).

### S3.2. Figure records and interpretation {#figure-evidence}

Figure 5 renders the archived rational whole-cell intervals and clipped uncertain-wall event pieces. The two implementations share Arb arithmetic; no independent arithmetic certification is inferred from their agreement. The plotting generator reads saved records and evaluates stated finite-dimensional formulas, without integrating a background or solving an eigenvalue problem. Conversion to plotting coordinates is only a visual representation: the exact rational input records and published endpoint hull remain the numerical statements.

The whole-cell phase intervals are distinct from the narrower grid-endpoint intervals. The final grid endpoints lie beyond the upper end of the wall interval; neither is substituted for the true wall. The terminal panel instead shows the two clipped event pieces from each implementation and the published hull. The archived background profile stores multiprecision numerical samples; it is an illustration, not an interval enclosure. Source identities, a generator and rendering checks accompany the figures.

### S3.3. Verification scope and reproducibility {#derivation-review}

The action calculation in Section S1 and Appendix G derives the bulk equations, constraint propagation, displaced-wall conditions, physical kinetic norm and finite-wall rows. Appendix L separately proves the global weak-domain/classical-mode correspondence; a finite algebraic test cannot replace that domain argument.

The accompanying algebraic checks cover 40 exact-rational curvature cases and 24 radial-identity groups. They test the doubled-cover normalization, constraint identities and kinetic terms, but do not replace their analytic derivation. Background and phase controls reproduce (14) and check that both implementations consume the interval-valued wall parameters. These controls use the same Arb backend and do not establish arithmetic independence.

## S4. Finite local wall fields: derivation and static reduction {#fw-details}

This section develops normal forms and static relaxation for article Theorem 2. The full wall variation is in Appendix G. The certified complete-count application retains Proposition 1's numerical premises. The separate concave example in Section S7 has its own background and remaining-band premises.

### S4.1. A trace-preserving normal form {#fw-normal}

At one wall suppress the subscript and write

\[
\mathsf H=\begin{pmatrix}h_0&b^T\\b&A\end{pmatrix},\qquad
\mathsf K=\begin{pmatrix}d&e^T\\e&M\end{pmatrix},\qquad
\widetilde u=u+M^{-1}ef,\qquad
d_0=d-e^TM^{-1}e\ge0.
\tag{NF1}
\]

This invertible change leaves the physical trace \(f\) unchanged and makes the kinetic form \(d_0f^2+\widetilde u^TM\widetilde u\). Whiten \(M\) and orthogonally diagonalize the transformed independent potential block. Denote its eigenvalues by \(\lambda_j\ge0\), its trace couplings by \(\widetilde b_j\), and its trace coefficient by \(\widetilde h_0\). Congruence preserves potential positivity, so \(\widetilde b_j=0\) whenever \(\lambda_j=0\). For \(x=-\mu/a^2>0\), the response is

\[
\begin{gathered}
\Gamma(x)=s_0+d_0x+
\sum_{\lambda_j>0}c_j\frac{x}{\lambda_j+x},\qquad
c_j=\frac{\widetilde b_j^2}{\lambda_j}\ge0,\\
s_0=\widetilde h_0-
\sum_{\lambda_j>0}\frac{\widetilde b_j^2}{\lambda_j}
=h_0-b^TA^\dagger b\ge0.
\end{gathered}
\tag{NF2}
\]

The last equality follows because both expressions minimize the same potential over all independent amplitudes at \(f=1\). The Moore-Penrose inverse is valid: \(\mathsf H\ge0\) implies \(b\perp\ker A\). This range condition and nonnegativity of the generalized Schur complement are the standard pseudoinverse criterion for a positive semidefinite block matrix [39]. Consequently \(\Gamma(0)=s_0\) for each fixed wall system and \(d\Gamma/dx\ge0\). Zero restoring modes remain massless fields in the undivided system; the rational response is not a list of every wall mode. In particular an uncoupled massless wall field contributes no pole to \(\Gamma\).

Finite coupled matrices largely reduce to this change of normal coordinates. The affine term \(d_0x\), nonnegative rational terms and zero restoring directions clarify what the enlarged action admits beyond the selected positive-frequency oscillator. The general spectral treatment of rational boundary functions is established [32, 33], and localized scalar kinetic terms already occur in brane stability analysis [34]. We apply these established methods to the declared model.

### S4.2. Static reduction of the negative count {#fw-count}

**Proposition S1 — static relaxation.** Assume a fixed bulk background whose constant nonnegative wall-Hessian problems have a real, discrete, bounded-below physical separated spectrum, with simple ordered branches \(\alpha_j(\kappa_a,\kappa_b)\) continuous and nondecreasing in each finite Hessian. Assume the physical characteristic correspondence and norm response used in the article, with finitely many negative branches at each fixed pair. For finite wall matrices satisfying (FW1), define

\[
\mathsf H_i=\begin{pmatrix}h_{0i}&b_i^T\\b_i&A_i\end{pmatrix},\qquad
s_i=h_{0i}-b_i^TA_i^\dagger b_i.
\tag{SC1}
\]

Then, counting negative radial eigenvalues with multiplicity,

\[
N_-(\text{full dynamical walls})
=N_-(\text{static walls with Hessians }s_a,s_b).
\tag{SC2}
\]

**Proof.** Positivity gives \(s_i\ge0\); (NF2) gives \(\Gamma_i(\mu)\ge s_i\) for \(\mu<0\) and a continuous limit \(s_i\) at zero. For each branch set \(F_j(\mu)=\alpha_j(\Gamma_a(\mu),\Gamma_b(\mu))\) and \(a_j=\alpha_j(s_a,s_b)\). If \(a_j<0\), then \(F_j(a_j)\ge a_j\), while \(F_j(0)=a_j<0\). The continuous function \(F_j(\mu)-\mu\) is strictly decreasing, so has exactly one zero in \([a_j,0)\). If \(a_j\ge0\), then \(F_j(\mu)\ge a_j\ge0\) and there is no negative fixed point. Invertibility of \(A_i-\mu M_i/a_i^2\) excludes negative pure-wall modes and gives both directions of the physical correspondence. Two branches cannot share a fixed point, because the static eigenvalue at that same pair would then be repeated. The positive norm-slope identity gives simplicity of each full root. These finitely many roots exhaust the negative spectrum. \(\square\)

The hypotheses are separated spectral hypotheses, not a claim about arbitrary Cauchy data. They must be checked for each bulk model. The matrix positivity criterion [39] supplies the relaxed Hessians; the physical spectral correspondence and its continuity qualification are separate steps. For the article's exact background the spectral hypotheses follow from its physical reconstruction and positive reduced form. Since its static negative count is one at every nonnegative pair, (SC2) recovers the wall-field conclusion of Proposition 1. If \(A_i>0\), bulk-coupled massless modes correspond to the static problem at \((s_a,s_b)\). If \(A_i\) is singular, its kernel amplitudes must also be retained at zero mass; the negative count does not exclude those states.

### S4.3. The rank-loss qualification {#fw-rank}

At fixed potential Hessians \(\mathsf H_i\), any admissible change of kinetic matrices preserves the negative count. Along a continuous potential family for which the relaxed Hessians \(s_i\) remain continuous, a change of this count requires meeting a static massless locus. Locally constant rank of \(A_i\), in particular \(A_i>0\), is a sufficient condition for this continuity. The unqualified claim for all continuous potential families is false: loss of rank can create pure-wall zero modes while the relaxed Hessian jumps. No constant-rank assumption is needed for the pointwise theorem (SC2).

For an explicit counterexample attach, at both walls of the separate background in Section S7,

\[
\mathsf H(\varepsilon)=
\begin{pmatrix}1&-\varepsilon\\-\varepsilon&\varepsilon^2\end{pmatrix},
\qquad \mathsf K=\operatorname{diag}(0,1),\qquad\varepsilon\ge0.
\tag{RL1}
\]

Here \(z^T\mathsf H z=(f-\varepsilon u)^2\ge0\) and \(M=1\). For \(\varepsilon>0\), \(A=\varepsilon^2\), \(b=-\varepsilon\), so \(s=0\); at \(\varepsilon=0\), the pseudoinverse gives \(s=1\). Thus the relaxed pair jumps from \((0,0)\) to \((1,1)\). The count in Section S7 is two before rank loss and one at rank loss, with two additional pure-wall massless fields at the endpoint. For \(x>0\),

\[
\Gamma(x,\varepsilon)=\frac{x}{\varepsilon^2+x},\qquad
\lim_{\varepsilon\to0^+}\lim_{x\to0^+}\Gamma=0,
\qquad
\lim_{x\to0^+}\lim_{\varepsilon\to0^+}\Gamma=1.
\tag{RL2}
\]

This adverse example explains the missing continuity hypothesis. It changes the potential Hessian, so it does not contradict fixed-potential kinetic invariance, the pointwise count theorem, or the fixed-potential large-inertia example below.

### S4.4. Concrete finite wall systems {#fw-examples}

A mixed representation is furnished by the positive-definite matrices

\[
\mathsf H=\begin{pmatrix}3&-1&-1\\-1&2&1\\-1&1&2\end{pmatrix},
\qquad
\mathsf K=\begin{pmatrix}2&1&0\\1&3&1\\0&1&2\end{pmatrix}.
\tag{EX1}
\]

Their leading principal minors are respectively \((3,5,7)\) and \((2,5,8)\). Direct elimination and (NF2) agree:

\[
\begin{aligned}
\Gamma(x)&=\frac{7+29x+31x^2+8x^3}{3+8x+5x^2}\\
&=\frac73+\frac85x+\frac12\frac{x}{1+x}
+\frac{121}{150}\frac{x}{3/5+x},\\
\frac{d\Gamma}{dx}&=\frac85+\frac{1}{2(1+x)^2}
+\frac{121}{250(3/5+x)^2}>0.
\end{aligned}
\tag{EX2}
\]

The semidefinite potential \(\mathsf H=\left(\begin{smallmatrix}1&-1\\-1&1\end{smallmatrix}\right)\), with \(\mathsf K=\operatorname{diag}(0,1)\), instead gives \(\Gamma=x/(1+x)\) and \(s_0=0\). It is admitted by Theorem 2 although the earlier requirement of a strictly positive bare oscillator frequency excludes it. Finally \(\mathsf H=\operatorname{diag}(1,0)\) and the same \(\mathsf K\) give \(\Gamma=1\) together with an independent massless spectator. Increasing only that spectator's inertia leaves the bulk response unchanged. These examples are exact finite-dimensional calculations, not numerical spectra.

## S5. Canonical oscillator specialization {#app-B}

At each wall add a canonical independent scalar with centered interaction

\[
W_i=\frac{\omega_i^2\chi_i^2}{2}
+\frac{\beta_i}{2}\left[\chi_i-\eta_i(\Phi-\Phi_i^*)\right]^2,
\quad \omega_i^2>0,\quad\beta_i\ge0.
\tag{2}
\]

The full wall potential is \(\tau_i+W_i\). The centers \(\Phi_i^*\) are the exact background traces, and the independent field has background value zero. The interaction and its first derivatives vanish there. This is a specialization of (FW1); no charged current is required.

### S5.1. Exact background and physical spectral problem {#app-B.1}

Use the six exact rational parameters, launch interval and wall-distance interval in manuscript Appendix A. In particular, the centered traces in the added interaction are exact traces of the linked root, not independently rounded constants. Let \(E=a^{-1}\), \(T=\Phi_0'\), \(H=a'/a\). The background first integral and regular scalar system are manuscript (9)–(10), with inward signs \(\sigma_a=+1\), \(\sigma_b=-1\). The metric perturbation \(\psi\), scalar \(f\), derivative \(g\), and \(L=g+2T\psi\) are retained through the turn. The equations hold globally in distributions, with finite original-action Hermitian kinetic norm and the physical wall traces. They are not patched separately on the two sides of \(T=0\).

The neutral reconstruction has four parts, derived in Section S1 and Appendices K-L: the full generic scalar Israel/bending equations are equivalent to the retained characteristic; its artificial simple zero at \(\lambda=\mu+4k=0\) is removed without deleting finite poles or nonzero roots; the original-action Green identity supplies the positive kinetic weight; compact wall continuation preserves exhaustive simple roots. These results provide the physical input to the subsequent Sturm/phase argument. It is not inferred from an algebraic change of dependent variable alone. Exceptional harmonics, with identically zero traceless Hessian, are outside this count.

Appendices M–N prove the restricted index, wall limits and remaining-band exclusion, using the launch (13) and enclosed phase (14). Appendix O justifies the numerical predicates; their truth remains conditional on the identified outward execution.

### S5.2. Why oscillator elimination is legitimate only on the negative axis {#app-B.2}

For each centered canonical surface oscillator the undivided rows are manuscript (15). For \(\mu<0\), \(d_i=\omega_i^2+\beta_i-\mu E_i^2>0\), so \(u_i=\beta_i\eta_i f_i/d_i\). The effective Hessian \(\Gamma_i\) is nonnegative and nonincreasing in \(\mu\), while the original unique eigenvalue \(\alpha\) is nondecreasing in each constant Hessian. Consequently \(F(\mu)=\alpha(\Gamma_a(\mu),\Gamma_b(\mu))\) is nonincreasing. At the two constant-Hessian comparison masses \(\alpha(\Gamma_0)\le\alpha(\Gamma_\infty)\), the function \(F-\mu\) has opposite weak signs. Its strict decrease yields exactly one root.

Differentiate the original-action Green identity, keeping the surface oscillator equation. The wall inertia adds \(\sum_i a_i^2|u_i|^2\) to the norm. Equivalently, the derivative contribution of \(\Gamma_i\) to the mass variation is minus this added term divided by the bulk norm. Therefore, at the fixed point,

\[
(\mu-F)'=\frac{Z_A+\sum_i a_i^2|u_i|^2}{Z_A}>0.
\tag{S1}
\]

The undivided equations show that no pure oscillator mode lies at a negative pole. Reality follows from the same Hermitian Green identity before elimination. This completes the negative-sector count conditional on manuscript Proposition 1. At nonnegative mass the oscillator poles must be restored in the characteristic. The no-massless assertion in Proposition 1 does not exclude added massless spectator states in the enlarged theory.

### S5.3. The selected oscillator proof {#fw-oscillator}

At \(\chi_i=0\), interaction (2) preserves the exact background. For a generic harmonic, the tracefree Israel consequence removes bending in longitudinal gauge after variation; it is not an independent frozen-embedding assumption. Let \(u_i\) be the surface \(\chi_i\) amplitude and \(\kappa_i=\tau_i''\ge0\). The physical undivided boundary equations are

\[
\begin{gathered}
2\sigma_iL_i=(\kappa_i+\beta_i\eta_i^2)f_i-\beta_i\eta_i u_i,\\
\left(\omega_i^2+\beta_i-\frac{\mu}{a_i^2}\right)u_i
=\beta_i\eta_i f_i.
\end{gathered}
\tag{15}
\]

The oscillator sees \(\mu/a_i^2\), not the gravitationally shifted parameter. Its poles at positive \(\mu\) must remain in the undivided problem. The coupled negative-sector kinetic coefficient is

\[
Z_{\mathrm{ext}}=Z_A+\sum_i a_i^2|u_i|^2>0.
\tag{16}
\]

The corresponding Green identity supplies reality with this same physical norm.

**Corollary S1 — selected oscillator specialization.** Conditional on Proposition 1, arbitrary finite couplings \(\omega_i^2>0\), \(\beta_i\ge0\), real \(\eta_i\) and \(\kappa_i\ge0\) preserve exactly one real simple negative radial eigenvalue in the declared coupled scalar sector. It obeys \(\mu_*\le\alpha_{DD}<-4k\).

**Proof.** For \(\mu<0\), every oscillator denominator in (15) is positive. Eliminating the amplitude for this argument gives the effective Hessian

\[
\Gamma_i(\mu)=\kappa_i+\beta_i\eta_i^2
-\frac{\beta_i^2\eta_i^2}{\omega_i^2+\beta_i-\mu/a_i^2}.
\tag{17}
\]

It satisfies

\[
\begin{gathered}
0\le\Gamma_{i,0}:=\kappa_i+
\frac{\beta_i\eta_i^2\omega_i^2}{\omega_i^2+\beta_i}
\le\Gamma_i(\mu)\le\Gamma_{i,\infty}:=\kappa_i+\beta_i\eta_i^2,\\
\Gamma_i'(\mu)=-\frac{\beta_i^2\eta_i^2}
{a_i^2(\omega_i^2+\beta_i-\mu/a_i^2)^2}\le0.
\end{gathered}
\tag{18}
\]

Every negative coupled mode is therefore a fixed point

\[
\mu=F(\mu):=\alpha(\Gamma_a(\mu),\Gamma_b(\mu)).
\tag{19}
\]

The function \(F\) is continuous and nonincreasing. Let \(\mu_L=\alpha(\Gamma_{a,0},\Gamma_{b,0})\) and \(\mu_U=\alpha(\Gamma_{a,\infty},\Gamma_{b,\infty})\). Both lie below \(-4k\), and \(F(\mu_L)\ge\mu_L\), \(F(\mu_U)\le\mu_U\). A fixed point exists between them and is unique because \(F(\mu)-\mu\) is strictly decreasing. At the root, the norm-slope identity gives

\[
\frac{d}{d\mu}[\mu-F(\mu)]
=\frac{Z_{\mathrm{ext}}}{Z_A}>0,
\tag{20}
\]

so it is simple. No negative pure oscillator mode or negative oscillator pole was omitted. An additional negative bulk-coupled mode would contradict Proposition 1 at its own constant nonnegative Hessian pair. The bound by \(\alpha_{DD}\) follows from (12). \(\square\)

This specialization preserves the complete negative count on the certified background. More generally it preserves the restricted count of Theorem 2. Decoupled positive-kinetic massless spectators can be added, but they do not alter this negative count and must be retained as zero modes in the enlarged theory.

## S6. Matrix ordering and localized trace inertia {#fw-inertia}

### S6.1. Parameter response {#fw-response}

For a simple negative mode on a fixed background, varying the matrices along a smooth admissible parameter \(\zeta\) gives

\[
\frac{d\mu}{d\zeta}
=\frac{\displaystyle\sum_i a_i^4z_i^T
\left(\frac{d\mathsf H_i}{d\zeta}
-\frac{\mu}{a_i^2}\frac{d\mathsf K_i}{d\zeta}\right)z_i}
{Z_{\mathrm{new}}}.
\tag{TI1}
\]

This follows by differentiating the stationary Schur form and then the bulk fixed-point equation; its denominator is (FW5). Positive-semidefinite matrix increases in either restoring or kinetic form are therefore nondecreasing for negative masses. This is matrix ordering, not entrywise ordering. Kinetic changes at fixed \(\mathsf H_i\) preserve the count by (SC2), even when two kinetic matrices are not ordered.

### S6.2. The specified two-wall limit {#fw-trace-limit}

On the central background fix the potentials and all other kinetic entries, and add \(\zeta e_0e_0^T\) to \(\mathsf K_i\) at both walls, \(\zeta\ge0\). The symbol \(\zeta\) is a coupling parameter, not physical time. Then

\[
\begin{gathered}
\Gamma_i(\mu,\zeta)=\Gamma_i(\mu,0)-\zeta\mu/a_i^2,\\
\frac{d\mu_*}{d\zeta}
=\frac{-\mu_*}{Z_{\mathrm{new}}}\sum_i a_i^2f_i^2>0,
\qquad \mu_*(\zeta)\longrightarrow\alpha_{DD}< -4k.
\end{gathered}
\tag{TI2}
\]

The finite-wall trace of the negative mode is nonzero by the inherited endpoint uniqueness. Since \(\mu_*\le\alpha_{DD}<0\), both effective Hessians diverge as \(\zeta\to\infty\), so continuity at the compact Dirichlet face proves the limit. If \(\mu=-r(r+3h)\), the homogeneous linear growth rate decreases to

\[
r_{DD}=\frac{-3h+\sqrt{9h^2-4\alpha_{DD}}}{2}>h.
\tag{TI3}
\]

At a background wall, proper time rescales both \(r\) and \(h\) by \(a_i^{-1}\); their ratio is unchanged. This is a linear rate statement, not nonlinear fate. It concerns trace inertia at both walls. Adding inertia only to an uncoupled spectator has no such effect; adding the trace term at only one wall gives the corresponding mixed Dirichlet/dynamical-wall limit instead.

### S6.3. Leading approach to the Dirichlet ceiling {#fw-asymptotic}

Let \(t_i=(1+\kappa_i)^{-1}\) be the compact wall coordinates. The inherited simple physical characteristic gives analytic dependence near \(t_a=t_b=0\). For a nontrivially normalized double-Dirichlet mode, define \(Z_{DD}\) by (11) and its conormal traces by \(L_{i,DD}\). The face response is

\[
\alpha_{t_i}(0,0)=-\frac{4a_i^4L_{i,DD}^2}{Z_{DD}}<0.
\tag{TI4}
\]

Indeed the finite-wall relation gives \(f_i=2\sigma_iL_i/\kappa_i\); combine it with \(\alpha_{\kappa_i}=a_i^4f_i^2/Z_A\) and \(d\kappa_i/dt_i=-t_i^{-2}\). At the Dirichlet face, \(L_{i,DD}=0\) together with \(f_i=0\) would force the below-threshold mode to vanish.

With \(\epsilon=1/\zeta\), the dynamic root has

\[
t_i=\frac{\epsilon}{x_i(\mu)+\epsilon[1+\Gamma_i(\mu,0)]},
\qquad x_i(\mu)=-\mu/a_i^2.
\tag{TI5}
\]

At \(\epsilon=0\), the fixed-point equation is \(\mu=\alpha_{DD}\), with unit derivative with respect to \(\mu\). The implicit-function theorem and (TI4) yield

\[
\begin{gathered}
\mu_*(\zeta)=\alpha_{DD}-\frac{C_{DD}}{\zeta}+O(\zeta^{-2}),\\
C_{DD}=\frac{4\sum_i a_i^6L_{i,DD}^2}
{(-\alpha_{DD})Z_{DD}}>0.
\end{gathered}
\tag{TI6}
\]

The coefficient is invariant under rescaling the Dirichlet eigenmode and independent of the fixed finite wall matrices at this leading order. It is symbolic: no numerical value or explicit remainder constant has been established here.

Inverse-parameter corrections with boundary-flux coefficients also occur in Robin-to-Dirichlet asymptotics [40]. The expression above is derived for the present eigenvalue-dependent boundary response and original-action normalization. The Laplacian result provides a methodological comparison, while the gravitational coefficient and remainder order follow from the simple physical characteristic used here.

## S7. A separate concave background and two limiting rates {#fw-concave}

### S7.1. Exact background and the soft-corner count {#fw-concave-model}

This example uses a different bulk potential and different exact walls from the article's central model. Use the same canonical doubled-cover bulk equations (9), in a chart whose warp is normalized at the interior scalar minimum:

\[
\begin{gathered}
V(\Phi)=\Phi-\tfrac12\Phi^2+\Phi^4,\qquad k=3,\\
(a,H,\Phi,T)(0)=(1,-2,0,0),\qquad
-1/100\le s\le1/100.
\end{gathered}
\tag{CE1}
\]

The Hamiltonian constraint is exactly satisfied initially and propagates. The compact rectangle

\[
\tfrac9{10}\le a\le\tfrac{11}{10},\quad
-\tfrac{21}{10}\le H\le-\tfrac{19}{10},\quad
|\Phi|\le\tfrac1{100},\quad |T|\le\tfrac1{50}
\tag{CE2}
\]

has derivative bounds \(231/100\), \(250009/67500\), \(1/50\) and \(294501/250000\), respectively. Multiplying by \(1/100\) gives displacements strictly smaller than each initial distance to its faces. A first-exit argument in either direction therefore keeps the unique exact IVP inside the rectangle throughout the interval; smooth compact-domain continuation supplies existence. Throughout it,

\[
T'\ge\tfrac{205499}{250000}>0,\qquad
V''\le-\tfrac{2497}{2500}<0,\qquad
V''+12/a^2+4T^2/3\ge\tfrac{1079}{121}>0.
\tag{CE3}
\]

Thus there is one scalar turn and positive warp, despite strict concavity of the traversed potential. With endpoint values from this exact IVP, define the background-preserving pure wall potentials by

\[
\begin{aligned}
\tau_a(\Phi)&=-6H_a+2T_a(\Phi-\Phi_a)
+\tfrac12\kappa_a(\Phi-\Phi_a)^2,\\
\tau_b(\Phi)&=6H_b-2T_b(\Phi-\Phi_b)
+\tfrac12\kappa_b(\Phi-\Phi_b)^2.
\end{aligned}
\tag{CE4}
\]

By (CE3), Lemma 1 supplies the endpoint signs and one scalar turn. Theorem 1 then gives exactly one eigenvalue below \(-4k\), no threshold mode, and the real simple ordered static spectrum for every nonnegative wall pair, including Dirichlet faces. The additional soft-corner mode follows from the following direct estimate.

**Lemma S2 (soft-corner count).** For (CE1)--(CE4) at \(\kappa_a=\kappa_b=0\), exactly one eigenvalue lies in \((-4k,0)\), and zero is not an eigenvalue. Thus the total negative count at that corner is two.

**Proof.** Keep the interior normalization of (CE1), so \(k=3\), the lower warp \(a_a\) need not equal one, and the interval length is \(D=1/50\). At \(\mu=0\), the constraint and lower wall fix
\[
\psi_a=1,\qquad f_a=-\frac{36}{a_a^2T'_a},\qquad L_a=0.
\]
Bounds (CE2)--(CE3) give \(-55<f_a<-25\). The regular equations are
\[
\begin{aligned}
\psi'&=-2H\psi-Tf/3,\qquad f'=L-2T\psi,\\
L'&=-4HL+(V''+4T^2/3)f-2T'\psi.
\end{aligned}
\]
In the box \(1/2\le\psi\le3/2\), \(-56\le f\le-23\), \(0\le L\le3\), the same background bounds imply
\[
\begin{gathered}
|\psi'|\le\frac{1001}{150},\qquad |f'|\le\frac{153}{50},\\
0<\frac{14569591}{750000}\le L'\le\frac{21183503}{250000}.
\end{gathered}
\]
Multiplication by \(D\) gives displacements smaller than \(1/2\), \(1\), and \(3\), respectively. These are strictly within the initial distances to the \(\psi\) faces, both \(f\) faces (at least 1 and 2), and the upper \(L\) face. The positive lower bound for \(L'\) prevents exit through its lower face. A first-exit argument therefore gives \(f<0\) and \(L>0\) along the entire interior path, with \(L_b>0\).

Consequently \(L+if\) remains in the fourth quadrant and its continuous lift from \(3\pi/2\) obeys \(3\pi/2<\theta_b(0)<2\pi\). Appendix N.3 attaches this lift to the threshold phase in \((\pi,3\pi/2)\). Strict spectral monotonicity (M2) crosses exactly one upper-wall level, \(3\pi/2\), before \(\mu=0\); the next is \(5\pi/2\). Since \(L_b>0\), zero is not a root. This proves the remaining-band count. Lower-wall normalization rescales \(\mu\) and \(k\) by the same positive factor \(a_a^{-2}\), preserving the result. \(\square\)

The continuation inequality (M5) bounds the remaining-band count at every other nonnegative wall pair by one. The next subsection identifies precisely where that extra mode crosses zero.

### S7.2. The static transition and material relaxation {#fw-transition}

At physical \(\mu=0\), the regular constraint gives \(\psi=a^2(TL-T'f)/36\). Substitution in (10) yields an equivalent two-dimensional system through the turn:

\[
\begin{gathered}
\begin{pmatrix}f\\L\end{pmatrix}'=\begin{pmatrix}A_0&E_0\\C_0&D_0\end{pmatrix}\begin{pmatrix}f\\L\end{pmatrix},\\
A_0=a^2TT'/18,\quad E_0=1-a^2T^2/18,\\
C_0=V''+4T^2/3+a^2(T')^2/18,\quad D_0=-4H-A_0.
\end{gathered}
\tag{CE5}
\]

Here the prime acts on the entire column \((f,L)^T\). In (CE2), \(|A_0|\le1/500\), \(99/100\le E_0\le1\), \(-1\le C_0\le-9/10\) and \(7\le D_0\le9\). Let \(\mathcal M=(m_{ij})\) be its exact transfer matrix from the lower to upper wall. For the first fundamental column, the invariant first-exit box \(9/10\le f\le11/10\), \(-1/10\le L\le0\) gives \(-2\le L'\le-81/100\), \(|f'|\le511/5000\). For the second, \(0\le f\le1/10\), \(1\le L\le13/10\) gives \(4949/5000\le f'\le6501/5000\), \(69/10\le L'\le59/5\). Integration over length \(1/50\) closes both boxes and gives

\[
\begin{gathered}
\tfrac{249489}{250000}\le m_{11}\le\tfrac{250511}{250000},\qquad
-\tfrac1{25}\le m_{21}\le-\tfrac{81}{5000},\\
\tfrac{4949}{250000}\le m_{12}\le\tfrac{6501}{250000},\qquad
\tfrac{569}{500}\le m_{22}\le\tfrac{309}{250},\\
\det\mathcal M=(a_a/a_b)^4>0.
\end{gathered}
\tag{CE6}
\]

For finite \(x=\kappa_a\), normalize \((f_a,L_a)=(1,x/2)\). The upper row \(L_b+yf_b/2=0\) is exactly

\[
\mathcal S(x,y)=2m_{21}+xm_{22}+ym_{11}
+\tfrac12xy m_{12}=0,\qquad y=\kappa_b.
\tag{CE7}
\]

Its nonnegative zero set is a single decreasing convex arc, since

\[
y_c(x)=-\frac{2m_{21}+xm_{22}}{m_{11}+xm_{12}/2},\quad
y_c'=-\frac{\det\mathcal M}{(m_{11}+xm_{12}/2)^2}<0,
\tag{CE8}
\]

and differentiation once more gives a positive second derivative. Along any nonzero positive ray from the soft corner, \(\mathcal S\) increases strictly; the physical norm response (M3) makes a massless crossing simple and upward. The soft-corner count in Lemma S2 and absence of collisions or escape in the remaining band therefore give two negative modes for \(\mathcal S<0\), one for \(\mathcal S\ge0\), with one massless bulk mode exactly on the arc. On the Dirichlet faces the zero residuals are respectively \(m_{11}+xm_{12}/2\), \(m_{22}+ym_{12}/2\) and \(m_{12}\), all positive. Continuation from large finite Hessians gives exactly one negative mode and no zero mode there.

The conservative bounds (CE6) imply \(\mathcal S<0\) when \(x+y\le1/50\), and \(\mathcal S>0\) when \(x+y\ge1/10\). Proposition S1 substitutes \((x,y)=(s_a,s_b)\) for every admissible finite wall system. At fixed potential Hessians, no kinetic mixing or trace inertia moves this count boundary. For the canonical oscillator potential with \(\kappa_i=0\), \(\beta_i=\omega_i^2=1\), one has \(s_i=\eta_i^2/2\). Taking both \(\eta_i=1/10\) gives two negative modes, whereas both \(\eta_i=1/2\) gives one. These are exact deductions from the rational witness regions, not measured eigenvalues; the persistent instability survives in both cases.

### S7.3. Two distinct rates in one fixed completion {#fw-two-rates}

Center one oscillator at each of this background's own scalar traces and keep

\[
\mathsf H_i=\begin{pmatrix}1/100&-1/10\\-1/10&2\end{pmatrix},\qquad
\mathsf K_i(\zeta)=\operatorname{diag}(\zeta,1),\qquad
s_i=1/200,\quad\zeta\ge0.
\tag{TR1}
\]

The potential is fixed and positive definite. Since \(s_a+s_b=1/100<1/50\), there are exactly two negative masses \(\mu_1(\zeta)<-4k<\mu_2(\zeta)<0\) at every finite \(\zeta\). Both increase by (TI1). The persistent branch approaches its own negative Dirichlet value with (TI6), using this background's data. In contrast \(\mu_2(\zeta)\to0^-\): a strictly negative limit would drive both effective Hessians to infinity and force that limit to be the second Dirichlet eigenvalue, which is positive by the Dirichlet count and zero-mode exclusion in Section S7.2. Infinite inertia is a singular limit outside the finite-coupling count theorem.

Write \(v_i=a_i^{-2}\), and let \(c_*>0\) be the unique solution of

\[
\mathcal S(s_a+c_*v_a,s_b+c_*v_b)=0.
\tag{TR2}
\]

Existence and uniqueness follow from \(\mathcal S(s_a,s_b)<0\) and strict increase along this ray. Equivalently \(c_*\) is the positive root of \(C_2c^2+B_2c+\mathcal S(s_a,s_b)=0\), where \(C_2=m_{12}v_av_b/2>0\) and \(B_2=v_am_{22}+v_bm_{11}+m_{12}(s_av_b+s_bv_a)/2>0\).

For \(\zeta>0\), put \(c(\zeta)=-\zeta\mu_2(\zeta)\). At the root the corresponding static problem has two negative modes, so \(\mathcal S(\Gamma_a,\Gamma_b)<0\). Since \(\Gamma_i(\mu,0)>s_i\) for \(\mu<0\) in this completion, strict monotonicity gives \(0<c(\zeta)<c_*\). Every convergent subsequence as \(\zeta\to\infty\) solves (TR2), by \(\mu_2\to0\) and continuity of the static characteristic. Hence \(c(\zeta)\to c_*\).

Set \(\epsilon=1/\zeta\), \(\mu=-\epsilon c\). The remaining-branch equation is

\[
\alpha_2\big(\Gamma_a(-\epsilon c,0)+cv_a,
\Gamma_b(-\epsilon c,0)+cv_b\big)+\epsilon c=0.
\tag{TR3}
\]

At \((c,\epsilon)=(c_*,0)\) its derivative in \(c\) is \(\sum_i(\alpha_2)_{\kappa_i}v_i>0\). The response is analytic at zero, so the implicit-function theorem yields

\[
\mu_2(\zeta)=-\frac{c_*}{\zeta}+O(\zeta^{-2}),\qquad
r_2(\zeta)=\frac{c_*}{3h\zeta}+O(\zeta^{-2}),\qquad h=\sqrt3.
\tag{TR4}
\]

The witness regions and \(9/10<a_i<11/10\) give

\[
\begin{gathered}
\frac{81}{20000}<c_*<\frac{1089}{20000},\qquad
0<\frac{r_2(\zeta)}h<\frac{121}{20000\zeta}\quad(\zeta>0),\\
\frac9{20000}<\lim_{\zeta\to\infty}\frac{\zeta r_2(\zeta)}h
<\frac{121}{20000},\qquad \frac{r_1(\zeta)}h>1.
\end{gathered}
\tag{TR5}
\]

Indeed the transition requires \(1/50<s_a+s_b+c_*(v_a+v_b)<1/10\), and \(200/121<v_a+v_b<200/81\). The finite-rate bound uses \(r_2<(-\mu_2)/(3h)\) and \(c(\zeta)<c_*\). Under lower-wall normalization \(a\mapsto a/A\), \(\mu,k,c_*\mapsto(\mu,k,c_*)/A^2\) and \(\zeta\) is unchanged; \(r/h\) is invariant. No numerical mass or remainder constant is asserted. The extra instability can become arbitrarily slow while the persistent mode remains faster than the background expansion rate. This distinguishes changing the restoring potential from changing inertia without inferring nonlinear saturation, a charged extension or a physical endpoint.


## S8. Certified upper-wall parameter families {#family-records}

The parameter-family calculation applies the original background and phase producers to interval-valued upper-wall parameters. The bulk parameters, lower wall and background wall curvature \(\gamma=20\) remain fixed. The accepted subintervals have width \(1/1000\). This is a family of different matched backgrounds; variation of perturbative wall Hessians within each member is the separate operation used by the spectral theorem.

**Table 8. Parameter coverage and continuity claims.**

| Run | Varied parameter range | Certified coverage and limitation |
|---|---|---|
| L | \(\lambda_b\in[-6.0529,-6.0229]\) | 30/30 subintervals; one branch through the anchor |
| V | \(v_1\in[0.086,0.150]\) | 62/64; anchor branch only on \([0.086,0.099]\); other certified runs \([0.100,0.147]\), \([0.148,0.150]\) |
| W | \(v_1\in[0.088,0.100]\), \(\lambda_b\in[-6.0529,-6.0429]\) | 115/120 cells; five failed cells include the anchor cell, so no two-dimensional neighbourhood of the anchor is certified |

The V/L controls passed 59 checks: archived-point reproduction, degenerate-parameter-box reproduction and proof that both engines consume the interval parameters. The separate W controls passed 39 checks. Every accepted sub-box retains its exact Newton images, event brackets, derivative signs, geometry bounds and phase hulls. The article corollary uses only the connected L and V segments stated there. Exact records and the full L/V tables are included in the public pipeline with their source hashes and full phase traces; see Data availability.

The archived Newton image (31) is strictly contained in the frozen launch boxes for \(v_1\in[0.090,0.091]\) and \(\lambda_b\in[-6.0529,-6.0519]\), respectively. Those boxes are binary64 dyadic intervals, specified by the round-trip decimal representations

\[
\begin{aligned}
v_1\text{ subinterval}:&\quad [0.09901075850991535,0.09901097594208401],\\
\lambda_b\text{ subinterval}:&\quad [0.09901083813541005,0.09901091652288684].
\end{aligned}
\] Exact rational containment and uniqueness identify the family roots at the anchor; the separate degenerate control checks phase reproduction.

V failed on the open gaps \((0.099,0.100)\) and \((0.147,0.148)\). A retained post-hoc diagnostic localized each to the independent engine's fixed Picard-iteration cap on a sensitivity component; the enclosures stayed finite. W's five failed cells were nearest the integration endpoint \(s=2\), where the coarser event bracket reached that endpoint. These are failures to certify, not counterexamples to the count or proof that the gaps can be crossed. No continuity assertion passes through them.

Figure 8 plots the exact saved terminal-phase hulls as rectangles over their full parameter intervals. A shared colour denotes continuity to the anchor only where the seam predicates pass. Other certified pieces have a different colour. Plotting uses floating coordinates, while all displayed inclusion and seam checks are evaluated in exact rationals. It does not regenerate the interval trajectories. Across all 207 accepted L/V/W boxes, the phase hulls lie in \([1.0748,1.0802]\), the margin to \(3/2\) is at least \(0.4198\), \(T_b\ge0.0051\), and \(k\ge3.268\times10^{-4}\); these decimal bounds are rounded outward. A favourable phase value does not compensate for a failed background predicate.

## S9. Flat-slice examples and evidence classes {#flat-examples}

### S9.1. Exploratory turns and spectra {#flat-numerics}

The reported flat-slice experiment used two step counts, 2000 and 4000, forward and backward characteristic counts, and a phase count. Three flat cases tested 16 nonnegative wall pairs each: a convex one-turn background with decreasing warp, another with increasing warp, and a three-turn background with a concave potential. All 48 wall pairs gave the predicted negative counts. The implementation checks and controls passed. The phase count uses a refined phase-increment safety evaluation; the stored eigenvalues and characteristic counts are unchanged. Records retain the failed evaluation and its corrected form. All spectral values here are exploratory floating-point results, not interval spectral certificates.

Figure 9 displays the saved turn positions and representative spectra.

![Saved scalar-turn locations and negative spectra at four symmetric wall pairs for one-turn and three-turn flat backgrounds.](figures/flat_turn_spectra.png){#fig:flat_turn_spectra}

**Figure 9.** Exploratory flat-slice records at 4000 steps. Left: saved zero locations of \(T=\Phi'_0\), normalized by wall separation; the signs between successive simple zeros alternate from \(T_a<0\). These are turn-location diagrams, not reconstructed scalar profiles. Right: negative eigenvalues at the saved symmetric pairs \(t_a=t_b\in\{1,0.5,0.1,0\}\), with \(t=(1+\kappa)^{-1}\); the endpoints are soft and Dirichlet walls. Markers are discrete observations and are not interpolated branches. The cases have one and three negative roots respectively, with different vertical scales. No individual scalar turn is identified with a particular eigenmode. F1 shares its lower Cauchy data with the interval-enclosed example below, but has a different upper wall; the saved interval records contain no predicate at the F1 wall.

The illustrated F1 case has \(V=2\Phi^2\), \(\Phi_a=1\), \(T_a=-1/2\), \(H_a=-\sqrt{11}/4\), and \(D\simeq0.467724\). F3 has \(V=5.5-10\Phi^2\), \(\Phi_a=-0.3\), \(T_a=-1/2\), positive initial \(H_a\simeq0.504149\), and \(D\simeq1.676543\). Walls are constructed from the background values and slopes as in Appendix P.2. The de Sitter float control gave approximately \(1.0763265\), inside the certified phase interval, and a monotone flat control reproduced the expected change under destabilizing endpoint signs. These controls support implementation consistency; the universal count is the analytic corollary, not an inference from finitely many wall pairs.

### S9.2. An interval-enclosed flat background {#flat-certificate}

An outward-Arb calculation at 768 bits enclosed the convex flat background with \(V=2\Phi^2\), \(\Phi_a=1\), \(T_a=-1/2\), \(H_a=-\sqrt{11}/4\), \(a_a=1\), through \(D=3/4\) in 6144 cells. It records positive warp, Hamiltonian-constraint containment, \(T_b>55.934031\) and a positive lower bound on \(T'\) throughout. The upper-wall values and slopes are outputs enclosed by the integration, rather than fixed exact rational inputs as in the de Sitter anchor; this choice supplies the flat compatibility relation discussed in Appendix P.2. With the exact lower signs and the flat one-turn criterion, the spectral conclusion follows from the analytic corollary, conditional on the recorded background predicates; this was not a separate interval eigenvalue calculation.

Two failed Picard attempts are preserved. The calculation uses a tight square enclosure for \(T^2\), growth of only the not-yet-contained components and a 64-iteration cap to obtain closure where \(H'=-T^2/3\) vanishes at a turn. The whole-cell acceptance criterion was retained. The flat calculation and the de Sitter calculation use separately identified source versions. The chosen upper wall is close to the finite-distance singularity found in exploration; the certified interval is compact and regular, but its large upper-wall fields make it less representative than the exploratory F1 illustration. No certificate is transferred from this example to F1 or F3.


## S10. Growth rates and the convex-potential consequence {#growth-rates}

### S10.1. Proper-time growth and the generic sector {#growth-rates.1}

Choose a spatially flat de Sitter patch, \(\gamma_k=-dt^2+e^{2ht}d\mathbf x^2\), with \(h=\sqrt{k}\). On a fixed wall, \(d\tau_i=a_i\,dt\), and its spatial scale factor is \(b_i(\tau_i)=a_i\exp(h_i\tau_i)\), where \(h_i=h/a_i\). The constant warp factors rescale mass and expansion equally:
\[
m_i^2=\mu/a_i^2,\qquad h_i^2=k/a_i^2,
\qquad m_i^2/h_i^2=\mu/k.
\]
This \(h_i\) is distinct from the radial gradient \(H=a'/a\) and the auxiliary positive coefficient \(\mathfrak h\). For a homogeneous separated harmonic \(Q=q_i(\tau_i)\), the physical equation \(\Box_{\gamma_k}Q=\mu Q\) is
\[
\ddot q_i+3h_i\dot q_i+m_i^2q_i=0,
\qquad
q_i=C_+e^{r_i\tau_i}+C_-e^{r_{i,-}\tau_i},
\]
\[
\frac{r_i}{h_i}=-\frac32+\sqrt{\frac94-\frac\mu k}
=\rho(\mu/k),\qquad
\frac{r_{i,-}}{h_i}=-\frac32-\sqrt{\frac94-\frac\mu k}.
\]
Dots denote wall proper time. The familiar exponent [4; Eq. (21)] obeys \(\rho(-4)=1\), \(\rho(0)=0\) and \(\rho'(x)=-1/(2\sqrt{9/4-x})<0\) for \(x\le0\). The growing amplitude is proportional to \(b_i^{\rho(\mu/k)}\). Each counted radial mode therefore supplies a branch with exponent strictly greater than one, independent of which wall measures it. Modes in \((-4k,0)\), if present, instead have exponents between zero and one. Figure 1(c) is this analytic conversion over a finite display interval, not a spectral computation or an upper bound on the possible mass magnitude.

The growing harmonics below the threshold belong to the generic sector. In slice time let \(Q=e^{rt}\), where \(r=a_ir_i>h\). Its traceless Hessian has temporal component \(\tfrac34r(r-h)Q\), which is nonzero. The growing homogeneous harmonic at the threshold \(r=h\) is exceptional, but generic harmonics also exist at that mass; the theorem's threshold exclusion follows from its radial wall/energy argument. A homogeneous harmonic on noncompact spatial slices is used here as a local mode, not as a spatially square-integrable perturbation. For finite comoving momentum the spatial momentum term redshifts, giving the same late-time exponents; admissible spatial packets must still respect the surface-flux condition of Section 2.

The decaying branch and initial data with \(C_+=0\) remain possible. These calculations exhibit growing separated solutions without asserting growth for every perturbation or a complete Cauchy mode basis. They also supply no amplitude-independent inflationary lifetime: reaching a nonlinear amplitude depends on the initial growing coefficient and subsequent dynamics. At flat slicing the homogeneous growing rate is \(\sqrt{-\mu}/a_i\), and there is no nonzero de Sitter expansion rate with which to form the ratio.

### S10.2. Rate brackets and wall dependence {#growth-rates.2}

The static brackets (RT2) and finite-wall brackets (FW3) immediately give, for \(0\le j<n\),
\[
1<\rho\!\left(\frac{\alpha_{j,DD}}k\right)
\le\frac{r_{i,j}}{h_i}
\le\rho\!\left(\frac{\alpha_j(0,0)}k\right).
\]
Thus the Dirichlet ceiling on mass is a positive lower bound on the excess growth rate, uniform over the admitted wall choices on that fixed background. No new mass enclosure is needed for the strict inequality. At fixed background, stiffening a pure-potential wall raises its eigenvalues and slows the corresponding growing branches, but cannot reduce the counted rates to the expansion rate. For mixed wall systems, the response identity (TI1) additionally shows that positive-semidefinite increases of either wall matrix cannot lower a negative mass, hence cannot increase its growing rate. Arbitrary matrix changes need not be ordered. Nor does it give a numerical uniform margin over an arbitrary family of backgrounds without corresponding mass bounds.

### S10.3. What convexity does and does not imply {#growth-rates.3}

The corollary in Section 3.2 uses convexity only along the scalar range visited by the background. With \(k>0\), it ensures \(\mathcal Q>0\). The between-zeros identity applies to any two zeros of \(T\), even if one is an endpoint, and therefore excludes endpoint zeros once an interior turn exists. A double zero is excluded by uniqueness unless \(T\equiv0\), which is incompatible with a non-monotone scalar profile. After orienting the unique simple crossing from negative to positive, the weighted derivative \(a^4T'\) is at least its strictly positive value at the crossing on both sides. This supplies both endpoint derivative signs without another numerical premise.

The orientation reversal is the field relabeling \(\widetilde\Phi=-\Phi\), with the potential and wall functions transformed accordingly; it does not assume an even potential. Congruence preserves the nonnegative wall forms and the positive independent-field kinetic block. The conclusion is one-way: every such non-monotone convex background has exactly one eigenvalue below \(-4k\) and hence at least one tachyon. The corollary neither proves stability for monotone profiles nor excludes other tachyons in \((-4k,0)\). A positive-mass quadratic bulk potential is an example of the convex class, not a description of every Goldberger--Wise variant. The result concerns the full coupled radial problem under the stated domain and wall assumptions, not a universal criterion obtained from a single-radion effective potential.
