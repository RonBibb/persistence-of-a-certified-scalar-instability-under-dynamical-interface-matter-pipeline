# Paper A: quantitative growth-rate investigation

Read [REPORT.md](REPORT.md) for the result, proof link and incorporation advice.
The computation produced a certified wall-uniform rate bound on the fixed
Appendix A background, under the manuscript's inherited analytic premises.
The manuscript and public pipeline were not changed.

Key records:

- [Contract and cutoff](CONTRACT.md)
- [Boundary adaptation and proof](METHOD.md)
- [Exact growth bounds](GROWTH_BOUNDS.json)
- [Three mass brackets](results/BRACKETS.json)
- [Symbolic controls](BOUNDARY_CONTROLS.json)
- [Fresh-process controls](PREFLIGHT.json) and [identity/replay audit](RESTART_AUDIT.json)
- [Runtime](RUNTIME.json), [post-run identity check](RUNTIME_RECHECK.json) and [source/input freeze](FREEZE.json)
- [Proposed manuscript insertion](PROPOSED_INSERTION.md)
- [Closeout](CLOSEOUT.json) and [resource closeout](RESOURCE_CLOSEOUT.json)

The two interval engines are unmodified copies of the archived mass engines.
`src/flow.py` adapts only the lower launch and upper determinant for the soft and
Dirichlet boundary cases. `src/investigate.py` applies the declared rational
bracketing rule. `src/analyze.py` checks saved endpoint records and converts the
mass bounds using exact rational inequalities.

The successful native Linux command used Python 3.14.4 and the existing
python-flint 0.9.0 installation, with:

    PYTHONPATH=/home/parallels/research-runs/cap-interval-arb-2026-09-12:/home/parallels/codex-precision-venv/lib/python3.12/site-packages
    PYTHONDONTWRITEBYTECODE=1
    PYTHONHASHSEED=0
    PYTHONNOUSERSITE=1
    OPENBLAS_NUM_THREADS=1
    OMP_NUM_THREADS=1

Full commands and durations are in `progress/invocations.json`; the actual
interpreter and library identities are in RUNTIME.json. No package was installed.
The job used one arithmetic worker under a one-core aggregate systemd quota,
with no affinity pinning. This packet is preserved research evidence, not a
claim that the deferred clean-download pipeline replay is finished.

Saved-record inspection and exact rate conversion can be repeated with
`python3 -B src/analyze.py` in the recorded Linux environment. Production and
adversarial replay sources retain the original hard cutoff and refuse to
overwrite terminal units; a future run needs a separately authorized, newly
bound output packet. Completed historical files must not be edited to restart it.
