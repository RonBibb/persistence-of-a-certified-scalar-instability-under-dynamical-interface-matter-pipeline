# Paper A growth-rate certification investigation

Authorized by Ronald's “Do it” after the proposed two-hour first investigation.
Start: 2026-11-14 19:00:56 UTC. Hard computation cutoff: 21:00:56 UTC.

Purpose: reproduce the physical-wall eigenvalue, then obtain a rigorous
Dirichlet ceiling and, if practical, the soft-wall floor on the same exact
background. Translate the mass brackets to proper-time growth-rate brackets.
Use the present manuscript's Theorems 1–2 for uniqueness and wall-uniform
transfer. Those analytic results and the original background certificate are
inherited premises, not re-proved by numerical signs.

The physical perturbative Hessians are (20,20). The background action always
retains gamma=20. The soft corner (0,0) and the Dirichlet corner change only
perturbative boundary conditions, not the background or its uncertainty.

Linux executes all numerical work and scientific hashes. One sequential
worker, one arithmetic/BLAS thread, OS scheduling, no CPU pinning; 3 GiB
address-space limit and a maximum 180-second deadline per flow. New artifacts
are written on the Research share in this unique packet. Do not alter the
ClaudeCode2 HOLD, historical jobs, existing evidence, manuscript or pipeline.
No agents, nonlinear evolution, parameter-family expansion or successor run.

Freeze the source, exact background inputs, engine copies, precision (768 bits),
work order, stopping rules, inherited theorem source and runtime before work.
Each full validated flow is the small resumable unit. Commit its terminal
record atomically, then commit controller progress. Reuse only matching
fingerprints. A failed flow is retained and is never a certificate. No partial
result is a completed unit. Fresh-process identical-flow and altered-fingerprint
controls qualify restart. Long internal trajectories are not expected: each
unit has a short enforced timeout, so interrupted units may restart in full.

Initial mass bracket: [-33/25000,-2615/2000000]. Primary bisection first, with
quarter-point probes when an interval sign is indeterminate; at most 18 rounds
per wall choice and target width 1/50000000. Retain strict opposite signs;
stop refinement after two rounds without improvement. The independently
written exponential engine then verifies both bracket endpoints. Both engines
use Arb; this is not independent arithmetic-library validation.

Required predicates: strict cell Picard inclusions, finite states, positive
warp, inclusion of zero in constraint and first-integral residuals, complete
coverage of the uncertain upper-wall interval, strict terminal opposite signs,
positive curvature and a strictly negative shifted mass throughout each bracket.
The original normalization and original physical determinant are used for the
physical pair. Other launch/determinant adaptations are separately documented
and checked algebraically.

Deliverables: bound inputs and code, preserved adverse attempts, numerical
records, exact growth conversion, explicit inherited-premise map, a report
of scientific value and incorporation recommendation, and resource closeout.
The goal is a mature bounded result, not merely a checkpoint. Finish early
only when that deliverable is complete or a documented obstacle prevents
further useful work within the authorized scope. No manuscript edit is assumed.
